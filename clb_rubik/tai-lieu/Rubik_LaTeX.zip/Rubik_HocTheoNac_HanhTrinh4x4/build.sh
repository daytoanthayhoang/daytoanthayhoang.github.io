#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
xelatex -interaction=nonstopmode -halt-on-error Rubik_HocTheoNac.tex
xelatex -interaction=nonstopmode -halt-on-error Rubik_HocTheoNac.tex
