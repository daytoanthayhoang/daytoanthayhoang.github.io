"""Print the exact continuous 4x4 lesson shared with the web player."""
from pathlib import Path
import sys,json,math,hashlib,textwrap
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'render_toolkit'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle
import numpy as np
from validated_cube import Cube
import draw_figures as df
from visual_sequences import cube_draw,cube_camera,cube_move_note
D=json.loads((ROOT/'data/walkthrough4.json').read_text())
N=json.loads((ROOT/'data/walkthrough4_narrative.json').read_text())
assert N['source_sha256']==hashlib.sha256((ROOT/'data/walkthrough4.json').read_bytes()).hexdigest()
NARR={x['id']:x for x in N['phases']}
TEXT_ONLY='--text-only' in sys.argv
OUT=ROOT/'assets/walkthrough4';OUT.mkdir(parents=True,exist_ok=True)
original_marks=df.add_view_marks
def readable_marks(ax,*args,**kwargs):
    kwargs['fontsize']=10.5;original_marks(ax,*args,**kwargs)
    for t in ax.texts:
        if t.get_text().startswith('Nhìn '):t.set_fontsize(11.5)
df.add_view_marks=readable_marks

c=Cube(4).apply(D['scrambleAlgorithm']);states=[c.copy()]
for move in D['moves']:c.move(move);states.append(c.copy())
assert len(states)==len(D['frames'])
for c,f in zip(states,D['frames']):
    assert c.validate()['passed']
    assert all(c.matrix(face)==f['state']['faces'][face] for face in 'URFDLB')
    assert all(tuple(s.pos)==tuple(t['pos']) and tuple(s.normal)==tuple(t['normal']) and s.color==t['color'] for s,t in zip(c.stickers,f['state']['stickers']))
assert c.is_uniform()

def net(state,name,title,ids=()):
    if TEXT_ONLY:
        assert (OUT/name).exists();return
    fig,ax=plt.subplots(figsize=(9.4,6.2));layout={'U':(1,2),'L':(0,1),'F':(1,1),'R':(2,1),'B':(3,1),'D':(1,0)}
    for face,(col,row) in layout.items():
        x,y=col*4.65,row*4.9
        for r in range(4):
            for co in range(4):
                st=state.face(face)[r*4+co];xx=x+co;yy=y+3-r
                ax.add_patch(Rectangle((xx,yy),.96,.96,facecolor=df.COL[st.color],edgecolor=df.INK,lw=.65))
                if 1<=r<=2 and 1<=co<=2:ax.add_patch(Rectangle((xx+.03,yy+.03),.90,.90,fill=False,edgecolor=df.INK,lw=1.2))
                sid=state.stickers.index(st)
                if sid in ids:ax.add_patch(Circle((xx+.48,yy+.48),.29,fill=False,ec='black',lw=2))
        ax.text(x+1.95,y+4.25,face,ha='center',va='center',fontsize=13,fontweight='bold',color=df.INK)
        for k in range(4):
            ax.text(x-.18,y+3.48-k,str(k+1),ha='right',va='center',fontsize=7.5,color=df.INK)
            ax.text(x+k+.48,y-.15,str(k+1),ha='center',va='top',fontsize=7.5,color=df.INK)
    ax.set_aspect('equal');ax.set_xlim(-.65,18.4);ax.set_ylim(-.45,14.4);ax.axis('off');fig.suptitle(title,fontsize=13,color=df.INK,fontweight='bold')
    fig.subplots_adjust(left=.01,right=.99,top=.94,bottom=.01);fig.savefig(OUT/name,bbox_inches='tight',pad_inches=.04,facecolor='white');plt.close(fig)

net(states[0],'W4_initial_net.pdf','Khối xáo của ví dụ: 0/6 tâm hoàn chỉnh, 0/12 cặp cạnh')
stage_outputs=[]
for st in D['stages']:
    sid=st['id'];ids=st['highlightIds'];work=st['workingStateIndex']
    net(states[work],sid+'_working.pdf','Khung tìm mảnh: '+sid+' · '+st['title'],ids)
    files=[];indices=list(range(st['start'],st['endExclusive']+1))
    for part,offset in enumerate(range(0,len(indices),8),1):
        selected=indices[offset:offset+8];rows=math.ceil(len(selected)/4)
        if TEXT_ONLY:
            name=f'{sid}_moves_{part}.pdf';assert (OUT/name).exists();files.append(name);continue
        fig,axs=plt.subplots(rows,4,figsize=(9.4,3.10*rows),squeeze=False)
        for j,ax in enumerate(axs.ravel()):
            if j>=len(selected):ax.axis('off');continue
            idx=selected[j];state=states[idx]
            move=D['moves'][idx] if idx<st['endExclusive'] else None
            cube_draw(ax,state,move=move)
            cam,_=cube_camera(move);pm,view=df.projection(cam)
            for k in ids:
                sticky=state.stickers[k]
                if np.dot(sticky.normal,view)>1e-5:
                    center=np.array(sticky.pos)/4+np.array(sticky.normal)/4
                    xy=center@pm.T;ax.add_patch(Circle(xy,.105,fill=False,ec='black',lw=1.1,zorder=10))
            local=idx-st['start']+1
            ax.set_title(f'{local:02d}  {move}' if move else f'{local:02d}  KIỂM MỐC',fontsize=16 if move else 13,fontweight='bold',color=df.INK,pad=4)
            note=cube_move_note(move) if move else 'Kiểm tra rồi\nqua mốc tiếp'
            ax.text(.5,-.025,note,transform=ax.transAxes,ha='center',va='top',fontsize=12.5,color=df.TEAL,linespacing=1.1,clip_on=False)
        fig.subplots_adjust(left=.02,right=.98,wspace=.10,hspace=.37,top=1-.36/(3.10*rows),bottom=.50/(3.10*rows))
        name=f'{sid}_moves_{part}.pdf';fig.savefig(OUT/name,bbox_inches=None,facecolor='white');plt.close(fig);files.append(name)
    stage_outputs.append({'id':sid,'workingFrame':work,'sequenceParts':files,'beforeMetrics':st['beforeMetrics'],'afterMetrics':st['afterMetrics']})

def esc(s):
    return str(s).replace('\\',r'\textbackslash{}').replace('&',r'\&').replace('%',r'\%').replace('#',r'\#').replace('_',r'\_').replace('→',r'$\to$')
T=[]
T.append(r'\subsection*{Trạng thái bắt đầu của chính ví dụ này}')
T.append('Sơ đồ tìm mảnh đã được vẽ sau các nước chuẩn bị để dễ tìm viên; lúc đọc chỉ quan sát, chưa xoay riêng theo sơ đồ. Khi thực hành, làm đúng dãy từ khung 01 một lần. Nếu đã làm nước chuẩn bị trên cube để so khớp sơ đồ, tiếp tục từ khung ngay sau phần chuẩn bị, không làm lại phần ấy.')
T.append(esc(D['disclosure']))
T.append('Hàng và cột được đếm từ1đến4 khi nhìn trực diện từng mặt từ ngoài; không đếm theo hình phối cảnh. Viền vuông nhấn vùng tâm; vòng đen chỉ viên đang theo dõi, không thay màu sticker.'.replace('từ1đến4','từ 1 đến 4'))
T.append(r'\par\noindent\includegraphics[width=\linewidth]{assets/walkthrough4/W4_initial_net.pdf}\par')
T.append(r'\begin{notebox}{Vì sao ví dụ tâm không bắt đầu bằng bốn viên rời?}'+
         'Trong khối xáo có chủ ý này, nhiều ô tâm đã đúng nhưng chưa mặt nào đủ bốn ô. Ta dùng một chu trình sửa ô sai, đổi cách cầm để tái sử dụng cùng kỹ năng. Đây là đường hoàn chỉnh của ví dụ, không khẳng định mọi khối xáo đều có sẵn thế thuận lợi này. Phần ghép thanh và các nhánh khác nằm ở hộp công cụ sau hành trình.'+r'\end{notebox}')
T.append(r'\begin{tabularx}{\linewidth}{@{}lX@{}}\toprule Nhóm mốc & Kết quả phải đạt\\\midrule Tâm1--5 & $0\to1\to2\to3\to4\to6$ tâm hoàn chỉnh.\\ Cạnh6--10 & $0\to1\to4\to7\to10\to12$ cặp; có cặp phụ thuận lợi trong ví dụ.\\ Mốc11--15 & Cross trắng, góc trắng, cạnh giữa, OLL parity, PLL parity, hoàn tất.\\\bottomrule\end{tabularx}')
for st,out in zip(D['stages'],stage_outputs):
    sid=st['id'];num=st['index']+1;nar=NARR[sid]
    T.append(r'\clearpage\section{Mốc '+str(num)+': '+esc(st['title'])+'}')
    T.append(r'\textbf{Nhìn và xác định việc đang làm.} '+esc(st['recognize'])+r'\par')
    T.append(r'\textbf{Quan sát trong khung làm việc.} '+esc(nar['look'])+r'\par')
    T.append(r'\textbf{Định vị chính xác.} '+esc(st['find'])+r'\par')
    if st['workingFrameMoves']:
        T.append(r'\textbf{Thế cầm của sơ đồ tìm mảnh:} đã làm '+r'\alg{'+' '.join(st['workingFrameMoves'])+r'} từ đầu mốc. Chuỗi hình thao tác bên dưới vẫn bắt đầu trước các nước chuẩn bị này.\par')
    else:T.append(r'\textbf{Thế cầm của sơ đồ tìm mảnh:} chính là trạng thái đầu mốc, chưa thêm nước chuẩn bị.\par')
    T.append(r'\noindent\includegraphics[width=.88\linewidth]{assets/walkthrough4/'+sid+r'_working.pdf}\par')
    T.append(r'\textbf{Vì sao chọn thao tác này?} '+esc(nar['why'])+r'\par')
    T.append(r'\textbf{Quyết định.} '+esc(nar['decision'])+r'\par')
    T.append(r'\textbf{Điều phải giữ.} '+esc(st['preserve'])+r'\par')
    if sid=='W4-10':T.append(r'Ở mốc này, \alg{R} nâng cánh lên tầng U nên \alg{U} giữa chuỗi có tác dụng trực tiếp. Bảng giải thích từng nước ở trang~\pageref{sec:l2e-reasons}; \alg{2U} chỉ một lát trong, không phải hai tầng.\par')
    T.append(r'\textbf{Làm theo từng cụm:}\par')
    for group in st['groups']:
        T.append(r'\noindent '+esc(group['label'])+': '+r'\alg{'+group['algorithm']+r'}\par')
    check_text=r'\begin{checkpointbox}{Kiểm tra, rồi mới đi tiếp}'+esc(nar['check'])+r'\par\textbf{Tiếp theo:} '+esc(nar['next']).rstrip('.')+r'.\end{checkpointbox}'
    for k,name in enumerate(out['sequenceParts']):
        last=k==len(out['sequenceParts'])-1
        T.append(r'\par\medskip\noindent\begin{minipage}{\linewidth}\centering\includegraphics[width=\linewidth]{assets/walkthrough4/'+name+r'}\par\small\textit{Mốc '+str(num)+', dãy '+str(k+1)+'/'+str(len(out['sequenceParts']))+r'. Mỗi khung là trước nước ghi trên khung; riêng khung KIỂM MỐC là sau trọn mốc.}')
        if last:T.append(r'\par\normalsize\raggedright '+check_text)
        T.append(r'\end{minipage}\par\medskip')
T.append(r'\clearpage\subsection*{Chuỗi tạo đúng khối xáo của ví dụ}')
T.append('Chỉ cần phần này nếu muốn tái tạo trên cube thật. Bắt đầu từ khối đã giải, U vàng/F xanh lá/R cam. Làm toàn bộ chuỗi dưới đây, rồi bắt đầu mốc1. Không phải scramble ngẫu nhiên và không dùng để đo thành tích.')
for i in range(0,len(D['scrambleAlgorithm'].split()),15):T.append(r'\noindent\alg{'+' '.join(D['scrambleAlgorithm'].split()[i:i+15])+r'}\par')
(ROOT/'chapters/walkthrough4_steps.tex').write_text('\n\n'.join(T))
(ROOT/'qa/walkthrough4_print.json').write_text(json.dumps({'source_sha256':hashlib.sha256((ROOT/'data/walkthrough4.json').read_bytes()).hexdigest(),'frames_replayed_and_face_matrices_equal':len(states),'all_states_legal':True,'final_solved':True,'stages':stage_outputs},ensure_ascii=False,indent=2))
print('Rendered15 stages,126 states; face matrices and final state verified.')
