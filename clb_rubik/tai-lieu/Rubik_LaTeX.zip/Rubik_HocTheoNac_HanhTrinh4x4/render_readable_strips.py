"""Generate readable 4-column sequences from the exact shared state manifest.
Run from this folder. Requires numpy/matplotlib and the bundled render toolkit.
Never infers the case from an inverse unless it matches the captured setup.
"""
from pathlib import Path
import sys,json,math,re,hashlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'render_toolkit'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from validated_cube import Cube
import draw_figures as df
from visual_sequences import cube_draw
DATA=json.loads((ROOT/'data/cube_cases.json').read_text())
by_prefix={c['prefix']:c for c in DATA['cases']}
original_marks=df.add_view_marks
def readable_marks(ax,*args,**kwargs):
    kwargs['fontsize']=10.5
    original_marks(ax,*args,**kwargs)
    for t in ax.texts:
        if t.get_text().startswith('Nhìn '):t.set_fontsize(11.5)
df.add_view_marks=readable_marks
prefixes=set()
for p in (ROOT/'chapters').glob('*.tex'):
    prefixes.update(re.findall(r'\\stripfig\{([^}]+)\}',p.read_text()))
out=ROOT/'assets';report=[]
for prefix in sorted(prefixes):
    case=by_prefix[prefix];c=Cube(case['n']).apply(case['setupAlgorithm'])
    assert c.validate()['passed']
    states=[c.copy()]
    for move in case['moves']:
        c.move(move);states.append(c.copy())
    for st,fr in zip(states,case['frames']):
        assert all(st.matrix(f)==fr['state']['faces'][f] for f in 'URFDLB')
    parts=[]
    for part,start in enumerate(range(0,len(states),8),1):
        selected=states[start:start+8];cols=min(4,len(selected));rows=math.ceil(len(selected)/cols)
        # Keep all four columns at the same physical scale, including a short last row.
        cols=4
        fig,axs=plt.subplots(rows,cols,figsize=(9.4,3.10*rows),squeeze=False)
        for j,ax in enumerate(axs.ravel()):
            if j>=len(selected):ax.axis('off');continue
            idx=start+j;fr=case['frames'][idx];move=case['moves'][idx] if idx<len(case['moves']) else None
            cube_draw(ax,selected[j],move=move)
            ax.set_title(f'{idx+1:02d}  {move}' if move else f'{idx+1:02d}  KẾT QUẢ',fontsize=16 if move else 13,fontweight='bold',color=df.INK,pad=4)
            note=fr.get('sourceCaption') or fr.get('quickCaption') or 'Kiểm tra kết quả'
            if not move:note='Kiểm tra kết quả'
            ax.text(.5,-.025,note,transform=ax.transAxes,ha='center',va='top',fontsize=12.5,color=df.TEAL,linespacing=1.1,clip_on=False)
        fig.subplots_adjust(left=.02,right=.98,wspace=.10,hspace=.37,top=1-.36/(3.10*rows),bottom=.50/(3.10*rows))
        name=f'{prefix}_readable_{part}.pdf';fig.savefig(out/name,bbox_inches=None,facecolor='white');plt.close(fig);parts.append(name)
    fragment=[]
    for i,name in enumerate(parts):
        fragment.append(r'\par\medskip\noindent\begin{minipage}{\linewidth}\centering')
        fragment.append(r'\includegraphics[width=\linewidth]{assets/'+name+'}')
        if i==0:fragment.append(r'\captionof{figure}{\textbf{Dãy thao tác.} \stripcaption}')
        else:fragment.append(r'\par\small\textit{Tiếp dãy thao tác: phần '+str(i+1)+'/'+str(len(parts))+r'. Giữ thứ tự số khung.}')
        fragment.append(r'\end{minipage}\par\medskip')
    (out/(prefix+'_readable.tex')).write_text('\n'.join(fragment))
    report.append({'case_id':case['id'],'prefix':prefix,'frames':len(states),'files':parts,'facesMatchSharedManifest':True,'columns':4,'maxFramesPerPart':8,'faceFontAt174mm_pt':10.5*174/25.4/9.4,'cameraFontAt174mm_pt':11.5*174/25.4/9.4})
(ROOT/'qa/readable_strip_qa.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Rendered',len(report),'sequences;',sum(len(x['files']) for x in report),'parts; exact frame equality passed.')
