"""Rebuild three vector figures with explicit notation and separated labels."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'render_toolkit'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from validated_cube import Cube
import draw_figures as df
from matplotlib.patches import Circle
OUT=ROOT/'assets'
def save(fig,name):
 fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',pad_inches=.06,facecolor='white');plt.close(fig)
# Anatomy is explicitly a goal-only schematic, not a complete physical state.
fig,axs=plt.subplots(1,2,figsize=(8.2,3.8))
for ax,n in zip(axs,[4,5]):
 h=n-1
 def keep(s):return (s.normal==(0,0,1) and abs(s.pos[0])<h and abs(s.pos[1])<h) or (s.pos[1]==h and s.pos[2]==h and abs(s.pos[0])<h)
 df.draw_cube(ax,Cube(n),title=f'{n}×{n}',gray=keep,highlight=keep,view_marks=False)
 df.add_view_marks(ax,footer=False)
 ax.text(0,-1.82,f'Tâm {n-2}×{n-2} · cạnh {n-2} viên',ha='center',fontsize=10,color=df.INK)
 ax.text(0,-2.15,'Sơ đồ mục tiêu: tâm F và cạnh UF',ha='center',fontsize=8.5,color=df.INK)
 ax.set_ylim(-2.35,1.85)
save(fig,'big_anatomy')
fig,axs=plt.subplots(2,3,figsize=(8.8,5.8))
for ax,(n,m,t) in zip(axs.ravel(),[(4,'R','Lớp ngoài'),(4,'Rw','Hai lớp phải'),(4,'2R','Một lớp trong'),(4,'U','Chỉ lớp trên'),(4,'Uw','Hai lớp trên'),(4,"2U'",'Chỉ lớp trong thứ hai từ U')]):df.draw_cube(ax,Cube(n),move=m,title=m+' · '+t)
fig.subplots_adjust(wspace=.08,hspace=.25);save(fig,'big_turns')
c=next(x for x in json.loads((ROOT/'data/cube_cases.json').read_text())['cases'] if x['id']=='B4-6')
a=Cube(4).apply(c['setupAlgorithm']);b=a.copy().apply(c['algorithm'])
for st,ref in [(a,c['initialState']),(b,c['finalState'])]:
 assert st.validate()['passed']
 assert all(st.matrix(f)==ref['faces'][f] for f in 'URFDLB')
fig,axs=plt.subplots(1,2,figsize=(8.2,3.8))
for ax,st,title in zip(axs,[a,b],['Trước: hai cánh A ở dưới','Sau: cặp A ở FL, cặp B ở FR']):
 df.draw_cube(ax,st,title=title)
 for side in [-3,3]:
  for y in [-1,1]:
   ss=[t for t in st.stickers if t.pos==(side,y,3)]
   front=next(t for t in ss if t.normal==(0,0,1))
   other=next(t for t in ss if t.normal!=(0,0,1))
   label='A' if other.color=='L' else 'B'
   xy=(np.array(front.pos)/4+np.array(front.normal)/4)@df.projection()[0].T
   ax.text(*xy,label,ha='center',va='center',fontsize=9,fontweight='bold',color=df.INK,bbox={'boxstyle':'circle,pad=.1','fc':'white','ec':df.INK,'lw':.6},zorder=10)
 ax.text(0,-1.82,'A = xanh lá–đỏ; B = xanh lá–cam',ha='center',fontsize=8.5,color=df.INK)
 ax.set_ylim(-2.35,1.85)
 # Camera footer moves below the label, never overlaps.
 for t in ax.texts:
  if t.get_text().startswith('Nhìn '):t.set_position((.5,-.06))
save(fig,'pair4_lasttwo')
(ROOT/'qa/clarity_figures.json').write_text(json.dumps({'big_anatomy':'goal-only schematic, separate labels','big_turns':'all six notation examples are 4x4; U,2U,Uw explicit','pair4_lasttwo':'full-color exact B4-6 initial/final states; all matrices equal','state_validation':True},ensure_ascii=False,indent=2))
