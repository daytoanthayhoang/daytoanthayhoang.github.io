RUBIK 3x3 VÀ 4x4: HỌC THEO NẤC
Bản hành trình liên tục và nâng cấp tập trung, ngày 14/11/2026.

1. Nội dung
- Đi từ cách từng tầng đang quen ở khoảng 45–55 giây; giữ đường lui, không buộc đổi ngay sang một bộ thuật toán lớn.
- Cross trực tiếp, F2L trực giác, tuyến tầng cuối chuyển tiếp, thực hành nhận dạng, lộ trình hướng tới sub20 rồi sub10.
- 4x4: một ví dụ liên tục 15 chặng, 125 nước, từ khối xáo có chủ ý tới hoàn chỉnh; tìm viên, giải thích lựa chọn, thao tác, kiểm và bước tiếp theo.
- Hộp công cụ: tâm, ghép cạnh, hai cạnh cuối, parity và giới thiệu chuyển dần sang Yau.
- Phân biệt kết quả một lượt, ao5/ao12, số đo cá nhân và thống kê thành tích WCA.
- Bộ Rubik: Hiểu để nhớ 2.1 và bản tra nhanh cũ được giữ riêng, không bị ghi đè.

2. Biên dịch
Cài một bản TeX Live hoặc MiKTeX đầy đủ; chạy hai lần:
  xelatex Rubik_HocTheoNac.tex
  xelatex Rubik_HocTheoNac.tex
Giữ rubikbook.sty, thư mục chapters và assets cạnh tệp .tex.
Các hình PDF vector đã được đóng gói. Không cần Python hay mạng để dựng PDF từ LaTeX.

3. Màu và góc nhìn
Thế chuẩn: U vàng, D trắng, F xanh lá, R cam, L đỏ, B xanh dương.
Tên mặt là vị trí, không phải màu. Sau xoay cả khối, màu tâm đổi vị trí.
Các camera U–F–L hoặc U–B–R chỉ để thấy viên, không tự thêm nước xoay cube.
Màu xám chỉ còn ở sơ đồ mục tiêu được chú thích rõ; các ca Sune/parity đã dùng đủ màu thật.
Không thay sơ đồ màu bằng cách tráo riêng hai màu. Nếu cube thật khác, phải đối chiếu toàn bộ các góc và quan hệ màu.

4. Dữ liệu dùng chung
data/cube_cases.json chứa 50 ca minh họa đã kiểm từ bộ gốc, gồm cả ca2x2 và 5x5 dùng cho bản web; bản PDF tập trung chỉ dùng phần phù hợp3x3/4x4.
Mỗi ca có trạng thái đầu, các frame, nước xoay, caption, nhóm thao tác, góc nhìn và mục tiêu kiểm tra.
render_readable_strips.py dùng dữ liệu này để dựng dãy4 cột. Công thức2R chỉ lớp trong; Rw là 2 lớp.
Để dựng lại các dãy này cần Python với numpy/matplotlib; các module cần thiết ở render_toolkit.
Tệp dữ liệu không khẳng định mọi ca đều kết thúc solved trong ứng dụng thật. Đọc mục tiêu/predicate của từng ca.

data/walkthrough4.json là timeline liên tục 126 trạng thái, không phải playlist các ca rời. Dùng cùng dữ liệu trên web; các stage/predicate chỉ rõ điểm cần kiểm. Đây là scramble sư phạm có chủ ý, không ngẫu nhiên và không đại diện mọi ca.
data/walkthrough4_narrative.json gắn lời dẫn Việt vào đúng stage. data/b4_6_move_explanation.json giải thích đủ chín nước ghép hai cạnh cuối, ký hiệu 2U/Uw và biến thể.
build_walkthrough_chapter.py tạo hình vector/chương tương ứng từ manifest, không đổi màu để ép kết quả.

5. Phạm vi kiểm tra
Xem Verification_Summary.txt. Kiểm mô phỏng không thay thế việc nhìn cube thật và kiểm hình đã xuất. Bản nâng cấp làm rõ góc nhìn, màu, trạng thái ca tập và tăng cỡ chữ trên dãy hình; không tự khẳng định mọi hình của toàn bộ sách 10 loại đã được kiểm lại.
