"""Print-only derivative. Never changes the locked branch manifest or earlier book."""
from pathlib import Path
import json,sys,hashlib,math,argparse
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'render_toolkit'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle
import numpy as np
from validated_cube import Cube
import draw_figures as df
from visual_sequences import cube_draw,cube_camera,cube_move_note
ap=argparse.ArgumentParser();ap.add_argument('--text-only',action='store_true');ap.add_argument('--focus-only',action='store_true');args=ap.parse_args()
P=ROOT/'data/branches5.json';D=json.loads(P.read_text());SHA=hashlib.sha256(P.read_bytes()).hexdigest()
assert SHA=='41debc4f50534f884d0696de7a853d6dd0737182cbcaf58bf3df504a6535e83f'
OUT=ROOT/'assets';OUT.mkdir(exist_ok=True)
original_marks=df.add_view_marks
def readable_marks(ax,*a,**kw):
 kw['fontsize']=10.5;original_marks(ax,*a,**kw)
 for t in ax.texts:
  if t.get_text().startswith('Nhìn '):t.set_fontsize(11.5)
df.add_view_marks=readable_marks
COL=df.COL;INK=df.INK
AB={'U':'V','D':'T','F':'XL','R':'C','L':'Đ','B':'XD'}
NAMES={k:v['nameVi'] for k,v in D['colors'].items()}
def esc(s):
 return str(s).replace('\\',r'\textbackslash{}').replace('&',r'\&').replace('%',r'\%').replace('#',r'\#').replace('_',r'\_').replace('→',r'$\to$').replace('↔',r'$\leftrightarrow$').replace('–','-')
def alg(s):return r'\alg{'+s+'}'
def pic(name,width='\\linewidth'):
 return r'\noindent\includegraphics[width='+width+']{assets/'+name+r'}\par'
def net(c,file,ids=()):
 if args.text_only or args.focus_only:assert (OUT/file).exists();return
 fig,ax=plt.subplots(figsize=(9.4,6.0));layout={'U':(1,2),'L':(0,1),'F':(1,1),'R':(2,1),'B':(3,1),'D':(1,0)};n=5;sx,sy=5.65,5.9
 for face,(col,row) in layout.items():
  x,y=col*sx,row*sy
  for r in range(n):
   for co in range(n):
    st=c.face(face)[r*n+co];xx=x+co;yy=y+n-1-r
    ax.add_patch(Rectangle((xx,yy),.96,.96,facecolor=COL[st.color],edgecolor=INK,lw=.65))
    if 1<=r<=3 and 1<=co<=3:ax.add_patch(Rectangle((xx+.03,yy+.03),.90,.90,fill=False,edgecolor=INK,lw=1.05))
    if c.stickers.index(st) in ids:ax.add_patch(Circle((xx+.48,yy+.48),.29,fill=False,ec='black',lw=1.5))
  ax.text(x+2.95 if face in ('F','D') else x+2.45,y+5.27,face,ha='center',va='center',fontsize=15,fontweight='bold',color=INK)
  for k in range(n):
   ax.text(x-.18,y+4.48-k,str(k+1),ha='right',va='center',fontsize=10.5,color=INK)
   ax.text(x+k+.48,y-.15,str(k+1),ha='center',va='top',fontsize=10.5,color=INK)
 ax.set_aspect('equal');ax.set_xlim(-.65,3*sx+5.1);ax.set_ylim(-.45,2*sy+5.6);ax.axis('off')
 fig.subplots_adjust(left=.01,right=.99,top=.99,bottom=.01);fig.savefig(OUT/file,bbox_inches='tight',pad_inches=.02,facecolor='white');plt.close(fig)
def locs(c):
 out={}
 for face in 'URFDLB':
  for i,s in enumerate(c.face(face)):out[c.stickers.index(s)]=(face,i//5+1,i%5+1)
 return out
def focus(c,f,edges,file,pieces):
 if args.text_only:assert (OUT/file).exists();return
 fig,axs=plt.subplots(1,3,figsize=(9.4,2.3),squeeze=False);LC=locs(c);codes={tuple(sorted(p['stickerIds'])):'P'+str(i+1) for i,p in enumerate(pieces)}
 for ax in axs.ravel():ax.axis('off')
 used=axs.ravel()[1:2] if len(edges)==1 else axs.ravel()[:len(edges)]
 for ax,edge in zip(used,edges):
  ed=f['metrics']['edgeDetails'][edge]
  status='ĐÃ GHÉP' if ed['paired'] else ('NGƯỢC GIỮA' if ed['residual'] else f"LẠC {ed['wrongIdentityWings']} CÁNH")
  ax.text(1.55,3.55,edge+' · '+status,ha='center',fontsize=12.5,fontweight='bold',color=INK)
  fs=list(edge)
  if edge in ('FL','FR'):fs=['F',edge[1]]
  for ri,row in enumerate(ed['rows']):
   y=2.4-ri*.9
   lab=('trên','giữa','dưới')[ri] if edge in ('FL','FR','BR','BL') else ('cánh','giữa','cánh')[ri]
   code=codes.get(tuple(sorted(row['stickerIds'])),'')
   ax.text(-.02,y+.28,lab+('\n'+code if code else ''),ha='right',va='center',fontsize=10.2,color=INK,linespacing=1.05)
   for j,face in enumerate(fs):
    color=row['mapping'][face];x=.12+j*1.48
    ax.add_patch(Rectangle((x,y),1.35,.59,fc=COL[color],ec=INK,lw=.8))
    id=next(i for i in row['stickerIds'] if LC[i][0]==face);_,r,co=LC[id]
    ax.text(x+.675,y+.32,AB[color],ha='center',va='center',fontsize=10.5,fontweight='bold',color=INK)
    ax.text(x+.675,y-.12,f'{face}({r},{co})',ha='center',va='center',fontsize=10.5,color=INK)
  ax.set_xlim(-.65,3.35);ax.set_ylim(-.28,3.95);ax.axis('off')
 fig.subplots_adjust(left=.02,right=.99,bottom=.01,top=.99,wspace=.20)
 fig.savefig(OUT/file,facecolor='white');plt.close(fig)
def sequence(C,states,st,indices,file):
 if args.text_only or args.focus_only:assert (OUT/file).exists();return
 rows=math.ceil(len(indices)/3);fig,axs=plt.subplots(rows,3,figsize=(9.4,3.15*rows),squeeze=False)
 for j,ax in enumerate(axs.ravel()):
  if j>=len(indices):ax.axis('off');continue
  idx=indices[j];c=states[idx];move=C['moves'][idx] if idx<st['endExclusive'] else None
  cube_draw(ax,c,move=move);cam,_=cube_camera(move);pm,view=df.projection(cam)
  for k in st['highlightIds']:
   s=c.stickers[k]
   if np.dot(s.normal,view)>1e-5:
    center=np.array(s.pos)/5+np.array(s.normal)/5;xy=center@pm.T
    ax.add_patch(Circle(xy,.42/5,fill=False,ec='black',lw=1.05,zorder=10))
  no=idx+1;title=f'{no:02d}  {move}' if move else f'S{idx}  KIỂM'
  ax.set_title(title,fontsize=16,fontweight='bold',color=INK,pad=4)
  note=cube_move_note(move) if move else 'Sau trọn bước\nĐọc hai mặt'
  if move=="3Rw'":note='BA LỚP PHẢI\nNgược 90° (Q: nước 8)'
  ax.text(.5,-.025,note,transform=ax.transAxes,ha='center',va='top',fontsize=12.5,color=df.TEAL,linespacing=1.1,clip_on=False)
 h=3.15*rows;fig.subplots_adjust(left=.02,right=.98,wspace=.12,hspace=.37,top=1-.36/h,bottom=.50/h)
 fig.savefig(OUT/file,facecolor='white');plt.close(fig)

BENEFITS={
'BR5-01':'Cặp giữa-dưới đã tốt và cánh cần tìm đã ở FL trên. Ta nhìn rõ vì sao chỉ cắt lát trên; kết quả 9→12 là thuận lợi riêng của thế chuẩn bị này.',
'BR5-02':'Cặp giữa-trên đã tốt và cánh còn thiếu đã ở FL dưới. So với ca 01, chỉ thay lát cần làm; không động vào phần đã khớp.',
'BR5-03':'Cả hai cánh cần dùng đã ở hai đầu FL, cùng đúng hướng để ghép. UB chưa ghép làm chỗ thay thế nên có thể cất bộ mới rồi trả lát.',
'BR5-04':'Bắt đầu từ khối đã giải để dễ theo dõi ba mảnh của FR. Đây là thí nghiệm công cụ T, không phải lời khuyên xoay một khối đã giải.',
'BR5-05':'Hai cánh lạc đã ở đúng ô chéo của C. Hướng hai sticker cũng phù hợp, nên C khép ngay cả hai nhóm: 10→12.',
'BR5-06':'Vị trí hai cánh lạc giống ca 05 nhưng hướng cánh FR trên khác. Cùng một C chỉ đạt 11 bộ ba; ví dụ cho thấy vì sao phải kiểm lại.',
'BR5-07':'Chỉ FL và FR chưa ghép; mười bộ còn lại đã tốt. Hai lần C được ngăn bằng hai bước nhận dạng và chuẩn bị, nhìn thấy rõ công dụng của T.',
'BR5-08':'Lỗi đã được đặt sẵn tại UF, cả ba mảnh cùng cặp màu. Chỉ còn kiểm hướng và làm Q, không phải đi tìm cánh ở nơi khác.',
'BR5-09':'Chỉ FL và FR còn lỗi hướng, không còn cánh sai danh tính. Sửa từng nhóm cho ta hai điểm đếm rõ ràng: 10→11→12.'}
SHORT={
'BR5-01':'Thêm cánh trên','BR5-02':'Thêm cánh dưới','BR5-03':'Thêm cả hai cánh','BR5-04':'Dùng T đổi cách trình bày',
'BR5-05':'Một cánh lạc: C khép ngay','BR5-06':'Một cánh lạc: còn lỗi hướng','BR5-07':'Hai cánh lạc: nhận dạng lại',
'BR5-08':'Một nhóm ngược viên giữa','BR5-09':'Hai nhóm ngược viên giữa'}
OV={
'BR5-06-S2':{'title':'Danh tính đã đủ, sửa hướng FR','recognize':'Sau C, FL đã ghép. FR không còn cánh sai cặp màu, nhưng hai cánh cùng ngược viên giữa. Đủ nhóm màu chưa phải đủ bộ ba.','decision':"Xoay cả khối z' để FR lên UF, làm Q rồi z trả cách cầm. Q được chọn vì lỗi còn lại là hướng, không phải danh tính.",'next':'Đủ sáu tâm và mười hai bộ ba đúng hướng. Chuyển sang giải lớp ngoài như 3×3.'},
'BR5-07-S1':{'title':'C lần đầu: trả một cánh cho mỗi nhóm','decision':'C chỉ đổi một cặp cánh chéo. Hai nhóm đang lạc cả hai cánh nên chưa thể xong sau một lần.','next':'Sau C, cánh lạc ở FL dưới và FR trên. Không lặp C ngay: hai ô ấy chưa phải FL trên/FR dưới.'},
'BR5-07-S2':{'title':'Đưa cánh lạc FL từ dưới lên trên','recognize':'Dùng đúng kết quả C đầu: FL dưới là cánh lạc, FR trên là cánh lạc còn lại. C cần FL trên, nên chuẩn bị phía trái trước.','decision':"Làm y' T y. y' đưa cạnh FL vào cửa sổ FR, T đổi hai đầu và hướng viên giữa, y trả khung cầm. Sau đó đọc lại FL.",'next':'Cánh lạc FL đã ở trên; FR vẫn còn cánh lạc ở trên. Chuẩn bị FR ở bước tiếp, không làm lại C đầu.'},
'BR5-07-S3':{'title':'Đưa cánh lạc FR từ trên xuống dưới','recognize':'FL trên đã sẵn sàng. Ở FR, cánh lạc vẫn nằm trên, còn C sẽ đổi cánh dưới.','decision':'Làm T ngay tại FR. T đưa cánh lạc xuống dưới và cũng đổi hướng viên giữa, vì vậy phải đọc cả hai mặt lần nữa.','next':'Hai cánh lạc đã ở đúng ô chéo FL trên/FR dưới. Bây giờ mới dùng C lần cuối.'},
'BR5-07-S4':{'title':'C lần cuối: khép hai bộ ba','recognize':'Sau hai bước T, cánh B ở FL trên và cánh A ở FR dưới. So với đầu ca, mỗi nhóm chỉ còn một cánh sai danh tính.','decision':'Làm C để trao lại đúng hai cánh. Hướng ở thế này phù hợp nên hai nhóm khép đồng thời.','next':'Reduction hoàn tất: sáu tâm và mười hai bộ ba. Khối này chưa solved toàn cube; tiếp tục lớp ngoài như 3×3.'},
'BR5-09-S1':{'title':'Sửa FR, giữ lại việc kiểm FL','decision':"FL và FR đều không có cánh sai danh tính, nên không dùng C. Đưa FR lên UF bằng z', làm Q rồi z; chưa động đến lỗi FL.",'next':'Sau sửa FR chỉ đạt 11 bộ ba. FL vẫn ngược viên giữa; tiếp tục ngay từ trạng thái này.'},
'BR5-09-S2':{'title':'Sửa nốt FL sau khi đếm lại','recognize':'Kết quả bước trước có FR đã ghép và FL còn hai cánh ngược viên giữa. Mười một bộ ba khác đang tốt.','decision':"Lần này dùng z đưa FL lên UF, Q sửa đúng nhóm đã chọn, rồi z' trả cách cầm. Đừng lặp cách cầm của lần sửa FR.",'next':'Đếm lại đủ 12 bộ ba và 6 tâm. Reduction đã hoàn tất; giải lớp ngoài như 3×3.'}}
# Exact coordinate names and face colors above come from the locked frame itself.
def edges_for(C,st):
 if C['id'] in ('BR5-01','BR5-02','BR5-03'):return ['FL','FR','UB']
 if C['id']=='BR5-04':return ['FR']
 if C['id']=='BR5-08':return ['UF']
 return ['FL','FR']
def end_edges(C,st):
 if C['id'] in ('BR5-01','BR5-02','BR5-03'):return ['UF','FL','FR']
 return edges_for(C,st)
def next_text(C,st):
 if st['id'] in OV and 'next' in OV[st['id']]:return OV[st['id']]['next']
 if C['id']=='BR5-04':return 'T đã đổi cách trình bày FR; cả khối chưa solved. Học tác dụng này rồi xem ca 07 để dùng T có mục đích.'
 if st['endExclusive']<len(C['moves']):return 'Tiếp tục bước sau từ chính trạng thái này, không xáo lại và không nạp một ví dụ khác.'
 return 'Đủ sáu tâm và mười hai bộ ba đúng hướng thì dùng lớp ngoài để giải như 3×3. Không thêm PLL parity của 4×4.'
def target_text(C,st):
 ps=st['selectedPieces']
 def desc(p):
  return ' / '.join(f"{s['face']}({s['row']},{s['col']}) {s['colorVi']}" for s in p['atWorkingStart']['stickers'])
 if C['id'] in ('BR5-01','BR5-02','BR5-03'):
  mid=next(p for p in ps if p['role']=='viên giữa FR')
  take=[ps[0]] if C['id']=='BR5-01' else ([ps[2]] if C['id']=='BR5-02' else [ps[0],ps[2]])
  return 'Ghép về viên giữa FR: '+desc(mid)+'. Cánh cần thêm: '+'; '.join(desc(p) for p in take)+'.'
 out=[p['role']+': '+desc(p) for p in ps if 'giữa' in p['role']]
 if st['kind']=='turn':
  return st['find']+' Theo mã viên: P1/P3 là hai cánh, P2 là viên giữa. T đổi hai đầu và hướng P2; chưa kết luận đã ghép nếu còn cánh sai danh tính.'
 finding=st['find'].replace('hai cánh lạc cần đổi','hai cánh được chọn để đổi ở bước này') if st['id']=='BR5-07-S1' else st['find']
 return finding+' Màu tại mốc: '+'; '.join(out)+'.'

def group_reason(g):
 label=g['label']
 if label=='Ghép cánh vào viên giữa':return 'Đưa đúng cánh còn thiếu tới FR; quan sát đủ hai màu trước khi cất.'
 if label=='Cất bộ ba lên UF':return 'Đưa bộ mới ra khỏi lát sắp trả; UB chưa ghép là cạnh thay thế.'
 if label=='Trả đúng các lát đã dùng':return 'Trả tâm; giữ bộ vừa cất ngoài vùng lát đang hồi lại.'
 if label.startswith('Mở lát'):return 'Đưa hai ô chéo vào chuỗi T, không thay bằng Uw.'
 if 'Cụm đầu T' in label:return 'Nửa đầu của T; chưa đánh giá kết quả khi công cụ chưa trọn.'
 if 'Cụm cuối T' in label:return 'Hoàn tất tác dụng của T; viên giữa FR cũng đổi hướng.'
 if label=='Trả 2U và nhận dạng lại':return 'Khôi phục lát rồi mới kiểm danh tính và hướng.'
 if 'Đưa cạnh FL' in label:return 'Đổi cách cầm để dùng cùng công cụ T tại FR.'
 if 'Đưa cạnh lỗi' in label:return 'Đặt đúng nhóm lỗi ở cửa sổ UF của Q.'
 if 'Mở rộng' in label:return 'Mở các lớp làm việc; x là xoay cả khối, không đổi riêng màu.'
 if 'Cụm phải' in label:return "Đúng bề rộng lớp: nước 8 của Q là 3Rw', ba lớp bên phải."
 if 'Cụm trái' in label:return 'Tiếp tục cân lại các lớp; chưa dừng giữa Q.'
 if 'Kết thúc Q' in label:return 'Hoàn tất sửa hướng và khôi phục các phần phải giữ.'
 if 'Trả cách cầm' in label:return 'Trở lại khung cầm trước bước để đếm và so hai cạnh.'
 return 'Làm trọn cụm rồi so trạng thái kế tiếp.'

qa={'source_sha256':SHA,'case_count':9,'unique_frames_verified':0,'rendered_sequence_panels':0,'stages':[],'cases':[]}
T=[]
for ci,C in enumerate(D['cases'],1):
 c=Cube(5).apply(C['scrambleAlgorithm']);states=[c.copy()]
 for m in C['moves']:c.move(m);states.append(c.copy())
 assert len(states)==len(C['frames'])
 for c,f in zip(states,C['frames']):
  assert all(c.matrix(face)==f['state']['faces'][face] for face in 'URFDLB')
  assert all(tuple(s.pos)==tuple(t['pos']) and tuple(s.normal)==tuple(t['normal']) and tuple(s.tangent)==tuple(t['tangent']) and s.color==t['color'] for s,t in zip(c.stickers,f['state']['stickers']))
 qa['unique_frames_verified']+=len(states)
 qa['cases'].append({'id':C['id'],'frames':len(states),'final_solved':states[-1].is_uniform(),'checkpoint_paired_counts':C['checkpointPairedCounts']})
 for si,st in enumerate(C['stages'],1):
  sid=st['id'];ov=OV.get(sid,{});work=st['workingStateIndex'];es=edges_for(C,st);after=st['endExclusive']
  net(states[work],sid+'_net.pdf',st['highlightIds'])
  focus(states[st['start']],C['frames'][st['start']],es,sid+'_before.pdf',st['selectedPieces'])
  focus(states[after],C['frames'][after],end_edges(C,st),sid+'_after.pdf',st['selectedPieces'])
  T.append(r'\clearpage')
  if si==1:
   T += [r'\section*{'+C['id']+' · '+SHORT[C['id']]+'}',r'\addcontentsline{toc}{section}{'+C['id']+' · '+SHORT[C['id']]+'}',
    r'{\small\sffamily\color{teal}VÍ DỤ ĐỘC LẬP '+str(ci)+r'/9 \quad | \quad '+str(len(C['moves']))+r' NƯỚC \quad | \quad BỘ BA: '+esc('→'.join(map(str,C['checkpointPairedCounts'])))+r'}\par',
    r'\textbf{Thuận lợi của ví dụ.} '+esc(BENEFITS[C['id']])]
  else:T += [r'\section*{'+C['id']+' · Tiếp tục cùng ví dụ}',r'{\small Không reset khối. Dùng đúng kết quả của bước trước.}\par']
  title=ov.get('title',SHORT[C['id']] if len(C['stages'])==1 else st['title'])
  T += [r'\subsection*{Bước '+str(si)+'/'+str(len(C['stages']))+': '+esc(title)+'}',r'\textbf{Nhận dạng.} '+esc(ov.get('recognize',st['recognize']))]
  if st['workingFrameMoves']:
   T.append(r'{\small\textbf{Khung sáu mặt dưới đây đã qua chuẩn bị} '+alg(' '.join(st['workingFrameMoves']))+r'. Khi thao tác, vẫn bắt đầu ở nước đầu của dãy sau; không làm phần chuẩn bị hai lần.}\par')
  else:T.append(r'{\small\textbf{Khung sáu mặt:} đúng trạng thái đầu bước. Vòng đen đánh dấu các mảnh đang theo dõi.}\par')
  T += [r'\begin{center}\includegraphics[width=.76\linewidth]{assets/'+sid+r'_net.pdf}\end{center}',
        r'{\small\textbf{Đọc cạnh ở đầu bước:} mã P đi theo cùng một viên trong bước này; chữ trong ô là màu (chú giải trang 2).}\par',pic(sid+'_before.pdf'),
        r'\textbf{Quyết định và lý do.} '+esc(ov.get('decision',C['goal'] if si==1 else st['decision']))+' '+esc(st['reason']),
        r'{\small\textbf{Ô/viên mục tiêu trong khung làm việc.} '+esc(target_text(C,st))+'}']
  # All sequence panels are actual complete states, before the named move.
  indices=list(range(st['start'],after+1));nparts=math.ceil(len(indices)/6);base,extra=divmod(len(indices),nparts);parts=[];off=0
  for pidx in range(nparts):
   size=base+(pidx<extra);parts.append(indices[off:off+size]);off+=size
  for pi,part in enumerate(parts,1):
   file=f'{sid}_moves_{pi}.pdf';sequence(C,states,st,part,file);qa['rendered_sequence_panels']+=len(part)
   T += [r'\clearpage\section*{'+C['id']+' · Làm rồi kiểm}',r'{\small\sffamily\color{teal}BƯỚC '+str(si)+'/'+str(len(C['stages']))+r' \quad | \quad DÃY '+str(pi)+'/'+str(len(parts))+r'}\par',
         r'{\small Mỗi khung là \textbf{trước} nước ghi trên hình; S'+str(after)+r' là trạng thái sau trọn bước. Số nước chạy liên tục trong ca, không phải số riêng của Q.}\par']
   groups=[g for g in st['groups'] if g['start']<=part[-1] and g['endExclusive']>part[0]]
   for g in groups:
    lo=max(g['start'],part[0]);hi=min(g['endExclusive'],part[-1]+1,after)
    label=('Tiếp ' if lo>g['start'] else '')+g['label']
    T.append(r'{\small\textbf{'+esc(label)+'}: '+alg(' '.join(C['moves'][lo:hi]))+'. '+esc(group_reason(g))+r'}\par')
   T.append(pic(file))
   if pi==len(parts):
    T += [r'{\small\textbf{Soi kết quả sau trọn bước, đã trả cách cầm nếu có:}}\par',pic(sid+'_after.pdf'),
       r'\begin{checkpointbox}{Kiểm trước khi đi tiếp}'+esc(('P1 từ trên xuống dưới; P3 từ dưới lên trên. P2 vẫn ở giữa FR nhưng hai sticker đổi mặt. ' if C['id']=='BR5-04' else '')+st['check'])+r'\par\textbf{Tiếp theo:} '+esc(next_text(C,st))+r'\end{checkpointbox}']
   else:
    T.append(r'\begin{notebox}{Chưa tới điểm kiểm cuối}Làm tiếp đúng khung kế tiếp. Tâm hoặc bộ ba có thể tạm tách trong công cụ; chỉ kết luận phần phải giữ sau trọn bước.\end{notebox}')
  qa['stages'].append({'id':sid,'start':st['start'],'end':after,'working_frame':work,'parts':len(parts),'all_indices_shown':indices})
assert qa['unique_frames_verified']==163
assert [q['final_solved'] for q in qa['cases'] if q['id'] in ('BR5-04','BR5-07')]==[False,False]
(ROOT/'chapters/branches.tex').write_text('\n\n'.join(T))
(ROOT/'qa/print_verification.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
# Setup is optional practice, not a tenth case. All rows use the exact locked algorithm.
S=[r'\clearpage\section*{Tạo lại các ví dụ để thực hành}',r'\addcontentsline{toc}{section}{Tạo lại các ví dụ để thực hành}',
'Đọc sách không cần cầm khối. Nếu muốn thử, mỗi ca bắt đầu riêng từ khối đã giải, U vàng, F xanh lá, R cam. Làm chuỗi chuẩn bị của đúng ca một lần; sau đó sang bước 1 của ca ấy. Không nối chín chuỗi với nhau.',
r'\textbf{Các chuỗi sau tạo thế học mẫu, không phải scramble thi tốc độ.}']
for i,C in enumerate(D['cases']):
 if i in (5,8):S.append(r'\clearpage\section*{Tạo lại ví dụ · tiếp theo}')
 S.append(r'\subsection*{'+C['id']+' · '+SHORT[C['id']]+'}')
 ms=C['scrambleAlgorithm'].split()
 if not ms:S.append('Không cần xáo: bắt đầu ngay từ khối đã giải để quan sát công cụ T.')
 for j in range(0,len(ms),13):S.append(alg(' '.join(ms[j:j+13]))+r'\par')
S += [r'\clearpage\section*{Phạm vi, đối chiếu và kiểm bản in}',r'\addcontentsline{toc}{section}{Phạm vi, đối chiếu và kiểm bản in}',
'Phụ lục này tiếp nối phần ghép cạnh của Hành trình Rubik 5×5. Chín ca chuẩn bị độc lập, gồm 154 nước, 163 trạng thái duy nhất và 14 bước lớn. Những mốc giáp nhau có thể xuất hiện lại để người đọc giữ nhịp; không có reset giữa các bước trong cùng ca.',
'Các ca 01, 02, 03, 04, 05, 08 tái hiện nguyên trạng sáu ví dụ B5-6, B5-7, B5-5, B5-4, B5-8, B5-9 trong chương 5×5 của tài liệu Hiểu để nhớ 2.1. Ba ca 06, 07, 09 bổ sung lịch sử nước đi hợp lệ, không tô màu tùy ý.',
'Nguồn phương pháp đối chiếu:',r'\begin{itemize}',r'\item J Perm, \emph{How to Solve the 5×5}: \url{https://jperm.net/5x5}.',r'\item CubeSkills, \emph{Beginner\textquotesingle s Method for Solving the 5×5 Cube}: \url{https://cubeskills.com/uploads/pdf/tutorials/beginners-method-for-solving-the-5x5-cube.pdf}.',r'\end{itemize}',
'Các hình trong phụ lục được dựng từ trạng thái sticker đã kiểm, không sao chép hình nguồn. Mô hình Python và JavaScript độc lập đối chiếu 163 trạng thái, 24.450 bản ghi sticker; JavaScript còn tính lại 163 bộ số đo và 576 nhãn vị trí. Bản in replay lại toàn bộ trạng thái trước khi vẽ.',
r'\begin{cautionbox}{Giới hạn cần giữ}',
'Bộ này không liệt kê mọi cách đưa mảnh bất kỳ vào FL/FR/UB và không tự chọn công thức cho mọi scramble. Điều kiện phải khớp cả hai màu, hướng và khung cầm. T/C/Q có thể đổi góc hoặc tầng ngoài; không cam kết giữ F2L đã giải. BR5-04 là thí nghiệm công cụ, BR5-07 hoàn tất reduction nhưng chưa solved toàn cube.',r'\end{cautionbox}',
r'\textbf{Dấu chốt phải giữ:} '+alg("3Rw'")+r' ở nước 8 của Q là ba lớp. '+alg('2U')+' là một lát thứ hai, không phải '+alg('Uw')+'. Kiểm đối chứng đã xác nhận hai cách thay ký hiệu này không thể dùng để thay nguyên trace đang minh họa.',
'Bản biên soạn: 14/11/2026.']
(ROOT/'chapters/setup_sources.tex').write_text('\n\n'.join(S))
print(json.dumps({k:v for k,v in qa.items() if k not in ('stages','cases')},ensure_ascii=False))
