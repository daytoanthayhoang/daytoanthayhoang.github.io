RUBIK 5×5 - CHỌN NHÁNH GHÉP CẠNH CUỐI
Phụ lục độc lập của Hành trình Rubik 5×5, biên soạn ngày 14/11/2026.

Mở Rubik_5x5_ChonNhanhCanhCuoi.pdf.
Nguồn LaTeX chính: Rubik_5x5_ChonNhanhCanhCuoi.tex.
Các chương: chapters/. Hình vector: assets/.
Dữ liệu khóa và báo cáo gốc: data/. QA bản in: qa/.

9 ca độc lập, 154 nước, 163 trạng thái duy nhất, 14 bước lớn.
Bản in vẽ 168 khung thao tác vì năm mốc giữa hai bước được nhắc lại.
Mỗi ca liên tục riêng. BR5-04 và BR5-07 không solved toàn cube.
Không thay dữ liệu nhánh gốc hoặc sách Hành trình 5×5 48 trang.

Biên dịch PDF từ hình đóng sẵn (mặc định, không cần Python): ./build.sh
Dựng lại toàn bộ hình rồi biên dịch PDF: ./build.sh --regenerate
Chỉ cập nhật LaTeX khi hình đã có: ./build.sh --text-only
Chỉ vẽ lại hình soi cạnh: ./build.sh --focus-only

XeLaTeX chạy hai lần. build.sh chỉ đặt TEXMF và TEXFORMATS đặc thù
nếu xelatex.fmt của môi trường này có tồn tại. Trên máy khác, script
dùng cấu hình TeX Live hiện có. Python cần matplotlib và numpy.
Không cần mạng để dựng bản in.

Màu: U vàng, D trắng, F xanh lá, R cam, L đỏ, B xanh dương.
2U/2D là một lát thứ hai; Uw/Rw là hai lớp; 3Rw' là ba lớp.
Công thức Q giữ đúng 3Rw' ở nước thứ tám.

SHA-256 branches5.json:
41debc4f50534f884d0696de7a853d6dd0737182cbcaf58bf3df504a6535e83f

BIÊN DỊCH TEX-ONLY: KHÔNG CẦN PYTHON
Toàn bộ hình đã đóng sẵn trong assets/. Trong thư mục này, chạy:
  xelatex -interaction=nonstopmode -halt-on-error Rubik_5x5_ChonNhanhCanhCuoi.tex
  xelatex -interaction=nonstopmode -halt-on-error Rubik_5x5_ChonNhanhCanhCuoi.tex
Hoặc chạy ./build_tex_only.sh hay ./build.sh (mặc định đều không dùng Python).
TeX Live đầy đủ trên máy khác: dùng trực tiếp hai lệnh xelatex ở trên.
Không cần tạo lại hình và không cần cài Python cho đường biên dịch này.
