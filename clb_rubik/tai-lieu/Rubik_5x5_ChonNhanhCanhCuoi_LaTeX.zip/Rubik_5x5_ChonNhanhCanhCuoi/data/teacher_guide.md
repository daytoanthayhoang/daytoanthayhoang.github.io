# Chọn nhánh ghép cạnh 5×5: hỏi trước khi xoay

## Đọc hình mà không cần cầm cube

Giữ F trước, R phải, U trên. Một cạnh lớn có **hai cánh và một viên giữa**. Trên hai cạnh đứng FL/FR, cánh trên ở hàng 2, viên giữa hàng 3, cánh dưới hàng 4. Đọc đủ hai mặt của mỗi mảnh:

- FL: F(hàng,1) và L(hàng,5).
- FR: F(hàng,5) và R(hàng,1).
- UF: U(5,cột) và F(1,cột), cột 2/4 là cánh, cột 3 là viên giữa.

Màu ở viên giữa xác định danh tính cặp màu, chưa xác định vị trí đích giữa các tâm. Ví dụ bộ vàng–xanh lá có thể được cất ở nơi khác và vẫn là bộ ba tốt, miễn ba mảnh nhìn cùng màu trên mỗi mặt.

**Ba tầng kiểm:** đủ hai màu của đúng danh tính → ba mảnh cùng hướng → sáu tâm và các bộ ba cũ được khôi phục sau trọn nhóm. Cặp tạm hai mảnh chỉ là 2/3, không được tính thành một bộ ba.

## Bảng quyết định ngắn

| Nhìn thấy | Chọn nhánh | Làm gì | Kiểm trước khi đi tiếp |
|---|---|---|---|
| Giữa–dưới FR đã khớp, thiếu trên; cánh đúng ở FL trên; UB chưa ghép | BR5-01 | Chỉ thêm trên: 2U' R U R' 2U | FR đủ ba sau lát đầu, UF đủ ba sau cất; trả tâm |
| Giữa–trên FR đã khớp, thiếu dưới; cánh đúng ở FL dưới; UB chưa ghép | BR5-02 | Chỉ thêm dưới: 2D R U R' 2D' | Không động lát trên đã tốt; kiểm cả hai mặt |
| Hai cánh cùng danh tính ở FL trên/dưới; viên giữa ở FR; UB chưa ghép | BR5-03 | 2U' 2D, cất R U R', trả 2D' 2U | Sau hai lát phải có bộ ba khớp ở FR |
| Cần đổi trên/dưới hoặc hướng nhìn của **toàn bộ** cạnh | BR5-04 | T ở FR; muốn tác động FL dùng y' T y | Viên giữa cũng đổi hướng; đây không phải sửa riêng một cánh |
| Chỉ còn FL/FR; mỗi nhóm lạc một cánh | BR5-05 hoặc BR5-06 | Đặt cánh lạc ở FL trên/FR dưới, làm C | Danh tính đã đủ chưa? Hướng đã khớp chưa? Nếu còn residual, chuyển nhánh sửa hướng |
| Cả hai cánh mỗi nhóm đều thuộc nhóm kia | BR5-07 | C một lần, **nhận dạng lại**, đưa cánh lạc về hai ô chéo rồi C tiếp | Sau C đầu chỉ mới giảm hai cánh lạc xuống một ở mỗi nhóm |
| Không còn cánh sai danh tính; hai cánh cùng ngược viên giữa | BR5-08 | Đưa bộ lỗi lên UF, dùng Q | Ba mảnh liền màu trên cả hai mặt; kiểm các bộ khác và tâm |
| Hai nhóm cùng có lỗi hướng ấy | BR5-09 | Sửa một, đếm lại, rồi sửa bộ lỗi còn lại | 10→11 chưa xong; phải đạt 12 bộ ba |

Nếu không khớp điều kiện trong bảng, đừng chọn theo một mảng màu trông giống. Cần đưa đúng mảnh vào vùng làm việc rồi nhận dạng lại. Nếu tâm chưa đủ sáu, trở về phần tâm trước.

## Hai công cụ ngắn, một công thức sửa hướng

T = R U R' F R' F' R.

T đổi vị trí hai cánh trên/dưới FR và đảo viên giữa FR. T tại FL là y' T y. Nó không sửa quan hệ “cánh ngược giữa”: cả cạnh cùng bị đổi cách trình bày.

C = 2U' R U R' F R' F' R 2U = 2U' T 2U.

C đổi cánh **FL trên ↔ FR dưới**, đồng thời đảo viên giữa FR. Đây là chỗ khác cần quan sát thêm so với 4×4. Hãy dùng ký hiệu **2U** cho một lát; đừng tự thay bằng Uw và mong giữ đúng trace đang minh họa.

Q tại UF = Rw U2 x Rw U2 Rw U2 **3Rw'** U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw'.

Nước thứ tám là **ba lớp**; mọi Rw khác là hai lớp. Trước Q phải kiểm đủ ba mảnh cùng cặp màu, hai cánh ngược viên giữa. Q không biến một cánh sai danh tính thành cánh cần tìm.

## Vì sao cần hai ví dụ cho kiểu I?

BR5-05 và BR5-06 đều có cánh B lạc ở FL trên và cánh A lạc ở FR dưới. Nhưng **hướng hai sticker** khác nhau:

- BR5-05, FR trên: xanh lá ở F, cam ở R. FR giữa: cam ở F, xanh lá ở R. Sau C, cả hai nhóm khớp luôn: 10→12.
- BR5-06, FR trên và viên giữa đều có cam ở F, xanh lá ở R. C đưa đủ danh tính về FR nhưng còn hai cánh ngược viên giữa: 10→11. Bước tiếp z' đưa FR lên UF, Q sửa hướng, z trả cách cầm: 11→12.

Vì vậy không ghi “mỗi cạnh lạc một cánh → C là xong”. Ghi “C sửa danh tính → kiểm hướng → chỉ sửa residual nếu thực sự còn”. Cả hai ví dụ đều có đủ lịch sử pháp lý, không phải đổi màu minh họa tùy ý.

## Theo dõi kiểu II ở BR5-07

1. Ban đầu, hai cánh FL đều thuộc danh tính viên giữa FR và ngược lại. Chỉ FL/FR chưa ghép; mười bộ khác tốt.
2. C đầu trả về một cánh cho mỗi nhóm. Cánh lạc còn lại nằm ở **FL dưới** và **FR trên**, chưa đúng hai ô C cần.
3. y' T y đổi cách trình bày FL, đưa cánh lạc lên trên. Đọc lại viên giữa vì nó cũng đổi hướng.
4. T tại FR đưa cánh lạc xuống dưới.
5. C cuối đổi đúng hai cánh lạc. Ví dụ này đạt 12 bộ ba và sáu tâm. Góc/tầng ngoài chưa solved, hãy chuyển sang giải 3×3.

Đây là chuỗi quyết định theo trạng thái, không phải mẹo lặp một công thức dài không nhìn.

## Parity 5×5 nằm ở đâu?

Các ví dụ sửa hướng trong gói này diễn ra **trước khi ghép cạnh xong**. “Đủ ba danh tính” không có nghĩa “bộ ba đã ghép”. Khi còn hai cánh ngược viên giữa, reduction chưa hoàn chỉnh.

Sau đủ **sáu tâm + mười hai bộ ba đúng hướng**, chỉ dùng lớp ngoài để giải như 3×3. Không thêm PLL parity của 4×4. Nếu trông như một hình không thể có trên 3×3, trước hết đọc lại hai mặt của từng bộ ba và kiểm tâm/cách cầm.

Công thức T/C/Q có thể đổi trạng thái các góc và tầng ngoài. Chỉ cam kết phần đã được kiểm: tâm và các danh tính bộ ba cũ. Không hứa giữ F2L nếu người học đem dùng sau khi đã giải tầng ngoài.

## Phạm vi và nguồn

Chín ca là ví dụ chuẩn bị độc lập; trong từng ca các bước liên tục, giữa các ca có khởi đầu riêng. Không nối các ca thành một hành trình. BR5-04 là minh họa công cụ từ solved, không phải lời khuyên xoay một cube đã giải. BR5-07 hoàn tất reduction nhưng không hoàn tất cube.

Những cách đưa mảnh bất kỳ về FL/FR/UB và mọi biến thể thế cầm không nằm hết trong gói. Bộ này mở rộng quyết định của hành trình 5×5 đã khóa, không thay nó và không tự nhận là solver tổng quát.

Nguồn: chương 5×5 trong *Hiểu để nhớ 2.1*, các ca đã kiểm B5-4…B5-9; [J Perm 5×5](https://jperm.net/5x5); [CubeSkills Beginner 5×5](https://cubeskills.com/uploads/pdf/tutorials/beginners-method-for-solving-the-5x5-cube.pdf). Các ví dụ mới đều đã được kiểm riêng trên toàn bộ sticker và các điều kiện nhận dạng nêu ở đây.
