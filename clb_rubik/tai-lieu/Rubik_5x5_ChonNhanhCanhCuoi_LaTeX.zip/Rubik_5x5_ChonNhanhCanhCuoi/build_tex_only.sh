#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
# Uses the packaged vector assets and never invokes Python.
exec ./build.sh
