"""Redraw only 14 net assets using the exact net() function in the print builder."""
from pathlib import Path
import sys,json,ast,hashlib,types
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'render_toolkit'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle
from validated_cube import Cube
import draw_figures as df
source=(R/'build_branches_print.py').read_text();tree=ast.parse(source)
node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='net')
ns={'args':types.SimpleNamespace(text_only=False,focus_only=False),'OUT':R/'assets','plt':plt,'Rectangle':Rectangle,'Circle':Circle,'COL':df.COL,'INK':df.INK}
exec(compile(ast.Module(body=[node],type_ignores=[]),'net_only','exec'),ns)
D=json.loads((R/'data/branches5.json').read_text());count=0
for C in D['cases']:
 c=Cube(5).apply(C['scrambleAlgorithm']);states=[c.copy()]
 for m in C['moves']:c.move(m);states.append(c.copy())
 for st in C['stages']:
  ix=st['workingStateIndex'];c=states[ix]
  assert all(c.matrix(f)==C['frames'][ix]['state']['faces'][f] for f in 'URFDLB')
  ns['net'](c,st['id']+'_net.pdf',st['highlightIds']);count+=1
before=json.loads((R/'qa/net_patch_before.json').read_text())
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==v for p,v in before.items())
(R/'qa/net_patch.json').write_text(json.dumps({'net_assets_redrawn':count,'change':'Shift F/D labels horizontally by half a cell; all cube cells and coordinates unchanged.','all_narrative_source_data_focus_and_sequence_assets_unchanged':True},ensure_ascii=False,indent=2))
print('Redrew',count,'nets only; all other content hashes unchanged.')
