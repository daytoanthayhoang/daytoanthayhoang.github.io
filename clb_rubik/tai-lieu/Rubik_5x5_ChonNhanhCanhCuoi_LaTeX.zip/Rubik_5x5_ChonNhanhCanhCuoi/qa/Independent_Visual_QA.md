# Phụ lục 5×5: kiểm lời chỉ viên và bản in

Kết luận cuối: ĐẠT trong phạm vi QA đã giao. Đủ 14 bước có lời chỉ viên/ô và hình soi đúng; bản vá nhãn đã kiểm lại. Không còn lỗi chặn phát hành được phát hiện.

Tệp: `output/rubik/Rubik_5x5_ChonNhanhCanhCuoi_20261114/Rubik_5x5_ChonNhanhCanhCuoi.pdf`.
Bản cuối đã kiểm: 57 trang, SHA-256 `aca4ccc26b048364764507c5b1bb8ff582e391cf5f5ce84ad4a525c741133f46`.
Bản trước vá nhãn: `ed4ff1e990d3055418d82c607ca1c125f0b51aad367a971b93c5feb07beb9963`.

## Phạm vi đã kiểm

- Xem thật đủ 14 trang nhận dạng/khung làm việc: physical 6, 8, 10, 13, 16, 19, 22, 27, 30, 33, 36, 39, 44, 49.
- Xem thật đủ 14 trang kết thúc bước/hình soi sau bước: physical 7, 9, 12, 15, 18, 21, 26, 29, 32, 35, 38, 43, 48, 53.
- Xem thêm physical 24, 31, 41, 51 để kiểm nước rộng, đổi cách cầm, nhãn Q và mũi tên. Trang 7/9/12 cũng cho thấy rõ 2U/2D và góc nhìn dưới.
- Soát token, số thứ tự khung và checkpoint ngay trong PDF: đủ 154 nước + 14 checkpoint, đúng thứ tự từng ca. Không lặp chứng minh phép quay Python/JavaScript.
- Không có text span tràn ngoài trang; cỡ chữ nhỏ nhất khoảng 7,27 pt. Khung focus hai sticker có màu, chữ viết tắt màu, ô tọa độ và mã P rõ. Không thấy hộp kiểm tràn/cắt.

## 14 bước: kết quả

- BR5-01/02/03: đích được ghi đúng là viên giữa FR, F(3,5) vàng / R(3,1) xanh lá. Cánh cho từ FL hàng 2, hàng 4, hoặc cả hai tương ứng. Không còn lấy viên giữa FL đầu danh sách làm đích.
- BR5-04 và BR5-07-S2/S3: đọc toàn cạnh FR, P1/P3 là hai cánh và P2 là viên giữa. T đổi hai đầu cùng hướng viên giữa; lời không còn hứa đã ghép ở bước chuẩn bị. Ca04 ghi rõ đây là thí nghiệm từ khối solved và kết thúc chưa solved toàn khối.
- BR5-05, BR5-06-S1, BR5-07-S1/S4: FL và FR có mốc viên giữa riêng, đọc đủ hai màu. Hai vị trí được chọn cho C là FL hàng 2 và FR hàng 4. Câu ở BR5-07-S1 đã được sửa thành “hai cánh được chọn để đổi ở bước này”, tránh nhầm với tổng bốn cánh sai danh tính của đầu ca.
- BR5-06-S2 và BR5-09-S1: net sau z′ có lỗi ở UF; hình soi có nhãn ĐẦU bước và còn ghi FR/FL trong thế cầm ban đầu. Màu midge UF trong khung làm việc là U(5,3) cam / F(1,3) xanh lá.
- BR5-07-S2: net sau y′ đưa FL ban đầu thành FR làm việc, trong khi focus đầu bước vẫn ghi FL/FR. Nhãn và lời chuẩn bị phân biệt rõ, không yêu cầu làm setup hai lần.
- BR5-08: UF là U(5,2–4)/F(1,2–4); midge vàng–xanh lá khác hướng hai cánh, đúng hình và lời.
- BR5-09-S2: net sau z đưa FL lên UF, midge U(5,3) đỏ / F(1,3) xanh lá; focus đầu bước cho FR đã ghép và FL vẫn ngược giữa. Không lặp nhầm setup của lần sửa FR.
- Ca07 kết thúc đúng ở reduction, lời và ảnh không tuyên bố solved toàn cube. Ca09 thể hiện đúng 10→11→12 bộ ba.
- 3Rw′ được ghi rõ BA LỚP PHẢI và là nước 8 của Q; số nước lớn trên khung vẫn chạy liên tục trong ca, được giải thích ở đầu các trang thao tác.

## Lỗi trình bày nhỏ đã phát hiện

Trong net ban đầu, số cột 3 dưới U giao nhãn F và số 3 dưới F giao nhãn D. Ví dụ physical27: số3 bbox y315,47–323,94 pt; F bbox y317,53–329,63 pt. Đây chỉ là vị trí chữ, không liên quan state/công thức. Đã dịch riêng F/D nửa ô ngang, giữ nguyên canvas, mặt, sticker, focus và sequence. Đã raster lại và xem thật đủ 14 net trên bản cuối: 28 nhãn F/D tách khỏi mọi số hàng/cột, không giao bounding box và không che sticker. Kết luận bản vá: ĐẠT.

## Kiểm phụ theo yêu cầu

Bản 74 trang `Rubik_HanhTrinh3x3_2x2_74tr.pdf`: không phát hiện số tọa độ giao F/D trong scan bbox. Xem thật physical7 (3×3) và physical52 (2×2): nhãn tách rõ. Không cần sửa bản này.

## Bằng chứng

- `step_review.json`: danh sách 14 bước, trang đầu/cuối và setup.
- `stage_label_reference.json`: tọa độ/màu theo cùng sticker ID ở đầu, sau setup và sau bước.
- `review_inventory.json`, `final_verification.json`: hash, trang, số khung và đối chiếu bản sửa câu27.
- `start_*.jpg`, `end_*.jpg`, `pages/`: ảnh đã đọc; `final_page27.png`: câu27 đã sửa.
- `related_74page_label_scan.json`, `related74_page07.png`, `related74_page52.png`: kiểm nhanh bản74.

Bằng chứng vá nhãn cuối: `net_final_check.json`, `net_final_1.png` đến `net_final_4.png`, `final_net_pages/`.
