from pathlib import Path
import fitz,json
from PIL import Image,ImageOps,ImageDraw
R=Path(__file__).resolve().parents[1];d=fitz.open(R/'Rubik_5x5_ChonNhanhCanhCuoi.pdf');Q=R/'qa';(Q/'pages').mkdir(exist_ok=True)
rows=[]
for i,p in enumerate(d):
 pix=p.get_pixmap(matrix=fitz.Matrix(1.5,1.5));pix.save(Q/'pages'/f'page-{i+1:02d}.png')
 rows.append({'page':i+1,'text_chars':len(p.get_text()),'top_body':p.get_text()[:140]})
for start in range(0,len(d),8):
 W=510;H=750;sheet=Image.new('RGB',(W*2,H*4),'#d7dddd');draw=ImageDraw.Draw(sheet)
 for j in range(8):
  if start+j>=len(d):break
  im=Image.open(Q/'pages'/f'page-{start+j+1:02d}.png').convert('RGB');im.thumbnail((W-18,H-32))
  x=(j%2)*W+(W-im.width)//2;y=(j//2)*H+25;sheet.paste(im,(x,y));draw.text(((j%2)*W+10,(j//2)*H+7),f'PAGE {start+j+1}',fill='black')
 sheet.save(Q/f'contact-{start//8+1:02d}.jpg',quality=92)
(Q/'page_inventory.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('Rendered',len(d),'pages')
