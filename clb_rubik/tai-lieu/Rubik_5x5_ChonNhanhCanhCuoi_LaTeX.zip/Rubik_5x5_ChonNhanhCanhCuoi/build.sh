#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
FORMAT_DIR='/workspace/scratch/a84c62516364/output/math8/Bo_TuyenChon40_Web_20261114_cloud/kiemtra'
if [ -f "$FORMAT_DIR/xelatex.fmt" ]; then
  export TEXMF='{/usr/share/texmf,/usr/share/texlive/texmf-dist}'
  export TEXFORMATS="$FORMAT_DIR:"
fi
# Default: use packaged assets. Python is optional.
if [ "${1-}" = '--regenerate' ]; then
  shift
  export MPLCONFIGDIR="${MPLCONFIGDIR:-/tmp/rubik-matplotlib}"
  python build_branches_print.py "$@"
elif [ "${1-}" = '--text-only' ] || [ "${1-}" = '--focus-only' ]; then
  export MPLCONFIGDIR="${MPLCONFIGDIR:-/tmp/rubik-matplotlib}"
  python build_branches_print.py "$@"
elif [ "$#" -ne 0 ]; then
  echo 'Usage: ./build.sh [--regenerate | --text-only | --focus-only]' >&2
  exit 2
fi
xelatex -interaction=nonstopmode -halt-on-error Rubik_5x5_ChonNhanhCanhCuoi.tex > build1.txt
xelatex -interaction=nonstopmode -halt-on-error Rubik_5x5_ChonNhanhCanhCuoi.tex > build2.txt
