from pathlib import Path
import json,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
root=Path(__file__).resolve().parents[1]
f=json.loads((root/'data/pyraminx_frames.json').read_text())['frames'][-1]
fig,ax=plt.subplots(figsize=(3.65,3.2));fig.subplots_adjust(left=.05,right=.95,top=.97,bottom=.02)
for s in f['stickers']:
 if s['face']!='B':continue
 pts=np.array(s['vertices'])[:,[0,1]]
 ax.add_patch(Polygon(pts,facecolor=s['hex'],edgecolor='#254455',linewidth=.8))
 x,y=pts.mean(axis=0);t={'T':'chóp','C':'tâm','E':'cạnh'}[s['pieceId'][0]];ax.text(x,y,t,ha='center',va='center',fontsize=8.3,color='#12333c',weight='bold')
for x,y,t in [(0,1.12,'U'),(-.92,-.39,'L'),(.92,-.39,'R')]:ax.text(x,y,t,ha='center',va='center',fontsize=10,weight='bold')
ax.set_xlim(-1.0,1.0);ax.set_ylim(-.48,1.2);ax.set_aspect('equal');ax.axis('off');fig.savefig(root/'assets/anatomy_front.pdf');plt.close(fig)
