import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {Pyraminx,SLOTS,VERTICES,rotate,dot,add,scale} from './pyraminx-engine.js';
const data=JSON.parse(readFileSync(new URL('../data/walkthrough-pyraminx.json',import.meta.url)));
const drawings=JSON.parse(readFileSync(new URL('../data/pyraminx_frames.json',import.meta.url))).frames;
const center=s=>scale(s.vertices.reduce(add,[0,0,0]),1/3),distance=(a,b)=>Math.hypot(...add(a,scale(b,-1)));
function geometricStep(state,token){
 const axis=VERTICES[token[0].toUpperCase()],tip=token[0]!==token[0].toUpperCase(),angle=(token.endsWith("'")?1:-1)*2*Math.PI/3,next=[];
 for(const s of SLOTS){let target=s.id;const c=center(s),lambda=(3*dot(c,axis)+1)/4;
  if(lambda>(tip?2/3:1/3)+1e-8){const p=rotate(c,axis,angle),n=rotate(s.normal,axis,angle),matches=SLOTS.filter(t=>distance(center(t),p)<1e-8&&distance(t.normal,n)<1e-8);assert.equal(matches.length,1);target=matches[0].id;}
  next[target]=state[s.id];
 }return next;
}
const cube=new Pyraminx().apply(data.scrambleAlgorithm);assert.deepEqual(cube.exportState(),data.initialState);let oracle=cube.exportState();
for(let i=0;i<data.frames.length;i++){
 assert.deepEqual(cube.exportState(),data.frames[i].state);assert.deepEqual(oracle,data.frames[i].state);assert.deepEqual(drawings[i].state,oracle);assert.deepEqual(drawings[i].stickers,JSON.parse(JSON.stringify(cube.renderData()))); // JSON normalizes signed zero.
 if(i<data.moves.length){cube.move(data.moves[i]);oracle=geometricStep(oracle,data.moves[i]);}
}
assert.ok(cube.isSolved());for(const s of data.stages){assert.deepEqual(s.beforeState,data.frames[s.start].state);assert.deepEqual(s.afterState,data.frames[s.endExclusive].state);}
console.log('PASS: 40 exact states, 39 moves, 1,440 rendered sticker records and 11 checkpoints; independent cutting-plane rotation agrees.');
