from pathlib import Path
import json,hashlib,shutil,subprocess,xml.etree.ElementTree as ET,re
import numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'data/walkthrough-pyraminx.json').read_text());F=json.loads((ROOT/'data/pyraminx_frames.json').read_text())['frames']
V={'U':np.array([0,1,0.]),'L':np.array([-np.sqrt(2/3),-1/3,np.sqrt(2)/3]),'R':np.array([np.sqrt(2/3),-1/3,np.sqrt(2)/3]),'B':np.array([0,-1/3,-2*np.sqrt(2)/3])}
FACE_NAMES={'B':'TRƯỚC','L':'BÊN PHẢI','R':'BÊN TRÁI','U':'ĐÁY'}
assert len(F)==len(D['moves'])+1==40
for i,f in enumerate(F):
 assert f['state']==D['frames'][i]['state'] and sorted(f['state'])==list(range(36))
 assert len(f['stickers'])==36 and set(s['slotId'] for s in f['stickers'])==set(range(36))
 if i<39:assert f['nextMove']==D['moves'][i]
assert F[-1]['metrics']['isSolved']

def esc(s):
 return str(s).replace('\\',r'\textbackslash{}').replace('&',r'\&').replace('%',r'\%').replace('_',r'\_').replace('#',r'\#')
def human(s):
 for prefix,label in [('T','Chóp'),('C','Cụm tâm'),('E','Cạnh')]:s=re.sub(prefix+r':([ULRB]+)',lambda m:label+' '+m[1],s)
 return s

def faces(index,targets=None,name=None):
 f=F[index];targets=targets if targets is not None else f['highlightPieceIds']
 fig,axs=plt.subplots(1,4,figsize=(9.3,2.6));fig.subplots_adjust(left=.005,right=.995,bottom=.02,top=.9,wspace=.03)
 for ax,face in zip(axs,['B','L','R','U']):
  normal=-V[face];up=np.array([0,1,0.]) if face!='U' else V['B'].copy();up=up-normal*np.dot(up,normal);up/=np.linalg.norm(up);right=np.cross(up,normal)
  for s in f['stickers']:
   if s['face']!=face:continue
   pts=np.array(s['vertices']);xy=np.c_[pts@right,pts@up]
   ax.add_patch(Polygon(xy,facecolor=s['hex'],edgecolor='#1b2835' if s['pieceId'] in targets else '#666666',linewidth=1.8 if s['pieceId'] in targets else .45,joinstyle='round'))
  for letter,p in V.items():
   if letter==face:continue
   x,y=np.dot(p,right)*1.13,np.dot(p,up)*1.13;ax.text(x,y,letter,ha='center',va='center',weight='bold',fontsize=9,color='#17344a')
  ax.set_xlim(-1.04,1.04);ax.set_ylim(-.85,1.24);ax.set_aspect('equal');ax.axis('off');ax.set_title(FACE_NAMES[face],fontsize=9,color='#17344a',weight='bold',pad=0)
 out=ROOT/'assets'/(name or f'faces_{index:03}.pdf');fig.savefig(out,transparent=False);plt.close(fig)

for i in range(40):faces(i)
faces(39,targets=[],name='solved_faces.pdf')
# Source SVGs are copied, cropped without changing geometry, then converted to PDF.
svgroot=ROOT/'data/svg';svgroot.mkdir(exist_ok=True)
NS='{http://www.w3.org/2000/svg}'
for i,f in enumerate(F):
 for camera in ['front','opposite']:
  original=svgroot/camera/(f'pyra_{i:03}.svg' if camera=='front' else f'pyra_opposite_{i:03}.svg')
  if not original.exists():continue
  rt=ET.parse(original).getroot();rt.set('viewBox','-275 -280 550 550');rt.set('width','550');rt.set('height','550')
  for child in list(rt):
   if child.tag==NS+'text':rt.remove(child)
   elif child.tag==NS+'g':
    for node in child:
     if node.tag==NS+'circle':node.set('r','24')
     elif node.tag==NS+'text':node.set('font-size','30');node.set('dy','10')
  # Opposite view may have different projected extents. Root crop still includes all vertices and arcs.
  cropped=ROOT/'assets'/f'move_{camera}_{i:03}.svg';ET.ElementTree(rt).write(cropped,encoding='unicode')
  subprocess.run(['inkscape',str(cropped),'--export-type=pdf','--export-filename='+str(cropped.with_suffix('.pdf'))],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)

out=[r'\chapter{Một khối xuyên suốt: từ chóp lệch đến bốn mặt đúng}']
for s in D['stages']:
 n=s['index']+1;start,end=s['start'],s['endExclusive'];targets=s['highlightPieceIds'];faces(start,targets,name=f'stage{n:02}_before.pdf');faces(end,targets,name=f'stage{n:02}_after.pdf')
 out += ([r'\clearpage'] if n>1 else [])+[r'\section{'+str(n)+'. '+esc(s['title'])+'}',r'\textbf{Mục tiêu.} '+esc(s['goal']),r'\par\smallskip\includegraphics[width=\linewidth]{assets/stage'+f'{n:02}'+r'_before.pdf}',r'{\small Bốn mặt trước chặng. Viền đậm đánh dấu mảnh đang theo dõi; chữ U/L/R/B là đỉnh.}',r'\step{Tìm mảnh}',esc(human(s['find'])),r'\step{Vì sao làm như vậy?}',esc(s['why']),r'\textbf{Phần phải giữ sau cả cụm.} '+esc(s['preserve']),r'\begin{checkpointbox}{Thao tác của chặng '+str(n)+'}',r'\alg{'+esc(s['algorithm'])+'}',r'\end{checkpointbox}']
 # Each diagram is the state BEFORE its printed move. Separate row minipages prevent splitting.
 for a in range(start,end,3):
  out += [r'\par\medskip\noindent\begin{minipage}{\linewidth}']
  for i in range(a,min(a+3,end)):
   token=D['moves'][i];camera='opposite' if token[0].upper()=='B' else 'front';kind='chóp nhỏ' if token[0].islower() else 'hai lớp';direction='ngược' if "'" in token else 'thuận';pos=F[i]['camera']['position'];caption='Góc sau/trái' if camera=='opposite' else ('Góc '+('trước' if pos[2]>0 else 'sau')+'/'+('phải' if pos[0]>0 else 'trái'))
   out += [r'\begin{minipage}[t]{.323\linewidth}\centering',r'{\bfseries '+str(i+1)+r'. \alg{'+esc(token)+r'}}\par',r'\includegraphics[width=\linewidth]{assets/move_'+camera+f'_{i:03}'+r'.pdf}',r'{\footnotesize '+caption+r'\\'+kind+' · 120° '+direction+r'}\end{minipage}\hfill']
  out += [r'\end{minipage}\par']
 out += [r'\par\medskip\begin{minipage}{\linewidth}\begin{checkpointbox}{Kiểm sau chặng '+str(n)+'}',r'\includegraphics[width=\linewidth]{assets/stage'+f'{n:02}'+r'_after.pdf}',esc(s['check']),r'\par\textbf{Đi tiếp.} '+esc(s['next']),r'\end{checkpointbox}\end{minipage}']
out += [r'\clearpage\section{Khi khối trên tay khác ví dụ}',r'\begin{description}']
for b in D['branchNotes']:out.append(r'\item['+esc(b['condition'])+'] '+esc(b['action']))
out += [r'\end{description}',r'Không chuyển sang chặng sau chỉ vì đã đọc hết công thức. Hãy đối chiếu phần phải giữ và kết quả kiểm; các nhánh không xảy ra trong mẫu cần nhận dạng lại trước khi xoay.']
(ROOT/'chapters/journey.tex').write_text('\n'.join(out))
(ROOT/'qa/render_source_check.json').write_text(json.dumps({'source_sha256':hashlib.sha256((ROOT/'data/walkthrough-pyraminx.json').read_bytes()).hexdigest(),'frames':40,'stickers_per_frame':36,'exact_states_and_next_moves_match':True,'final_solved':True,'face_views':'orthographic projections of exact sticker vertices, not hand-colored','move_arrows':'source SVG projection of legal engine rotation, camera-only changes'},ensure_ascii=False,indent=2))
print('Built Pyraminx journey: 11 stages,39 moves,40 exact states.')
