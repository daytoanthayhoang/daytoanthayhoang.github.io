HÀNH TRÌNH PYRAMINX

Một ví dụ tứ diện thật: 11 chặng, 39 nước, 40 trạng thái liên tục. Bản in chỉ đường từ chóp, tâm, cạnh đáy đến ba cạnh cuối, kèm bốn mặt trước/sau chặng và hai góc camera cho vùng khuất. Khối xáo được chuẩn bị để dạy, không phải bộ giải mọi scramble.

Dựng PDF bằng XeLaTeX hai lần:
  xelatex Rubik_HanhTrinhPyraminx.tex
  xelatex Rubik_HanhTrinhPyraminx.tex
Cần TeX Live hoặc MiKTeX đầy đủ. Hình vector đã có sẵn trong assets; không cần mạng hoặc Python để biên dịch tài liệu.

Dữ liệu nguyên: data/walkthrough-pyraminx.json và data/pyraminx_frames.json. Những SVG nguồn nằm ở data/svg; màu, hình học và mũi tên được tạo từ cùng mô hình dùng trên web. Mỗi mặt nhỏ nhìn từ ngoài vào; đáy cũng nhìn từ ngoài lên, không nhìn xuyên và không lật gương.

Tái tạo hình/chương (tùy chọn): Python 3 với numpy, matplotlib và Inkscape; chạy build_pyraminx_print.py từ thư mục này. Hình chóp/tâm/cạnh mở đầu được tạo bằng render_toolkit/anatomy.py. Có thể kiểm độc lập đường đi bằng Node.js: node render_toolkit/verify_journey.mjs. Phép kiểm này không cần gói ngoài.

Quy ước đặc thù: U/L/R/B là đỉnh, chữ hoa xoay hai lớp, chữ thường chỉ chóp; mỗi nước 120 độ. Không dùng parser/cách hiểu r của khối lập phương. Hình dưới nhãn nước là trạng thái trước nước đó; hộp Kiểm sau chặng mới là trạng thái sau cả cụm.
