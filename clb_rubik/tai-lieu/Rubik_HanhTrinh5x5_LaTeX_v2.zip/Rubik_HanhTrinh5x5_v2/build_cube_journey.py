"""Exact-state print renderer for n×n continuous teaching walkthroughs.
Usage: python build_cube_journey.py data/walkthrough3.json [--narrative data/narrative3.json]
No state or move is inferred: every rendered frame is verified against the manifest.
"""
from pathlib import Path
import sys,argparse,json,hashlib,math
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'render_toolkit'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Circle
import numpy as np
from validated_cube import Cube
import draw_figures as df
from visual_sequences import cube_draw,cube_camera,cube_move_note
ap=argparse.ArgumentParser();ap.add_argument('manifest');ap.add_argument('--narrative');ap.add_argument('--text-only',action='store_true');ap.add_argument('--net-only',action='store_true');a=ap.parse_args()
p=Path(a.manifest);p=p if p.is_absolute() else ROOT/p
D=json.loads(p.read_text());n=D['n'];assert n in (2,3,4,5)
sha=hashlib.sha256(p.read_bytes()).hexdigest();name='walkthrough'+str(n)
NARR={}
if a.narrative:
 q=Path(a.narrative);q=q if q.is_absolute() else ROOT/q;N=json.loads(q.read_text())
 assert N['source_sha256']==sha
 NARR={x['id']:x for x in N['phases']}
OUT=ROOT/'assets'/name;OUT.mkdir(parents=True,exist_ok=True)
original_marks=df.add_view_marks
def readable_marks(ax,*args,**kwargs):
 kwargs['fontsize']=10.5;original_marks(ax,*args,**kwargs)
 for t in ax.texts:
  if t.get_text().startswith('Nhìn '):t.set_fontsize(11.5)
df.add_view_marks=readable_marks
c=Cube(n).apply(D['scrambleAlgorithm']);states=[c.copy()]
for m in D['moves']:c.move(m);states.append(c.copy())
assert len(states)==len(D['frames'])
for c,f in zip(states,D['frames']):
 assert c.validate()['passed']
 assert all(c.matrix(face)==f['state']['faces'][face] for face in 'URFDLB')
 assert len(c.stickers)==len(f['state']['stickers'])
 assert all(tuple(s.pos)==tuple(t['pos']) and tuple(s.normal)==tuple(t['normal']) and s.color==t['color'] for s,t in zip(c.stickers,f['state']['stickers']))
assert c.is_uniform()

def net(c,filename,title,ids=()):
 if a.text_only:assert (OUT/filename).exists();return
 fig,ax=plt.subplots(figsize=(9.4,6.2));layout={'U':(1,2),'L':(0,1),'F':(1,1),'R':(2,1),'B':(3,1),'D':(1,0)}
 sx,sy=n+.65,n+.90
 for face,(col,row) in layout.items():
  x,y=col*sx,row*sy
  for r in range(n):
   for co in range(n):
    st=c.face(face)[r*n+co];xx=x+co;yy=y+n-1-r
    ax.add_patch(Rectangle((xx,yy),.96,.96,facecolor=df.COL[st.color],edgecolor=df.INK,lw=.65))
    if 1<=r<=n-2 and 1<=co<=n-2:ax.add_patch(Rectangle((xx+.03,yy+.03),.90,.90,fill=False,edgecolor=df.INK,lw=1.2))
    if c.stickers.index(st) in ids:ax.add_patch(Circle((xx+.48,yy+.48),.29,fill=False,ec='black',lw=2))
  ax.text(x+(n-.1)/2+(.5 if face in ('F','D') and n%2 else 0),y+n+.25,face,ha='center',va='center',fontsize=13,fontweight='bold',color=df.INK)
  for k in range(n):
   ax.text(x-.18,y+n-.52-k,str(k+1),ha='right',va='center',fontsize=7.5,color=df.INK)
   ax.text(x+k+.48,y-.15,str(k+1),ha='center',va='top',fontsize=7.5,color=df.INK)
 ax.set_aspect('equal');ax.set_xlim(-.65,3*sx+n+.1);ax.set_ylim(-.45,2*sy+n+.6);ax.axis('off');fig.suptitle(title,fontsize=13,color=df.INK,fontweight='bold')
 fig.subplots_adjust(left=.01,right=.99,top=.94,bottom=.01);fig.savefig(OUT/filename,bbox_inches='tight',pad_inches=.04,facecolor='white');plt.close(fig)

net(states[0],'initial_net.pdf',f'{n}×{n}: trạng thái bắt đầu của ví dụ')
outputs=[]
for st in D['stages']:
 sid=st['id'];ids=st['highlightIds'];work=st['workingStateIndex']
 net(states[work],sid+'_working.pdf','Khung tìm mảnh: '+sid+' · '+st['title'],ids)
 if a.net_only:continue
 files=[];indices=list(range(st['start'],st['endExclusive']+1))
 for part,off in enumerate(range(0,len(indices),8),1):
  filename=f'{sid}_moves_{part}.pdf';files.append(filename)
  if a.text_only:assert (OUT/filename).exists();continue
  selected=indices[off:off+8];rows=math.ceil(len(selected)/4)
  fig,axs=plt.subplots(rows,4,figsize=(9.4,3.10*rows),squeeze=False)
  for j,ax in enumerate(axs.ravel()):
   if j>=len(selected):ax.axis('off');continue
   idx=selected[j];state=states[idx];move=D['moves'][idx] if idx<st['endExclusive'] else None
   cube_draw(ax,state,move=move);cam,_=cube_camera(move);pm,view=df.projection(cam)
   for k in ids:
    sticky=state.stickers[k]
    if np.dot(sticky.normal,view)>1e-5:
     center=np.array(sticky.pos)/n+np.array(sticky.normal)/n;xy=center@pm.T
     ax.add_patch(Circle(xy,.42/n,fill=False,ec='black',lw=1.1,zorder=10))
   local=idx-st['start']+1
   ax.set_title(f'{local:02d}  {move}' if move else f'{local:02d}  KIỂM MỐC',fontsize=16 if move else 13,fontweight='bold',color=df.INK,pad=4)
   note=cube_move_note(move) if move else 'Kiểm tra rồi\nqua mốc tiếp'
   ax.text(.5,-.025,note,transform=ax.transAxes,ha='center',va='top',fontsize=12.5,color=df.TEAL,linespacing=1.1,clip_on=False)
  fig.subplots_adjust(left=.02,right=.98,wspace=.10,hspace=.37,top=1-.36/(3.10*rows),bottom=.50/(3.10*rows))
  fig.savefig(OUT/filename,bbox_inches=None,facecolor='white');plt.close(fig)
 outputs.append({'id':sid,'workingFrame':work,'sequenceParts':files})

if a.net_only:
 print('Only net labels regenerated; chapters and move diagrams unchanged.');sys.exit(0)

def esc(s):
 return str(s).replace('\\',r'\textbackslash{}').replace('&',r'\&').replace('%',r'\%').replace('#',r'\#').replace('_',r'\_').replace('→',r'$\to$')
T=[r'\subsection*{Trạng thái bắt đầu của chính ví dụ này}',esc(D['disclosure']),
   'Hàng/cột đếm từ 1 khi nhìn thẳng vào từng mặt từ ngoài. Vòng đen chỉ viên cần theo dõi, không thay màu. Sơ đồ tìm mảnh đã làm phần chuẩn bị để dễ quan sát; khi thực hành, theo dãy từ khung 01 một lần. Nếu đã làm phần chuẩn bị để đối chiếu, tiếp tục ngay sau phần ấy, không làm lại.',
   r'\par\noindent\includegraphics[width=\linewidth]{assets/'+name+r'/initial_net.pdf}\par']
for i,(st,out) in enumerate(zip(D['stages'],outputs),1):
 sid=st['id'];nar=NARR.get(sid,{})
 T.append(r'\clearpage\section{Mốc '+str(i)+': '+esc(st['title'])+'}')
 for label,key in [('Mục tiêu','goal'),('Nhận dạng','recognize'),('Tìm viên','find')]:T.append(r'\textbf{'+label+'.} '+esc(nar.get(key,st[key]))+r'\par')
 if nar.get('look'):T.append(r'\textbf{Quan sát trong khung làm việc.} '+esc(nar['look'])+r'\par')
 if st['workingFrameMoves']:T.append(r'\textbf{Sơ đồ tìm mảnh:} đã làm \alg{'+' '.join(st['workingFrameMoves'])+r'} từ đầu mốc. Dãy thao tác vẫn bắt đầu trước phần chuẩn bị.\par')
 else:T.append(r'\textbf{Sơ đồ tìm mảnh:} đúng trạng thái đầu mốc, chưa có nước chuẩn bị.\par')
 T.append(r'\noindent\includegraphics[width=.88\linewidth]{assets/'+name+'/'+sid+r'_working.pdf}\par')
 for label,key,fallback in [('Vì sao chọn','why','reason'),('Quyết định','decision','decision'),('Điều phải giữ','preserve','preserve')]:T.append(r'\textbf{'+label+'.} '+esc(nar.get(key,st[fallback]))+r'\par')
 T.append(r'\par\noindent\begin{minipage}{\linewidth}\textbf{Làm theo từng cụm:}\par')
 for group in st['groups']:T.append(r'\noindent '+esc(group['label'])+r': \alg{'+group['algorithm']+r'}\par')
 T.append(r'\end{minipage}\par')
 for k,f in enumerate(out['sequenceParts']):
  last=k==len(out['sequenceParts'])-1
  T.append(r'\par\medskip\noindent\begin{minipage}{\linewidth}\centering\includegraphics[width=\linewidth]{assets/'+name+'/'+f+r'}\par\small\textit{Mốc '+str(i)+', dãy '+str(k+1)+'/'+str(len(out['sequenceParts']))+r'. Mỗi khung là trước nước ghi trên khung; riêng KIỂM MỐC là sau trọn mốc.}')
  if last:T.append(r'\par\normalsize\raggedright\begin{checkpointbox}{Kiểm tra, rồi mới đi tiếp}'+esc(nar.get('check',st['check']))+r'\par\textbf{Tiếp theo:} '+esc(nar.get('next',st['next'])).rstrip('.')+r'.\end{checkpointbox}')
  T.append(r'\end{minipage}\par\medskip')
T.append(r'\clearpage\subsection*{Tạo lại đúng khối xáo để thực hành}')
T.append('Bắt đầu từ khối đã giải, U vàng/F xanh lá/R cam. Làm chuỗi dưới đây rồi bắt đầu mốc 1. Đây là ví dụ sư phạm, không dùng làm scramble đo thành tích.')
moves=D['scrambleAlgorithm'].split()
for i in range(0,len(moves),15):T.append(r'\noindent\alg{'+' '.join(moves[i:i+15])+r'}\par')
if D.get('branchNotes'):
 T.append(r'\subsection*{Nếu không giống hình mẫu}')
 for branch in D['branchNotes']:T.append(r'\textbf{'+esc(branch['condition'])+'.} '+esc(branch['action'])+r'\par')
(ROOT/'chapters'/f'{name}_steps.tex').write_text('\n\n'.join(T))
(ROOT/'qa'/f'{name}_print.json').write_text(json.dumps({'source_sha256':sha,'frames_replayed_and_all_stickers_equal':len(states),'all_states_legal':True,'final_solved':True,'stages':outputs},ensure_ascii=False,indent=2))
print(f'Rendered {len(outputs)} stages, {len(states)} states for {n}×{n}; all stickers match manifest.')
