"""Exact integer facelet model for diagrams and algorithm checks (NxN).

Axes: +x=R, +y=U, +z=F. Face turns clockwise viewed from outside.
`2R` is inner second layer only; `Rw` two layers; `3Rw` three layers.
`r` is accepted as inner second layer, never as a wide move.
Every sticker retains a tangent vector so marked centre orientation is tracked.
"""
from dataclasses import dataclass
from copy import deepcopy
import re
import numpy as np

NORMALS={'R':(1,0,0),'L':(-1,0,0),'U':(0,1,0),'D':(0,-1,0),'F':(0,0,1),'B':(0,0,-1)}
BASES={'F':((1,0,0),(0,1,0)), 'B':((-1,0,0),(0,1,0)),
       'R':((0,0,-1),(0,1,0)), 'L':((0,0,1),(0,1,0)),
       'U':((1,0,0),(0,0,-1)), 'D':((1,0,0),(0,0,1))}

def rot(v,axis,q):
    a=list(v)
    for _ in range(q%4):
        if axis==0:a=[a[0],-a[2],a[1]]
        elif axis==1:a=[a[2],a[1],-a[0]]
        else:a=[-a[1],a[0],a[2]]
    return tuple(a)

def tokens(alg):
    alg=alg.replace('’',"'").replace('′',"'")
    return [t for t in alg.split() if t not in ['|','(',')']]

def inverse(alg):
    def inv(t):
        if t.endswith('2') or t.endswith("2'"):return t.rstrip("'")
        return t[:-1] if t.endswith("'") else t+"'"
    return ' '.join(inv(t) for t in tokens(alg)[::-1])

@dataclass
class Sticker:
    pos:tuple
    normal:tuple
    tangent:tuple
    color:str
    home:tuple
    home_normal:tuple
    home_tangent:tuple

class Cube:
    def __init__(self,n=3):
        self.n=n;self.s=n-1;self.stickers=[]
        vals=list(range(-self.s,self.s+1,2))
        for f,norm in NORMALS.items():
            e1,e2=BASES[f]
            for row,b in enumerate(vals[::-1]):
                for col,a in enumerate(vals):
                    p=tuple(self.s*norm[k]+a*e1[k]+b*e2[k] for k in range(3))
                    self.stickers.append(Sticker(p,norm,e2,f,p,norm,e2))
    def copy(self):return deepcopy(self)
    def apply(self,alg):
        for t in tokens(alg):self.move(t)
        return self
    def move(self,t):
        match=re.fullmatch(r"(\d*)([URFDLBurfdlbMESxyz])(w?)(2'?|'?)",t)
        if not match:raise ValueError('Bad move: '+t)
        num,face,wide,end=match.groups();count=int(num or '1')
        power=2 if '2' in end else (-1 if end=="'" else 1)
        if face in 'xyz':
            axis='xyz'.index(face);q=-power;selected=lambda p:True
        elif face in 'MES':
            axis={'M':0,'E':1,'S':2}[face];q=power*(1 if face in 'ME' else -1)
            selected=lambda p:p[axis]==0
        else:
            f=face.upper();norm=NORMALS[f];axis=next(i for i in range(3) if norm[i]);sign=norm[axis]
            q=-sign*power
            if wide:
                count=int(num or '2');cut=self.s-2*(count-1)
                selected=lambda p:sign*p[axis]>=cut
            elif num or face.islower():
                depth=int(num or '2');level=self.s-2*(depth-1)
                selected=lambda p:sign*p[axis]==level
            else:selected=lambda p:sign*p[axis]==self.s
        for st in self.stickers:
            if selected(st.pos):
                st.pos=rot(st.pos,axis,q);st.normal=rot(st.normal,axis,q);st.tangent=rot(st.tangent,axis,q)
        return self
    def face(self,f):
        norm=NORMALS[f];e1,e2=BASES[f]
        sts=[st for st in self.stickers if st.normal==norm]
        return sorted(sts,key=lambda st:(-sum(st.pos[k]*e2[k] for k in range(3)),sum(st.pos[k]*e1[k] for k in range(3))))
    def matrix(self,f):
        a=[st.color for st in self.face(f)]
        return [a[i*self.n:(i+1)*self.n] for i in range(self.n)]
    def is_solved(self,supercube=False):
        return all(st.normal==st.home_normal and (not supercube or st.tangent==st.home_tangent) for st in self.stickers)
    def is_uniform(self):return all(len(set(st.color for st in self.face(f)))==1 for f in NORMALS)
    def moved(self,centres=True):
        return [st for st in self.stickers if st.pos!=st.home or st.normal!=st.home_normal or (centres and st.tangent!=st.home_tangent)]
    def cubies(self):
        out={}
        for st in self.stickers:out.setdefault(st.pos,[]).append(st)
        return out
    def fingerprint(self,orientation=False):
        return tuple((st.pos,st.normal,st.tangent if orientation else None) for st in self.stickers)

if __name__=='__main__':
    for n in [2,3,4,5]:
        moves=['R','U','F','D','L','B','Rw','2R','x','y','z']
        for m in moves:
            c=Cube(n).apply(' '.join([m]*4))
            assert c.fingerprint(True)==Cube(n).fingerprint(True),(n,m)
        a="R U R' U' F2 L D' B Rw U2 2R x y'"
        assert Cube(n).apply(a+' '+inverse(a)).fingerprint(True)==Cube(n).fingerprint(True)
    assert Cube(3).apply("R U R' U' "*6).is_solved(True)
    print('NxN model: turn orders, reversibility, sexy6 verified.')
