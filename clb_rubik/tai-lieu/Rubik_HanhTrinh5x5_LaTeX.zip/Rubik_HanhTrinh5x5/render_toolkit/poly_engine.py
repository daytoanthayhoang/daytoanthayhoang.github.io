"""Geometric sticker permutation model for Megaminx and Skewb checks."""
import numpy as np
from itertools import combinations,product
from copy import deepcopy
import re

def normalize(v):
    v=np.array(v,dtype=float);return v/np.linalg.norm(v)
def rotation(axis,angle):
    a=normalize(axis);x,y,z=a
    k=np.array([[0,-z,y],[z,0,-x],[-y,x,0]])
    return np.eye(3)*np.cos(angle)+(1-np.cos(angle))*np.outer(a,a)+np.sin(angle)*k
def inv(seq):
    def i(t):
        if t.endswith("'"):return t[:-1]
        return t+"'"
    return ' '.join(i(t) for t in seq.split()[::-1])
class Poly:
    def copy(self):return deepcopy(self)
    def apply(self,a):
        for t in a.split():self.move(t)
        return self
    def state(self):
        return tuple((tuple(np.round(p,7)),tuple(np.round(n,7))) for p,n,c,h,hn in self.stickers)
    def solved(self):return all(np.allclose(p,h) and np.allclose(n,hn) for p,n,c,h,hn in self.stickers)
    def changed(self):
        return [(c,np.round(p,4),np.round(n,4),np.round(h,4)) for p,n,c,h,hn in self.stickers if not(np.allclose(p,h) and np.allclose(n,hn))]
    def pieces(self):
        d={}
        for st in self.stickers:d.setdefault(tuple(np.round(st[0],6)),[]).append(st)
        return d
    def where(self,p):
        return tuple(f for f,n in self.normals.items() if abs(np.dot(p,n)-1)<1e-5)

class Mega(Poly):
    def __init__(self):
        a=1/np.sqrt(5);b=2/np.sqrt(5)
        self.normals={'U':np.array([0.,1.,0.]),'D':np.array([0.,-1.,0.])}
        ring=['F','R','BR','BL','L']
        for i,f in enumerate(ring):
            ang=i*2*np.pi/5
            self.normals[f]=np.array([b*np.sin(ang),a,b*np.cos(ang)])
        # Lower-right DR is opposite BL. Each lower name keeps visible role.
        for upper,lower in [('F','DB'),('R','DBL'),('BR','DL'),('BL','DR'),('L','DBR')]:
            self.normals[lower]=-self.normals[upper]
        self.stickers=[]
        # All centres, 30 edges, 20 corners from face-plane intersections.
        for k in [1,2,3]:
            for fs in combinations(self.normals,k):
                ns=[self.normals[f] for f in fs]
                if any(abs(np.dot(a,b)-1/np.sqrt(5))>1e-6 for a,b in combinations(ns,2)):continue
                vec=sum(ns);p=vec/np.dot(vec,ns[0])
                if np.max([np.dot(p,n) for n in self.normals.values()])>1+1e-5:continue
                for f,n in zip(fs,ns):self.stickers.append([p.copy(),n.copy(),f,p.copy(),n.copy()])
        assert len(self.stickers)==132,len(self.stickers)
    def move(self,t):
        m=re.fullmatch(r"(DBR|DBL|DR|DL|DB|BR|BL|[UDFRL])(\d*)('?)",t)
        if not m:raise ValueError(t)
        face,num,prime=m.groups();power=int(num or '1')*(-1 if prime else 1)
        n=self.normals[face];r=rotation(n,-power*2*np.pi/5)
        for st in self.stickers:
            if abs(np.dot(st[0],n)-1)<1e-5:
                st[0]=r@st[0];st[1]=r@st[1]
        return self

class Skewb(Poly):
    """Local axes R=UFR, L=UFL, B=UBR, K=UBL; no WCA ambiguity."""
    def __init__(self):
        self.normals={'R':np.array([1.,0,0]),'L':np.array([-1.,0,0]),'U':np.array([0.,1,0]),'D':np.array([0.,-1,0]),'F':np.array([0.,0,1]),'B':np.array([0.,0,-1])}
        self.axes={'R':np.array([1,1,1]),'L':np.array([-1,1,1]),'B':np.array([1,1,-1]),'K':np.array([-1,1,-1])}
        self.stickers=[]
        for f,n in self.normals.items():self.stickers.append([n.copy(),n.copy(),f,n.copy(),n.copy()])
        for p in product([-1,1],repeat=3):
            p=np.array(p,dtype=float)
            for f,n in self.normals.items():
                if np.dot(p,n)==1:self.stickers.append([p.copy(),n.copy(),f,p.copy(),n.copy()])
    def move(self,t):
        m=re.fullmatch(r"([RLBKxyz])(2?)(('?))",t)
        if not m:raise ValueError(t)
        f,num,prime,_=m.groups();power=int(num or '1')*(-1 if prime else 1)
        if f in 'xyz':
            n=np.eye(3)['xyz'.index(f)];r=rotation(n,-power*np.pi/2)
            for st in self.stickers:st[0]=r@st[0];st[1]=r@st[1]
        else:
            n=self.axes[f];r=rotation(n,-power*2*np.pi/3)
            for st in self.stickers:
                if np.dot(st[0],n)>.5:st[0]=r@st[0];st[1]=r@st[1]
        return self

if __name__=='__main__':
    for cls,moves,period in [(Mega,['U','R','F','L','DR','BL'],5),(Skewb,['R','L','B','K'],3)]:
        for t in moves:assert cls().apply(' '.join([t]*period)).solved(),(cls,t)
        a=' '.join(moves);assert cls().apply(a+' '+inv(a)).solved()
    for name,a in [('cross',"F R U R' U' F'"),('edgeperm',"R U R' U R U' U' R' U"),('sexy',"R U R' U'")]:
        c=Mega().apply(a)
        print(name, 'changed pieces', [(c.where(sts[0][0]),'/'.join(x[2] for x in sts)) for sts in c.pieces().values() if any(not np.allclose(s[0],s[3]) or not np.allclose(s[1],s[4]) for s in sts)])
