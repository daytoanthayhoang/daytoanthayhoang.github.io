"""Original vector diagrams from exact puzzle states. No external images."""
from pathlib import Path
import math,re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon,FancyArrowPatch,Rectangle
import matplotlib.patheffects as pe
from cube_engine import Cube,NORMALS,BASES,inverse,tokens
from poly_engine import Mega,Skewb,normalize,rotation

OUT=Path(__file__).parent/'assets';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42,'axes.unicode_minus':False})
# Standard BOY colour scheme, reoriented by z2 from white-up / green-front.
# The book normally starts yellow-up / white-down / green-front, therefore
# RIGHT IS ORANGE and LEFT IS RED.  Swapping only U/D would mirror a real cube.
COL={'U':'#F4D846','D':'#F7F7F3','F':'#38A878','R':'#F4A546','L':'#E65E58','B':'#548DC4'}
COLOR_LETTERS={'U':'Y','D':'W','F':'G','R':'O','L':'R','B':'B'}
COLOR_NAMES={'U':'vàng','D':'trắng','F':'xanh lá','R':'cam','L':'đỏ','B':'xanh dương'}
INK='#16374A';ACC='#B24317';MUTED='#DCE4E6';TEAL='#067C83'
CAM=np.array([5.,4.,7.])
def projection(cam=CAM):
    cam=normalize(cam);right=normalize(np.cross([0,1,0],cam));up=np.cross(cam,right)
    return np.stack([right,up]),cam
def project(pts,cam=CAM):return np.array(pts)@projection(cam)[0].T
def camera_view_label(cam=CAM):
    _,view=projection(cam)
    faces=[f for f in ['U','D','F','B','R','L'] if np.dot(NORMALS[f],view)>1e-5]
    return 'Nhìn '+' · '.join(faces)
def add_view_marks(ax,cam=CAM,face_badges=True,footer=True,fontsize=8):
    """Position names are boxed; they are never colour abbreviations."""
    pm,view=projection(cam)
    if face_badges:
        for f in ['U','D','F','B','R','L']:
            norm=np.array(NORMALS[f])
            if np.dot(norm,view)<=1e-5:continue
            xy=(norm*1.23)@pm.T
            if f in 'UD':xy+=np.array([0,.29 if xy[1]>0 else -.22])
            else:xy+=np.array([.26 if xy[0]>0 else -.26,-.06])
            ax.text(*xy,f,ha='center',va='center',fontsize=fontsize,
                    fontweight='bold',color=INK,zorder=11,
                    bbox=dict(boxstyle='round,pad=.12',fc='white',ec=INK,lw=.55,alpha=.96))
    if footer:
        ax.text(.5,.018,camera_view_label(cam),transform=ax.transAxes,
                ha='center',va='bottom',fontsize=9.5,color=INK,zorder=12,
                bbox=dict(facecolor='white',edgecolor='none',pad=.9,alpha=.96))
def turn_arc(face,direction=1,double=False,offset=1.055,radius=.60):
    """An exact quarter/half turn in the face's outward-facing plane."""
    norm=np.array(NORMALS[face]);e1,e2=map(np.array,BASES[face])
    sweep=math.pi if double else math.pi/2
    angles=np.linspace(math.radians(155),math.radians(155)-direction*sweep,42)
    return np.array([offset*norm+radius*(np.cos(a)*e1+np.sin(a)*e2) for a in angles])
def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',pad_inches=.06,facecolor='white')
    fig.savefig(OUT/(name+'.png'),dpi=140,bbox_inches='tight',pad_inches=.06,facecolor='white')
    plt.close(fig)
def frame(ax):
    ax.set_aspect('equal');ax.axis('off');ax.set_xlim(-1.85,1.85);ax.set_ylim(-1.88,1.85)
def parse_move(t,n):
    m=re.fullmatch(r"(\d*)([URFDLBurfdlb])(w?)(2'?|'?)",t)
    if not m:return None
    num,f,w,suf=m.groups();face=f.upper();norm=np.array(NORMALS[face]);axis=np.flatnonzero(norm)[0];sign=norm[axis]
    if w:count=int(num or 2);select=lambda p:sign*p[axis]>=n-1-2*(count-1)
    elif num or f.islower():depth=int(num or 2);select=lambda p:sign*p[axis]==n-1-2*(depth-1)
    else:select=lambda p:sign*p[axis]==n-1
    return face,select,(-1 if suf=="'" else 1),('2' in suf)
def draw_cube(ax,c,move=None,title=None,cam=CAM,labels=False,gray=None,mark_centres=False,highlight=None,view_marks=True):
    pmat,view=projection(cam);n=c.n;sel=parse_move(move,n) if move else None
    visible=[st for st in c.stickers if np.dot(st.normal,view)>1e-5]
    visible.sort(key=lambda st:np.dot(st.normal,view))
    for st in visible:
        f=next(f for f,v in NORMALS.items() if tuple(v)==st.normal)
        e1,e2=map(np.array,BASES[f]);norm=np.array(st.normal)
        center=np.array(st.pos)/n+norm/n;half=.92/n
        verts=np.array([center+half*(a*e1+b*e2) for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]])
        color=COL[st.color]
        if gray and not gray(st):color=MUTED
        hc=bool(sel and sel[1](st.pos)) or bool(highlight and highlight(st))
        ax.add_patch(Polygon(verts@pmat.T,fc=color,ec=ACC if hc else INK,lw=1.4 if hc else .55,joinstyle='round',zorder=2))
        xy=center@pmat.T
        if labels:
            text=COLOR_LETTERS[st.color]
            ax.text(*xy,text,ha='center',va='center',fontsize=max(5,11-n),color=INK,zorder=3)
        if mark_centres and sum(v==0 for v in st.pos)==2:
            p1=(center-.2*np.array(st.tangent))@pmat.T;p2=(center+.23*np.array(st.tangent))@pmat.T
            ax.add_patch(FancyArrowPatch(p1,p2,arrowstyle='-|>',mutation_scale=10,color=INK,lw=1.4,zorder=4))
    if sel:
        face,_,direction,double=sel
        depth,letter,wide,_=re.fullmatch(r"(\d*)([URFDLBurfdlb])(w?)(2'?|'?)",move).groups()
        inner=(bool(depth) or letter.islower()) and not wide
        offset=(n-1-2*(int(depth or 2)-1))/n if inner else 1.055
        path=turn_arc(face,direction,double,offset=offset,radius=1.12 if inner else .60)@pmat.T
        ax.plot(path[:,0],path[:,1],color=ACC,lw=2.1,zorder=6,path_effects=[pe.Stroke(linewidth=3.8,foreground='white'),pe.Normal()])
        ax.add_patch(FancyArrowPatch(path[-3],path[-1],arrowstyle='-|>',mutation_scale=14,color=ACC,lw=2,zorder=7))
    if title:ax.set_title(title,color=INK,fontsize=10,pad=2)
    frame(ax)
    if view_marks:add_view_marks(ax,cam)
def sequence(name,alg,n=3,start=None,cols=4,chunklabel=None):
    ts=tokens(alg);c=Cube(n) if start is None else start.copy();count=len(ts)+1
    rows=math.ceil(count/cols);fig,axs=plt.subplots(rows,cols,figsize=(2.35*cols,2.27*rows),squeeze=False)
    for i,ax in enumerate(axs.ravel()):
        if i<count:
            move=ts[i] if i<len(ts) else None
            title=f'{i+1}. {move}' if move else 'Kết quả'
            cam=CAM
            if move and re.match(r"\d*[Ll]",move):cam=[-5,4,7]
            if move and re.match(r"\d*[Bb]",move):cam=[5,4,-7]
            if move and re.match(r"\d*[Dd]",move):cam=[5,-4,7]
            draw_cube(ax,c,move,title,cam=cam)
            if move:c.move(move)
        else:ax.axis('off')
    fig.subplots_adjust(wspace=.06,hspace=.16)
    save(fig,name)
def draw_top(ax,c=None,mask=None,title=None,arrows=None,labels=False):
    if c is not None:states=c.face('U');n=c.n
    else:states=None;n=3
    for r in range(n):
        for col in range(n):
            idx=r*n+col
            color=COL[states[idx].color] if states is not None else (COL['U'] if (r,col) in (mask or []) else MUTED)
            ax.add_patch(Rectangle((col,n-r-1),.96,.96,fc=color,ec=INK,lw=.8))
            if labels and states is not None:ax.text(col+.48,n-r-.52,COLOR_LETTERS[states[idx].color],ha='center',va='center',fontsize=8)
    ax.text(n/2,-.28,'F · phía trước',ha='center',va='top',fontsize=8,color=INK)
    ax.text(n/2,n+.12,'B',ha='center',fontsize=8,color=INK)
    if arrows:
        coords={'UF':(1.48,.48),'UR':(2.48,1.48),'UB':(1.48,2.48),'UL':(.48,1.48),'UFR':(2.48,.48),'UFL':(.48,.48),'UBL':(.48,2.48),'UBR':(2.48,2.48)}
        for a,b in arrows:
            ax.add_patch(FancyArrowPatch(coords[a],coords[b],connectionstyle='arc3,rad=.18',arrowstyle='-|>',mutation_scale=12,lw=1.7,color=ACC,zorder=5))
    ax.set_xlim(-.2,n+.2);ax.set_ylim(-.58,n+.35);ax.set_aspect('equal');ax.axis('off')
    if title:ax.set_title(title,fontsize=10,color=INK)
def overview():
    fig,axs=plt.subplots(2,3,figsize=(9,5.3))
    for ax,n,name in zip(axs.ravel(),[2,3,4,5,3,3],['2×2 · các góc','3×3 · nền tảng','4×4 · tâm và cặp cạnh','5×5 · tâm và bộ ba cạnh','Mặt quay: R U F','Ba mặt còn lại: L D B']):
        draw_cube(ax,Cube(n),title=name,cam=CAM if 'còn' not in name else -CAM,labels=(n<4))
    save(fig,'cube_family')
def color_reference():
    fig,axs=plt.subplots(1,2,figsize=(10,4.05),gridspec_kw={'width_ratios':[1,1.45]})
    draw_cube(axs[0],Cube(),labels=True,title='Thế cầm mặc định của sách')
    ax=axs[1]
    layout={'U':(1,2),'L':(0,1),'F':(1,1),'R':(2,1),'B':(3,1),'D':(1,0)}
    for face,(x,y) in layout.items():
        ax.add_patch(Rectangle((x,y),.96,.96,fc=COL[face],ec=INK,lw=1.15))
        ax.text(x+.48,y+.64,face,ha='center',va='center',fontsize=15,fontweight='bold',color=INK)
        ax.text(x+.48,y+.30,COLOR_NAMES[face],ha='center',va='center',fontsize=10.5,color=INK)
    ax.set_xlim(-.14,4.10);ax.set_ylim(-.20,3.12);ax.set_aspect('equal');ax.axis('off')
    ax.set_title('Sơ đồ mở: giữ nguyên quan hệ sáu màu',fontsize=12,color=INK,pad=10)
    fig.subplots_adjust(left=.015,right=.99,bottom=.11,top=.88,wspace=.12)
    fig.text(.5,.025,'Vàng trên · trắng dưới · xanh lá trước · cam phải · đỏ trái · xanh dương sau',
             ha='center',fontsize=11,color=INK)
    save(fig,'cube_color_reference')
def notation():
    fig,axs=plt.subplots(2,3,figsize=(9,5.3))
    for ax,f,cam,txt in zip(axs.ravel(),'RUFLDB',[CAM,CAM,CAM,[-5,4,7],[5,-4,7],[5,4,-7]],['phải','trên','trước','trái','dưới','sau']):
        draw_cube(ax,Cube(),f,f'{f}: mặt {txt} · 90°',cam=cam)
    save(fig,'notation_faces')
    fig,axs=plt.subplots(1,3,figsize=(9,2.7))
    for ax,f in zip(axs,['R',"R'",'R2']):draw_cube(ax,Cube(),f,f)
    save(fig,'notation_prime')
    fig,axs=plt.subplots(1,4,figsize=(10,2.5))
    for ax,f,n in zip(axs,['R','Rw','2R','3Rw'],[4,4,4,5]):draw_cube(ax,Cube(n),f,f'{f} trên {n}×{n}')
    save(fig,'big_notation')
def core_figures():
    S="R U R' U'";C="F R U R' U' F'";E="R U R' U R U2 R' U";P="U R U' L' U R' U' L"
    sequence('cube3_sexy',S,cols=5)
    sequence('sexy_left',"L' U' L U",cols=5)
    sequence('cross_sequence',C,start=Cube().apply(inverse(C)),cols=4)
    sequence('edge_cycle_sequence',E,start=Cube().apply(inverse(E)),cols=5)
    sequence('corner_cycle_sequence',P,start=Cube().apply(inverse(P)),cols=5)
    sequence('middle_right_sequence',"U R U' R' U' F' U F",start=Cube().apply(inverse("U R U' R' U' F' U F")),cols=5)
    sequence('middle_left_sequence',"U' L' U L U F U' F'",start=Cube().apply(inverse("U' L' U L U F U' F'")),cols=5)
    fig,axs=plt.subplots(1,4,figsize=(10,2.8))
    for ax,mask,name in zip(axs,[[(1,1)],[(1,1),(0,1),(1,0)],[(1,1),(1,0),(1,2)],[(1,1),(0,1),(1,0),(1,2),(2,1)]],['Chấm','L ngược: UB + UL','Ngang: UL + UR','Dấu cộng']):draw_top(ax,mask=mask,title=name)
    save(fig,'cube3_yellow_cross')
    fig,axs=plt.subplots(1,2,figsize=(8,3.2))
    for ax,a,title in zip(axs,["U R U' R' U' F' U F","U' L' U L U F U' F'"],['Cạnh UF → khe FR','Cạnh UF → khe FL']):draw_cube(ax,Cube().apply(inverse(a)),title=title,labels=True)
    save(fig,'cube3_middle')
    fig,axs=plt.subplots(1,2,figsize=(7,3.1))
    draw_top(axs[0],Cube(),title='C: giữ nguyên vị trí UFR',arrows=[('UFL','UBR'),('UBR','UBL'),('UBL','UFL')])
    draw_cube(axs[1],Cube().apply(inverse(P)),title='Một trạng thái để tập C')
    save(fig,'cube3_corner_cycle')
    # Clockwise/counterclockwise orientation pattern generated from a legal twist sequence.
    twistsetup=inverse("R U R' U' "*2+"D "+"R U R' U' "*4+"D'")
    c=Cube().apply('x2').apply(twistsetup)
    fig,axs=plt.subplots(1,3,figsize=(9,2.9))
    draw_cube(axs[0],c,title='Vàng ở D; xử lý góc DFR',cam=[5,-3,7],highlight=lambda s:s.pos==(2,-2,2))
    draw_cube(axs[1],c,'R','Làm đủ R U R\' U\'')
    draw_cube(axs[2],c.copy().apply(S+' '+S),'D','Sau 2 nhịp S: dùng D chuyển trạm',cam=[5,-3,7])
    save(fig,'cube3_twist')
    fig,axs=plt.subplots(2,2,figsize=(8,6))
    for ax,a,title,cam in zip(axs.ravel(),["R U' R'","F' U F","R U R'","F' U' F"],['Cặp nối · R U\' R\'','Cặp nối · F\' U F','Cặp tách · R U R\'','Cặp tách · F\' U\' F'],[[-5,4,7],[5,4,-7],CAM,CAM]):draw_cube(ax,Cube().apply(inverse(a)),title=title,labels=True,cam=cam)
    save(fig,'f2l_insert')
    sequence('f2l_whiteup',"R U2 R' U' R U R'",start=Cube().apply(inverse("R U2 R' U' R U R'")),cols=4)
    fig,axs=plt.subplots(1,2,figsize=(8,3.6))
    for ax,a,t in zip(axs,["R U R' U R U2 R'","R U2 R' U' R U' R'"],['Đúng mẫu Sune','Đúng mẫu Anti-Sune']):draw_cube(ax,Cube().apply(inverse(a)),title=t,gray=lambda s:s.color=='U')
    save(fig,'speed_sune')
    fig,ax=plt.subplots(figsize=(3.5,3.3));draw_top(ax,Cube(),title='T-perm',arrows=[('UFR','UBR'),('UBR','UFR'),('UL','UR'),('UR','UL')]);save(fig,'speed_tperm')
    fig,ax=plt.subplots(figsize=(3.5,3.3));draw_top(ax,Cube(),title='Ua: cạnh UB đứng yên',arrows=[('UF','UR'),('UR','UL'),('UL','UF')]);save(fig,'speed_uperm')
    fig,axs=plt.subplots(1,2,figsize=(8,3.2));draw_cube(axs[0],Cube(2),title='Một tầng hoàn chỉnh',cam=[5,-4,7],labels=True)
    bad=Cube(2).apply("x2 R U R' U' R' F R2 U' R' U' R U R' F' x2");draw_cube(axs[1],bad,title='Mặt D đồng màu; dải bên chưa khớp',cam=[5,-4,7],labels=True);save(fig,'cube2_layer')

def big_figures():
    a4="Rw U2 x Rw U2 Rw U2 Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw'"
    a5="Rw U2 x Rw U2 Rw U2 3Rw' U2 Lw U2 Rw' U2 Rw U2 Rw' U2 Rw'"
    pp="2R2 U2 2R2 Uw2 2R2 Uw2 U2"
    fig,axs=plt.subplots(1,3,figsize=(10,3))
    for ax,n,a,t in zip(axs,[4,4,5],[a4,pp,a5],['4×4 · cạnh UF đảo','4×4 · UF và UB đổi chỗ','5×5 · cánh ngược mảnh giữa']):
        c=Cube(n).apply(inverse(a));draw_cube(ax,c,title=t,labels=(n==4))
    save(fig,'parity_compare')
    fig,axs=plt.subplots(1,2,figsize=(8,3))
    for ax,n in zip(axs,[4,5]):draw_cube(ax,Cube(n),title=f'{n}×{n}: tâm và cạnh',highlight=lambda s:sum(abs(v)==n-1 for v in s.pos)<3)
    save(fig,'big_structure')
    sequence('cube4_bar',"Rw U2 Rw'",4,start=Cube(4).apply(inverse("Rw U2 Rw'")),cols=4)
    sequence('edge_flip_sequence',"R U R' F R' F' R",4,cols=4)
    sequence('slice_pair_sequence',"2U' R U R' F R' F' R 2U",4,cols=5)
    # Proof-style cycle diagrams for the last two centres.
    fig,axs=plt.subplots(1,2,figsize=(9,3.6))
    for ax,n,t in zip(axs,[4,5],['4×4: tâm 2×2','5×5: tâm 3×3']):
        k=n-2
        for face,off in [('U',0),('F',k+1)]:
            for row in range(k):
                for col in range(k):ax.add_patch(Rectangle((off+col,k-row-1),.94,.94,fc=COL[face],ec=INK,lw=.7))
            ax.text(off+k/2,k+.2,face,ha='center',fontweight='bold',color=INK)
        pts=[(k-.5,k-.5),(k+1.5,k-.5),(2*k+.5,k-.5)]
        for a,b in zip(pts,pts[1:]+pts[:1]):ax.add_patch(FancyArrowPatch(a,b,connectionstyle='arc3,rad=.30',arrowstyle='-|>',mutation_scale=13,lw=1.8,color=ACC))
        ax.set_xlim(-.3,2*k+1.3);ax.set_ylim(-.4,k+.8);ax.set_aspect('equal');ax.axis('off');ax.set_title(t,color=INK)
    save(fig,'centres_cycle')
def mirror():
    fig,axs=plt.subplots(1,2,figsize=(8,3.4))
    for ax,ns,txt in zip(axs,[[[.18,.33,.49],[.26,.33,.41],[.12,.33,.55]],[[.32,.68]]*3],['Mirror 3×3 · ba lớp theo mỗi trục','Mirror 2×2 đối xứng · hai độ dày a, b']):
        pm,v=projection()
        cuts=[np.array([-1]+list(-1+2*np.cumsum(a))) for a in ns]
        for axis in [2,0,1]:
            norm=np.eye(3)[axis];others=[i for i in range(3) if i!=axis]
            for i in range(len(ns[others[0]])):
                for j in range(len(ns[others[1]])):
                    verts=[]
                    for aa,bb in [(i,j),(i+1,j),(i+1,j+1),(i,j+1)]:
                        p=np.zeros(3);p[axis]=1;p[others[0]]=cuts[others[0]][aa];p[others[1]]=cuts[others[1]][bb];verts.append(p)
                    ax.add_patch(Polygon(np.array(verts)@pm.T,fc=['#B9C6CB','#DEE4E7','#F1F3F4'][axis],ec=INK,lw=.9))
        frame(ax);ax.set_title(txt,fontsize=9,color=INK)
    save(fig,'mirror_dimensions')
    fig,axs=plt.subplots(1,2,figsize=(8,2.8))
    for ax,widths,title in zip(axs,[[1,1,1],[1,.65,1.35]],['Đúng: phẳng và liên tục ở cả hai mặt','Chưa đúng: mặt trên phẳng, mặt bên lệch']):
        x=0
        for w in widths:
            ax.add_patch(Rectangle((x,0),w,.65,fc='#C2CFD4',ec=INK));ax.add_patch(Polygon([[x,.65],[x+.25,.92],[x+w+.25,.92],[x+w,.65]],fc='#E9EEF0',ec=INK));x+=w
        ax.plot([1,1],[-.2,1.12],'--',c=ACC,lw=1);ax.plot([2,2],[-.2,1.12],'--',c=ACC,lw=1)
        ax.set_xlim(-.2,3.5);ax.set_ylim(-.4,1.4);ax.set_aspect('equal');ax.axis('off');ax.set_title(title,fontsize=9)
    save(fig,'mirror_flatness')
    fig,axs=plt.subplots(1,2,figsize=(8,3))
    draw_cube(axs[0],Cube(),title='Khung cơ chế: các trục R, U, F',mark_centres=True)
    draw_cube(axs[1],Cube().apply("M E M' U M E' M' U'"),title='Tâm L +90°; tâm U −90°',cam=[-5,4,7],mark_centres=True)
    save(fig,'ghost_centers')
    fig,axs=plt.subplots(1,2,figsize=(8,3.2))
    for ax,t in zip(axs,['Chốt khung cơ chế trước khi giải','Khôi phục dáng hộp ở cuối']):
        draw_cube(ax,Cube(),title=t,gray=lambda s:False,mark_centres=True)
    axs[0].text(0,-1.55,'R / U / F theo trục cơ khí',ha='center',fontsize=8,color=INK)
    axs[1].text(0,-1.55,'Sơ đồ khái niệm; không mô phỏng góc cắt Ninja',ha='center',fontsize=7,color=INK)
    save(fig,'ghost_frames')

if __name__=='__main__':
    overview();color_reference();notation();core_figures();big_figures();mirror()
    print('Vector assets:',len(list(OUT.glob('*.pdf'))))
