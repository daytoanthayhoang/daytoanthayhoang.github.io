"""Shared, exact-state visual lessons for Rubik workbook v2.

make_visual(prefix, alg, start, draw_state, turn_state, case_titles=...,
            notes=None, compact_cols=6)
draw_state(ax, state, move=None, title=None, large=False)
turn_state(state, token) may mutate and return None or return a new state.
notes may be a list (one entry per move), token->text dict, or (token,index)->str.
Writes *_case.pdf/png (large before/after), *_strip.pdf/png (compact complete
sequence), *_large.pdf/png (three panels per row). All frames are BEFORE
their labelled move. The last frame is AFTER the complete sequence.
"""
from copy import deepcopy
import math,re,textwrap
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
import matplotlib.patheffects as pe
from cube_engine import Cube, NORMALS, BASES, inverse
from draw_figures import save, draw_cube, projection, CAM, INK, TEAL, ACC, OUT, turn_arc


def _words(alg):
    return alg.replace('’',"'").replace('′',"'").split() if isinstance(alg,str) else list(alg)


def _advance(state, move, turn):
    out=turn(state,move)
    return state if out is None else out


def _note(notes,token,index):
    if callable(notes): return str(notes(token,index))
    if isinstance(notes,dict): return str(notes.get(token,''))
    if notes is not None and index<len(notes): return str(notes[index])
    return ''


def make_visual(prefix,alg,start,draw_state,turn_state,
                case_titles=('Trước khi làm','Sau trọn chuỗi'),notes=None,compact_cols=6):
    moves=_words(alg); states=[deepcopy(start)]
    for m in moves:states.append(deepcopy(_advance(deepcopy(states[-1]),m,turn_state)))
    fig,axs=plt.subplots(1,2,figsize=(8.6,4.25))
    for ax,s,title in zip(axs,[states[0],states[-1]],case_titles):
        draw_state(ax,s,move=None,title=None,large=True)
        title='\n'.join(textwrap.fill(line,width=30,break_long_words=False,break_on_hyphens=False) for line in title.split('\n'))
        ax.set_title(title,fontsize=14,color=INK,pad=10,fontweight='bold')
    fig.subplots_adjust(wspace=.10,top=.86,bottom=.03)
    save(fig,prefix+'_case')
    for suffix,cols in [('strip',compact_cols),('large',3)]:
        if suffix=='large':cols=min(cols,len(states))
        count=len(states);rows=math.ceil(count/cols)
        width=2.35*cols;height=(3.05 if suffix=='strip' else 2.72)*rows
        fig,axs=plt.subplots(rows,cols,figsize=(width,height),squeeze=False)
        for i,ax in enumerate(axs.ravel()):
            if i>=count:ax.axis('off');continue
            move=moves[i] if i<len(moves) else None
            draw_state(ax,states[i],move=move,title=None,large=(suffix=='large'))
            label=f'{i+1:02d}  {move}' if move else f'{i+1:02d}  KẾT QUẢ'
            ax.set_title(label,fontsize=(17 if move else 14) if suffix=='strip' else 14,color=INK,
                         fontweight='bold',pad=4)
            line=_note(notes,move,i) if move else 'Kiểm tra kết quả'
            if line:ax.text(.5,-.025,line,transform=ax.transAxes,ha='center',va='top',
                            color=TEAL,fontsize=13.5 if suffix=='strip' else 10,
                            linespacing=1.12,clip_on=False)
        if suffix=='strip':
            # Keep a fixed column scale even for a one-move strip.  Saving the
            # whole canvas avoids cropping empty columns and re-enlarging them
            # when LaTeX scales the file to one line of text.
            fig.subplots_adjust(left=.02,right=.98,wspace=.10,hspace=.37,
                                top=1-.36/height,bottom=.50/height)
            fig.savefig(OUT/(prefix+'_strip.pdf'),bbox_inches=None,facecolor='white')
            fig.savefig(OUT/(prefix+'_strip.png'),dpi=140,bbox_inches=None,facecolor='white')
            plt.close(fig)
        else:
            fig.subplots_adjust(wspace=.10,hspace=.31,top=.92,bottom=.09)
            save(fig,prefix+'_'+suffix)
    return {'prefix':prefix,'alg':' '.join(moves),'moves':len(moves),'frames':len(states)}


def cube_move_note(t,index=0):
    m=re.fullmatch(r"(\d*)([URFDLBurfdlbMESxyz])(w?)(2'?|'?)",t)
    if not m:return t
    depth,f,w,end=m.groups();face=f.upper()
    names={'R':'phải','L':'trái','U':'trên','D':'dưới','F':'trước','B':'sau'}
    if f in 'xyz':
        base={'x':'R','y':'U','z':'F'}[f]
        return 'CẢ KHỐI\n'+base+('2' if '2' in end else ("'" if end=="'" else ''))
    if f in 'MES':
        base={'M':'L','E':'D','S':'F'}[f]
        return 'Chỉ lát giữa\nTheo '+base+('2' if '2' in end else ("'" if end=="'" else ''))
    what=(str(int(depth or 2))+' lớp '+names[face]) if w else (
          ('Lát '+str(int(depth or 2))+' '+names[face]) if depth or f.islower() else names[face].capitalize())
    direction='Nửa vòng 180°' if '2' in end else ('Ngược 90°' if end=="'" else 'Thuận 90°')
    return what+'\n'+direction


def cube_camera(move):
    if not move:return CAM,None
    f=re.sub(r'^\d+','',move)[0]
    if f in 'LlM':return np.array([-5.,4.,7.]),'Góc nhìn phía trái'
    if f in 'Bb':return np.array([5.,4.,-7.]),'Góc nhìn phía sau'
    if f in 'DdE':return np.array([5.,-4.,7.]),'Góc nhìn phía dưới'
    return CAM,None


def _special_arrow(ax,token,cam):
    m=re.fullmatch(r"([MESxyz])(2'?|'?)",token)
    if not m:return
    face,end=m.groups();is_whole=face in 'xyz'
    ref={'x':'R','y':'U','z':'F','M':'L','E':'D','S':'F'}[face]
    norm=np.array(NORMALS[ref]);e1,e2=map(np.array,BASES[ref]);pm,_=projection(cam)
    direct=-1 if end=="'" else 1
    # Slices rotate in a parallel midplane; whole-cube arrows sit outside the shell.
    offset=1.11 if is_whole else .02
    radius=.92 if is_whole else .81
    path=turn_arc(ref,direct,'2' in end,offset=offset,radius=radius)@pm.T
    ax.plot(path[:,0],path[:,1],color=ACC,lw=2.2,zorder=7,
            path_effects=[pe.Stroke(linewidth=4.1,foreground='white'),pe.Normal()])
    ax.add_patch(FancyArrowPatch(path[-3],path[-1],arrowstyle='-|>',
                 mutation_scale=15,color=ACC,lw=2,zorder=8))


def cube_draw(ax,state,move=None,title=None,large=False,highlight=None,mark_centres=False):
    cam,camera_label=cube_camera(move)
    special=bool(move and re.match(r'^[MESxyz]',move))
    hi=highlight if move is None else None
    if special:
        f=move[0]
        if f in 'xyz':sel=lambda st:True
        else:
            axis={'M':0,'E':1,'S':2}[f]
            sel=lambda st:st.pos[axis]==0
        hi=sel
    draw_cube(ax,state,move=None if special else move,title=title,cam=cam,
              labels=False,highlight=hi,mark_centres=mark_centres)
    if special:_special_arrow(ax,move,cam)
    # draw_cube labels every view, including the result and standard U/F/R view.


def cube_visual(prefix,alg,n=3,start=None,
                case_titles=('Trước khi làm','Sau trọn chuỗi'),
                highlight=None,mark_centres=False,notes=None,case_cam=None):
    moves=_words(alg)
    if start is None:start=Cube(n).apply(inverse(' '.join(moves)))
    def drawer(ax,s,move=None,title=None,large=False):
        if move is None and large and case_cam is not None:
            return draw_cube(ax,s,title=title,cam=case_cam,highlight=highlight,mark_centres=mark_centres)
        return cube_draw(ax,s,move,title,large,highlight,mark_centres)
    return make_visual(prefix,moves,start,drawer,lambda s,t:s.move(t),
                       case_titles=case_titles,notes=cube_move_note if notes is None else notes)
