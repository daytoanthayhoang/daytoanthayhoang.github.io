"""Strict authoring API. All states begin solved and retain a replayable history.

Palette: U yellow, D white, F green, R orange, L red, B blue.
Face letters describe fixed spatial positions, never color names.
Lowercase r/l/u/d/f/b means INNER SECOND LAYER here, not wide.
Prefer explicit 2R and Rw to avoid cross-source ambiguity.
"""
from collections import Counter,defaultdict,deque
from copy import deepcopy
from pathlib import Path
import json,math,re
import numpy as np
from cube_engine import Cube as EngineCube,NORMALS,BASES,inverse as _inverse

COLOR_LETTERS={'U':'Y','D':'W','F':'G','R':'O','L':'R','B':'B'}
COLOR_NAMES={'U':'vàng','D':'trắng','F':'xanh lá','R':'cam','L':'đỏ','B':'xanh dương'}
CORNERS=['URF','UFL','ULB','UBR','DFR','DLF','DBL','DRB']
EDGES=['UR','UF','UL','UB','DR','DF','DL','DB','FR','FL','BL','BR']
REV={v:k for k,v in NORMALS.items()}


def canonical_move(token,n):
    if not isinstance(n,int) or isinstance(n,bool) or n<2:raise ValueError('Cube size must be an integer >= 2')
    token=token.replace('’',"'").replace('′',"'")
    m=re.fullmatch(r"(\d*)([URFDLBurfdlbMESxyz])(w?)(2'?|'?)",token)
    if not m:raise ValueError('Unsupported move: '+token)
    pre,f,w,end=m.groups();end='2' if '2' in end else end
    if f in 'xyzMES':
        if pre or w:raise ValueError('Rotations and middle slices cannot have depth or w: '+token)
        if f in 'MES' and n%2==0:raise ValueError('No unique middle slice exists on an even cube; use explicit 2R/2U/2F: '+token)
        return f+end
    if f.islower():
        if w:raise ValueError('Ambiguous lowercase wide move; write Rw or explicit 2R: '+token)
        pre=pre or '2';f=f.upper()
    if w:
        width=int(pre or 2)
        if not 2<=width<=n:raise ValueError(f'Wide width must be 2..{n}: '+token)
        return (str(width) if width!=2 else '')+f+'w'+end
    if pre:
        depth=int(pre)
        if not 1<=depth<=n:raise ValueError(f'Layer depth must be 1..{n}: '+token)
        return (str(depth) if depth!=1 else '')+f+end
    return f+end


def canonical_algorithm(algorithm,n=3):
    if isinstance(algorithm,str):
        algorithm=algorithm.replace('(', ' ').replace(')', ' ').replace('|',' ').split()
    return [canonical_move(t,n) for t in algorithm]


def inverse(algorithm,n=3):return _inverse(' '.join(canonical_algorithm(algorithm,n)))


class Cube(EngineCube):
    def __init__(self,n=3):
        if not isinstance(n,int) or isinstance(n,bool) or n<2:raise ValueError('Cube size must be an integer >= 2')
        super().__init__(n);self.history=[]
    def move(self,t):
        t=canonical_move(t,self.n);super().move(t);self.history.append(t);return self
    def apply(self,alg):
        # Validate the entire sequence first: failure never leaves a half-run state.
        for t in canonical_algorithm(alg,self.n):self.move(t)
        return self
    def export(self):return export_state(self)
    def validate(self):return validate_state(self,require_history=True)


def pos(name,n=3):return tuple(sum(NORMALS[f][i]*(n-1) for f in name) for i in range(3))
def at(c,p):
    if isinstance(p,str):p=pos(p,c.n)
    return {REV[s.normal]:s.color for s in c.stickers if s.pos==p}
def located(c,home):
    if isinstance(home,str):home=pos(home,c.n)
    ss=[s for s in c.stickers if s.home==home]
    return ss[0].pos,{REV[s.normal]:s.color for s in ss}
def exact(c,predicate):return all(s.pos==s.home and s.normal==s.home_normal for s in c.stickers if predicate(s))
def bounds(p,n):return sum(abs(v)==n-1 for v in p)
def lower_layers_solved(c):return exact(c,lambda s:s.home[1]<c.s)
def corners_solved(c):return exact(c,lambda s:bounds(s.home,c.n)==3)
def centers_solved(c):return all(s.normal==s.home_normal for s in c.stickers if bounds(s.home,c.n)==1)
def edge_group(c,name):
    target=pos(name,c.n)
    return [(p,{REV[s.normal]:s.color for s in ss}) for p,ss in c.cubies().items() if len(ss)==2 and all(p[i]==v for i,v in enumerate(target) if v)]
def paired(c,name):
    return len({tuple(sorted(v.items())) for _,v in edge_group(c,name)})==1

def parity(p):return sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))%2

_UNDO=None

def _orientation_undo():
    global _UNDO
    if _UNDO is not None:return _UNDO
    _UNDO={};q=deque([(EngineCube(),'')])
    while q:
        c,a=q.popleft();key=tuple(at(c,f)[f] for f in 'URFDLB')
        if key in _UNDO:continue
        _UNDO[key]=_inverse(a)
        for m in ['x','y','z']:q.append((c.copy().move(m),(a+' '+m).strip()))
    return _UNDO


def validate_state(c,require_history=False):
    """Reject corrupt states; replayable provenance is required for publishing.

    Structural checks alone are necessary, not a full reachability proof for
    arbitrary NxN hand-painted states. A matching legal move history supplies
    that proof. For 3x3, independent standard cubie constraints are checked too.
    """
    errors=[];h=c.s;grid=set(range(-h,h+1,2));home=EngineCube(c.n)
    if len(c.stickers)!=6*c.n*c.n:errors.append('wrong sticker count')
    if len({(s.pos,s.normal) for s in c.stickers})!=len(c.stickers):errors.append('duplicate sticker slot')
    if Counter(s.color for s in c.stickers)!=Counter(s.color for s in home.stickers):errors.append('wrong color count')
    homes=defaultdict(list)
    for s in c.stickers:
        homes[s.home].append(s)
        if any(v not in grid for v in s.pos):errors.append('off-grid position')
        if s.normal not in REV or sum(a*b for a,b in zip(s.pos,s.normal))!=h:errors.append('non-outward sticker')
        if sum(v*v for v in s.tangent)!=1 or sum(a*b for a,b in zip(s.normal,s.tangent)):errors.append('invalid tangent')
        if sorted(map(abs,s.pos))!=sorted(map(abs,s.home)):errors.append('changed piece orbit')
    for ss in homes.values():
        if len({s.pos for s in ss})!=1:errors.append('cubie split across positions')
        if len(ss)==3:
            if round(np.linalg.det([s.home_normal for s in ss]))!=round(np.linalg.det([s.normal for s in ss])):errors.append('reflected corner')
        if len(ss)==2 and all(v!=0 for v in ss[0].home):
            a,b=ss
            if round(np.linalg.det([a.home_normal,b.home_normal,a.home]))!=round(np.linalg.det([a.normal,b.normal,a.pos])):errors.append('reflected wing')
    cubie_report=None
    if not errors and c.n==3:
        key=tuple(at(c,f)[f] for f in 'URFDLB')
        undo=_orientation_undo().get(key)
        if undo is None:errors.append('center frame is not a rigid cube rotation')
        else:
            q=c.copy().apply(undo);cp=[];co=[];ep=[];eo=[]
            for name in CORNERS:
                d=at(q,name);colors=[d[f] for f in name]
                ident=next((i for i,n in enumerate(CORNERS) if set(n)==set(colors)),None)
                if ident is None:errors.append('impossible corner colors');break
                ori=next(i for i,v in enumerate(colors) if v in 'UD')
                if colors[(ori+1)%3]!=CORNERS[ident][1] or colors[(ori+2)%3]!=CORNERS[ident][2]:errors.append('reflected corner colors')
                cp.append(ident);co.append(ori)
            for name in EDGES:
                d=at(q,name);colors=''.join(d[f] for f in name)
                ident=next((i for i,n in enumerate(EDGES) if set(n)==set(colors)),None)
                if ident is None:errors.append('impossible edge colors');break
                ep.append(ident);eo.append(int(colors!=EDGES[ident]))
            if len(cp)==8 and len(ep)==12:
                cubie_report={'corner_twist_mod3':sum(co)%3,'edge_flip_mod2':sum(eo)%2,'corner_parity':parity(cp),'edge_parity':parity(ep)}
                if len(set(cp))!=8 or len(set(ep))!=12 or sum(co)%3 or sum(eo)%2 or parity(cp)!=parity(ep):errors.append('3x3 orientation/permutation invariant violated')
    provenance=False
    if hasattr(c,'history'):
        replay=EngineCube(c.n).apply(' '.join(canonical_algorithm(c.history,c.n)))
        provenance=(replay.fingerprint(True)==c.fingerprint(True) and [(s.color,s.home,s.home_normal,s.home_tangent) for s in replay.stickers]==[(s.color,s.home,s.home_normal,s.home_tangent) for s in c.stickers])
        if not provenance:errors.append('state does not match its legal move history')
    elif require_history:errors.append('missing move history; use validated_cube.Cube(...).apply(setup)')
    return {'passed':not errors,'errors':sorted(set(errors)),'history_verified':provenance,'n':c.n,'stickers':len(c.stickers),'cubie_invariants':cubie_report}


def export_state(c):
    return {'n':c.n,'history':getattr(c,'history',None),'palette':COLOR_NAMES,'color_letters':COLOR_LETTERS,
            'faces':{f:c.matrix(f) for f in NORMALS},'validation':validate_state(c,require_history=True),
            'stickers':[{'pos':s.pos,'normal':s.normal,'tangent':s.tangent,'color':s.color,'home':s.home,'home_normal':s.home_normal,'home_tangent':s.home_tangent} for s in c.stickers]}


def sequence_states(start,algorithm):
    v=validate_state(start,require_history=True)
    if not v['passed']:raise ValueError(v)
    moves=canonical_algorithm(algorithm,start.n);states=[start.copy()]
    for m in moves:
        states.append(states[-1].copy().move(m));v=validate_state(states[-1],require_history=True)
        if not v['passed']:raise ValueError(v)
    return moves,states


def render_lesson(outdir,prefix,start,algorithm,*,before='Trước khi làm',after='Sau trọn chuỗi',
                  recognition=None,result_checks=None,highlight_homes=(),recognition_cameras=None,
                  columns=3,labels=True):
    """Large recognition, before/after, complete step strip, plus auditable JSON.

    No inverse-generated default: the caller must supply an explicit legal
    start and should supply independent recognition/result predicates.
    Strip frames show the state BEFORE their numbered move; final is AFTER.
    All cameras are labeled by the visible positional faces.
    """
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from draw_figures import draw_cube,CAM,INK
    from visual_sequences import cube_camera,_special_arrow
    moves,states=sequence_states(start,algorithm)
    predicates=[]
    for kind,checks,state in [('recognition',recognition or {},states[0]),('result',result_checks or {},states[-1])]:
        for name,predicate in checks.items():
            passed=bool(predicate(state));predicates.append({'type':kind,'claim':name,'passed':passed})
            if not passed:raise ValueError('Failed '+kind+' predicate: '+name)
    outdir=Path(outdir);outdir.mkdir(parents=True,exist_ok=True)
    if not re.fullmatch(r'[A-Za-z0-9_-]+',prefix):raise ValueError('Prefix must be a simple filename stem')
    homes={pos(p,start.n) if isinstance(p,str) else tuple(p) for p in highlight_homes}
    highlight=(lambda s:s.home in homes) if homes else None
    artifacts=[]
    def save(fig,suffix):
        for ext in ['pdf','png']:
            p=outdir/(prefix+'_'+suffix+'.'+ext);fig.savefig(p,bbox_inches='tight',pad_inches=.10,dpi=180,facecolor='white');artifacts.append(str(p))
        plt.close(fig)
    cams=recognition_cameras or [CAM]
    fig,axs=plt.subplots(1,len(cams),figsize=(4.25*len(cams),4.45),squeeze=False)
    for ax,cam in zip(axs[0],cams):draw_cube(ax,states[0],title=before,cam=cam,labels=labels,highlight=highlight)
    save(fig,'recognition')
    fig,axs=plt.subplots(1,2,figsize=(8.6,4.5))
    for ax,c,title in zip(axs,[states[0],states[-1]],[before,after]):draw_cube(ax,c,title=title,cam=cams[0],labels=labels,highlight=highlight)
    save(fig,'case')
    cols=min(columns,len(states));rows=math.ceil(len(states)/cols)
    fig,axs=plt.subplots(rows,cols,figsize=(3.4*cols,3.65*rows),squeeze=False)
    frames=[]
    for i,ax in enumerate(axs.flat):
        if i>=len(states):ax.axis('off');continue
        move=moves[i] if i<len(moves) else None;cam,_=cube_camera(move)
        special=bool(move and move[0] in 'MESxyz');hi=None
        if special:
            if move[0] in 'xyz':hi=lambda st:True
            else:
                axis={'M':0,'E':1,'S':2}[move[0]];hi=lambda st:st.pos[axis]==0
        title=f'{i+1:02d}. {move}' if move else f'{i+1:02d}. KẾT QUẢ'
        draw_cube(ax,states[i],move=None if special else move,title=title,cam=cam,labels=labels,highlight=hi)
        if special:_special_arrow(ax,move,cam)
        frames.append({'index':i,'state_timing':'before_move' if move else 'after_sequence','next_move':move,'camera':list(map(float,cam)),'state':export_state(states[i])})
    fig.subplots_adjust(hspace=.25,wspace=.12);save(fig,'steps')
    sidecar={'prefix':prefix,'algorithm':' '.join(moves),'n':start.n,'palette':COLOR_NAMES,
             'source_setup':' '.join(start.history),'claims':predicates,'frames':frames,
             'limitations':'Validated legal move provenance and supplied predicates; not a guarantee that unprovided instructional claims are correct.'}
    path=outdir/(prefix+'_qa.json');path.write_text(json.dumps(sidecar,ensure_ascii=False,indent=2));artifacts.append(str(path))
    return {'artifacts':artifacts,'moves':len(moves),'frames':len(states),'claims':predicates,'qa':str(path)}
