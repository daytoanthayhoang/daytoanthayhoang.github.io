# 5×5 continuous-journey PDF layout QA

Result: FINAL PASS for visual release. No layout release blockers found. Metadata correction verified in final rebuild.

Reviewed file: `/workspace/scratch/a84c62516364/output/rubik/Rubik_HanhTrinh5x5_20261114/Rubik_HanhTrinh5x5.pdf`
Final SHA-256: `86b12b47f15e47823d5480dbc4392366d7864bbbc0d6fe21e108c445574fce57`
Initial reviewed SHA-256: `0e987a507ccfed87f0e978fd4cec5309a8c2504d93bba821d91b79fb078877ca`
Pages: 48 physical A4 pages. Page references below are physical PDF pages, not printed folios.

## Coverage and results

- Rendered all 48 pages at 110 dpi and inspected every page through 12 four-page contact sheets. Reopened physical pages 8, 9, 13, 31, 32, 44 and 47 at full rendered size for dense nets, slice arrows, checkpoint boxes, last-edge explanation, and scramble text.
- All text, tables, colored stickers, panel headings, arrows, face labels and checkpoint boxes are readable. No clipping, overlapping text/boxes, stray glyphs, or broken tcolorbox continuation observed. All PDF text spans are within page bounds; no text span is below 5 pt. Net row/column indices are approximately 6.1 pt and readable when enlarged.
- PDF-level panel inventory verified all 176 move panels and all 16 numbered checkpoint panels. Every stage's panel numbers and move tokens match the manifest in exact order, including the final checkpoint. This checks publication completeness/order, not the already completed mathematical proof.
- All 16 stages visibly follow target/recognition, find, why, decision, preserve, grouped moves, check and next. Working diagrams state when setup moves are already applied, and page 3 explains that move panels show the state before their move while checkpoint panels show the completed stage.
- Page 5 explicitly distinguishes R, 2R, 3R, Rw and 3Rw. Page 9 visually distinguishes second-inner and middle-slice arrows. Pages 31–32 emphasize that W5-10 move 08 is 3Rw′ (three layers), while other Rw moves turn two layers.
- Page 3 gives U yellow / D white / F green / R orange / L red / B blue and distinguishes regripping from camera changes. The visible colors in the initial net and the working diagrams agree with that convention. The U–F–L camera changes are visibly labeled on left-turn panels rather than presented as regrips.
- Page 6 clearly discloses 38/54 prepared center stickers, favorable pairs, incidental extra triples and favorable 3×3 pieces. Pages 24/26/28/30 repeat the incidental triple-count caveat at checkpoints.
- Pages 6 and 31 correctly identify the last-edge issue as white–green wings opposite the midge, not a 4×4 PLL-parity step. Pages 33 and 47 reiterate that all 12 triples must be complete before outer-layer solving.
- Physical pages 10, 13, 16, 19, 22, 24, 26, 28, 30, 33, 35, 37, 39, 41, 43 and 46 contain the 16 intact checkpoint boxes. The previous breakable-box/minipage failure is absent.
- Physical page 46 displays the final solved U/F/R view and directs checking all six faces. Physical page 47 contains the reproducible scramble and branching guidance.

## Final rebuild verification

The metadata title is now correctly “Hành trình Rubik 5×5 - Nguyễn Việt Hoàng”. Final PDF remains 48 pages, and the extracted text is byte-for-byte identical to the earlier reviewed PDF text. Raster differences occur only in the action-group headings/lists on physical pages 8, 11, 14, 17, 20, 23, 25, 27, 29, 31, 34, 36, 38, 40, 42 and 44. Every changed region was visually reinspected at the full 110-dpi render scale: all headings and lists remain intact, readable and free of overlap or clipping. All other pages are pixel-identical. The panel inventory was refreshed for the final hash: 176 moves plus 16 checkpoint panels, all ordered correctly. No source was modified during this review.

Optional polish only: physical page 4 has a single short paragraph and large whitespace, and several checkpoint pages are intentionally sparse. This does not interrupt the stage sequence or compromise readability; no reflow is required for release.

## Evidence

- `panel_inventory.json`: exact stage-to-page panel counts, sequence check, checksum and bounds check.
- `contact_01_04.jpg` through `contact_45_48.jpg`: all-page visual review sheets.
- `pages/page-01.png` through `pages/page-48.png`: rendered pages.
- `extracted.txt`: page-labelled PDF text.
- `audit_pdf.py`: reproducible panel inventory and text-bounds audit.

Final comparison evidence: `final_comparison.json`, `final_extracted.txt`, `final_changes_1.png` through `final_changes_4.png`, and `final_pages/`.
