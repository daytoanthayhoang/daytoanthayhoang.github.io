HÀNH TRÌNH RUBIK 5×5

Một ví dụ liên tục 16 chặng/176 nước, từ 0 tâm hoàn chỉnh và 0 bộ ba cạnh tới sáu mặt đồng màu. Khối xáo có chuẩn bị: 38/54 ô tâm đúng và các cặp thuận lợi được công khai. Không gọi đây là scramble ngẫu nhiên hoặc bộ giải tổng quát.

Biên dịch hai lần bằng XeLaTeX:
  xelatex Rubik_HanhTrinh5x5.tex
  xelatex Rubik_HanhTrinh5x5.tex
Cần TeX Live hoặc MiKTeX đầy đủ. Giữ rubikbook.sty, chapters và assets cạnh tệp chính. Các hình PDF vector đã sẵn, không cần mạng/Python để dựng tài liệu.

Dữ liệu dùng chung với web: data/walkthrough5.json. Tệp narrative chứa vài sửa lời cho dễ đọc, không đổi nước hoặc trạng thái. build_cube_journey.py có thể tái tạo hình/chương từ dữ liệu, dùng Python, numpy và matplotlib trong môi trường đã có các gói này. Bộ dựng kiểm từng sticker trước khi xuất hình.

Quy ước: 2R/3R là chỉ lớp thứ hai/thứ ba từ phải; Rw/3Rw là hai/ba lớp phải cùng quay. Tên mặt là vị trí, không phải màu. Trạng thái chuẩn: U vàng, D trắng, F xanh lá, R cam, L đỏ, B xanh dương; sau xoay cả khối, màu ở các vị trí đổi theo khối.

W5-10 là hai cánh ngược viên giữa của cạnh trắng–xanh lá tại UF. Đây là bước ghép cạnh còn thiếu, không phải PLL parity của 4×4. Khi đủ 6 tâm và 12 bộ ba đúng hướng, giải như 3×3.
