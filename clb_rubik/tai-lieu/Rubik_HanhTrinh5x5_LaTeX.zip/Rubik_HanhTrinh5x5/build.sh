#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
xelatex -interaction=nonstopmode -halt-on-error Rubik_HanhTrinh5x5.tex
xelatex -interaction=nonstopmode -halt-on-error Rubik_HanhTrinh5x5.tex
