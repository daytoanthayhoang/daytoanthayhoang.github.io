#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
xelatex -interaction=nonstopmode -halt-on-error Rubik_HanhTrinh3x3_2x2.tex
xelatex -interaction=nonstopmode -halt-on-error Rubik_HanhTrinh3x3_2x2.tex
