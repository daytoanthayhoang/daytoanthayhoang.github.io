HÀNH TRÌNH RUBIK 3×3 VÀ 2×2

Mỗi hành trình đi từ một scramble sư phạm có chủ ý tới khối hoàn chỉnh trên cùng một trạng thái liên tục. Không dùng các ca rời ghép lại rồi coi là một lần giải. Mốc nào có nước đổi cách cầm đều ghi trong timeline.

Biên dịch PDF:
  xelatex Rubik_HanhTrinh3x3_2x2.tex
  xelatex Rubik_HanhTrinh3x3_2x2.tex
Cần TeX Live hoặc MiKTeX đầy đủ. Giữ các thư mục chapters và assets cùng tệp rubikbook.sty. Hình đã là PDF vector nên không cần chạy Python hoặc truy cập mạng để biên dịch LaTeX.

Dữ liệu:
- data/walkthrough3.json và data/walkthrough2.json là các timeline dùng chung cho sách và mô phỏng.
- Các bước có trạng thái, nước quay, nhóm thao tác, mục tiêu, viên được chọn, kiểm tra và nhánh tiếp theo.
- Nếu có tệp narrative tương ứng, lời dẫn được gắn bằng ID và hash của manifest; không tự viết lại trạng thái.
- build_cube_journey.py tạo lại hình/chương từ dữ liệu, cần Python, numpy và matplotlib. Mỗi frame dựng lại phải khớp mọi sticker trong manifest.

Quy ước:
U vàng, D trắng, F xanh lá, R cam, L đỏ, B xanh dương ở thế chuẩn. Tên mặt là vị trí theo tay cầm; sau xoay cả khối phải đọc theo thế mới. Camera đổi chỉ để thấy viên khuất, không tự thêm động tác. Mỗi khung là trước nước ghi trên khung; KIỂM MỐC là sau trọn mốc.

Giới hạn:
Các ví dụ có chủ ý để dạy kỹ năng, không đại diện mọi scramble ngẫu nhiên và không dùng đo thành tích. Những ca không xuất hiện có chỉ dẫn rẽ nhánh; không hứa chuỗi của ví dụ giải được một khối xáo bất kỳ.
