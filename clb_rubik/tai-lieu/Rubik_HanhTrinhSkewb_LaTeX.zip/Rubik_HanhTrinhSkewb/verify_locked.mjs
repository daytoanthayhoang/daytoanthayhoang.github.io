import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
import {Skewb} from './data/skewb-engine.js';
const m=JSON.parse(readFileSync(new URL('./data/manifest.json',import.meta.url)));
const r=JSON.parse(readFileSync(new URL('./data/render-manifest.json',import.meta.url)));
const p=new Skewb().apply(m.scrambleAlgorithm);
assert.deepEqual(p.exportState(),m.initialState);
for(let i=0;i<m.frames.length;i++){
  const f=m.frames[i];assert.deepEqual(p.exportState(),f.state);assert.deepEqual(f.state,r.frames[i].state);
  assert.equal(p.signature(),f.signature);assert.deepEqual(p.metrics(),f.metrics);
  assert.deepEqual(p.renderData({inset:.93,offset:.009}),r.frames[i].polygons);
  assert.equal(r.frames[i].polygons.length,30);
  if(i<m.steps.length){const s=m.steps[i];assert.equal(p.signature(),s.beforeSignature);assert.deepEqual(p.animationDescriptor(s.token),s.animation);p.move(s.token);assert.equal(p.signature(),s.afterSignature);}
}
assert(p.isSolved());assert(p.metrics().exactSolved);assert.equal(m.stages.length,9);
for(const s of m.stages){assert.deepEqual(s.beforeState,m.frames[s.start].state);assert.deepEqual(s.afterState,m.frames[s.endExclusive].state);assert(s.predicatePassed);}
const qa={legal_scramble_reproduced:true,all_42_states_replayed:true,all_41_animation_descriptors_match:true,all_42_polygons_match_engine:true,all_42_metrics_match:true,all_9_stage_boundaries_match:true,final_solved:true};
writeFileSync(new URL('./qa/replay_check.json',import.meta.url),JSON.stringify(qa,null,2)+'\n');console.log(qa);
