#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
# Existing PDFs in assets allow TeX-only builds. To regenerate diagrams:
# MPLCONFIGDIR="$PWD/qa/matplotlib-cache" python3 build_skewb_print.py
# On this workspace the available XeLaTeX format is in the following location.
if [ -f /workspace/scratch/a84c62516364/output/math8/Bo_TuyenChon40_Web_20261114_cloud/kiemtra/xelatex.fmt ]; then
  export TEXMF='{/usr/share/texmf,/usr/share/texlive/texmf-dist}'
  export TEXFORMATS='/workspace/scratch/a84c62516364/output/math8/Bo_TuyenChon40_Web_20261114_cloud/kiemtra:'
fi
xelatex -interaction=nonstopmode -halt-on-error main.tex > qa/build1.txt
xelatex -interaction=nonstopmode -halt-on-error main.tex > qa/build2.txt
cp main.pdf Rubik_HanhTrinhSkewb.pdf
