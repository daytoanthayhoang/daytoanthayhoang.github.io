#!/usr/bin/env python3
"""Print-only typesetting. Never computes or changes the locked move trajectory."""
from pathlib import Path
import json, hashlib, math, re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle
ROOT=Path(__file__).resolve().parent
M=json.loads((ROOT/'data/manifest.json').read_text()); R=json.loads((ROOT/'data/render-manifest.json').read_text())['frames']
N={k:np.array(v,float) for k,v in {'R':[1,0,0],'L':[-1,0,0],'U':[0,1,0],'D':[0,-1,0],'F':[0,0,1],'B':[0,0,-1]}.items()}
FACE={'U':'Trên U','D':'Dưới D','F':'Trước F','B':'Sau B','R':'Phải R','L':'Trái L'}
INK='#16374a';TEAL='#067c83';WARM='#b65f21'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
assert len(M['steps'])==41 and len(R)==len(M['frames'])==42
assert all(r['state']==f['state'] for r,f in zip(R,M['frames']))
assert all(len(r['polygons'])==len(r['rawPolygons'])==30 for r in R)
assert all(s['predicatePassed'] for s in M['stages'])
assert M['frames'][40]['metrics']['exactSolved'] and M['frames'][41]['metrics']['exactSolved']
assert all(s['beforeSignature']==M['frames'][s['index']]['signature'] and s['afterSignature']==M['frames'][s['index']+1]['signature'] for s in M['steps'])

def tex(s):
 s=str(s).replace('–',' - ').replace('—',' - ')
 for a,b in [('\\',r'\textbackslash{}'),('&',r'\&'),('%',r'\%'),('_',r'\_'),('#',r'\#')]:s=s.replace(a,b)
 return s.replace('→',r'\(\to\)')
def static_palette(s):
 # Static explanations were authored with R=red/L=orange; bind their color
 # names to the locked manifest. This does not recolor source records.
 s=re.sub(r'\bđỏ\b','@@HOME_R@@',s)
 s=re.sub(r'\bcam\b','@@HOME_L@@',s)
 return s.replace('@@HOME_R@@',M['colorScheme']['R']['name']).replace('@@HOME_L@@',M['colorScheme']['L']['name'])
def piece(frame,pid):
 ps=[p for p in R[frame]['polygons'] if p['pieceId']==pid]
 return {'id':pid,'kind':ps[0]['kind'],'place':ps[0]['place'],'stickers':[{'colorVi':p['colorVi'],'face':p['face'],'color':p['color']} for p in ps]}
def name(p):return ('Góc ' if p['kind']=='corner' else 'Tâm ')+' - '.join(s['colorVi'] for s in p['stickers'])
def facings(p):return ', '.join(s['colorVi']+' ở '+s['face'] for s in p['stickers'])
def target_ids(stage):return stage['targets'][:6] if stage['index']==8 else stage['targets']
def project(vs,cam):
 pos=np.array(cam['position']);tar=np.array(cam['target']);z=pos-tar;z/=np.linalg.norm(z)
 x=np.cross(np.array([0.,1,0]),z);x/=np.linalg.norm(x);y=np.cross(z,x)
 vv=np.array(vs)*cam['worldScale']-pos;depth=-(vv@z);factor=1/np.tan(np.deg2rad(cam['fov'])/2)
 return np.c_[vv@x/depth*factor,vv@y/depth*factor],depth

def marker(ax,xy,num,fs=8.5):
 ax.text(*xy,str(num),ha='center',va='center',fontsize=fs,fontweight='bold',color=INK,bbox={'boxstyle':'circle,pad=.12','fc':'white','ec':TEAL,'lw':.8},zorder=20)
def view3d(ax,frame,ids):
 f=R[frame];visible=[]
 for p in f['polygons']:
  if np.dot(p['normal'],f['camera']['position'])<=0:continue
  xy,dep=project(p['vertices'],f['camera']);visible.append((float(np.mean(dep)),p,xy))
 allpts=np.concatenate([x[2] for x in visible]);lo=allpts.min(0);hi=allpts.max(0);mid=(lo+hi)/2;rad=max(hi-lo)*.69
 for _,p,xy in sorted(visible,reverse=True,key=lambda x:x[0]):
  ax.add_patch(Polygon(xy,fc=p['hex'],ec=INK,lw=.65,joinstyle='round'))
  if p['pieceId'] in ids:marker(ax,xy.mean(0),ids.index(p['pieceId'])+1,8.5)
 for fce,n in N.items():
  if np.dot(n,f['camera']['position'])<=0:continue
  xy,_=project([n*1.48],f['camera']);ax.text(*xy[0],fce,color=INK,ha='center',va='center',fontsize=11,fontweight='bold')
 ax.set_xlim(mid[0]-rad,mid[0]+rad);ax.set_ylim(mid[1]-rad,mid[1]+rad);ax.set_aspect('equal');ax.axis('off')

def faces(fig,frame,ids,rect):
 left,bot,width,height=rect
 for i,face in enumerate(['U','D','F','B','R','L']):
  ax=fig.add_axes([left+(i%3)*width/3,bot+(1-i//3)*height/2,width/3,height/2])
  n=N[face];u=np.array([1,0,0] if face in ['U','D','F'] else [0,0,-1] if face=='R' else [0,0,1] if face=='L' else [-1,0,0]);v=np.cross(n,u)
  for p in R[frame]['polygons']:
   if p['face']!=face:continue
   pts=np.array(p['vertices']);xy=np.c_[pts@u,pts@v]
   ax.add_patch(Polygon(xy,fc=p['hex'],ec=TEAL if p['pieceId'] in ids else INK,lw=1.25 if p['pieceId'] in ids else .6))
   if p['pieceId'] in ids:marker(ax,xy.mean(0),ids.index(p['pieceId'])+1,8.5)
  ax.text(0,-1.34,FACE[face],ha='center',va='center',fontsize=10,color=INK,fontweight='bold')
  ax.set_xlim(-1.2,1.2);ax.set_ylim(-1.58,1.12);ax.set_aspect('equal');ax.axis('off')

def dial(ax,step):
 a=step['animation'];col=WARM if a['whole'] else TEAL
 angle=a['angle'];theta=np.linspace(math.pi/2,math.pi/2+angle,100)
 xy=np.c_[np.cos(theta),np.sin(theta)]*.7
 ax.add_patch(Circle((0,0),.72,fill=False,ec='#ccd7df',lw=1))
 ax.plot(xy[:-3,0],xy[:-3,1],c=col,lw=2)
 ax.annotate('',xy[-1],xy[-7],arrowprops={'arrowstyle':'-|>','mutation_scale':12,'color':col,'lw':2})
 ax.text(0,0,step['token'],ha='center',va='center',fontsize=16,fontweight='bold',color=col)
 label={'y':'từ trên U','z':'từ trước F'}.get(a['axis'],'từ '+a['axisPlace'])
 ax.text(0,1.13,'NHÌN VÀO LÕI',ha='center',fontsize=8.5,color=INK)
 ax.text(0,-1.12,label,ha='center',fontsize=9,color=INK)
 ax.text(0,-1.58,f"{round(abs(angle)*180/math.pi)}° "+('thuận' if a['power']>0 else 'ngược'),ha='center',fontsize=9,color=col)
 ax.set_xlim(-1.35,1.35);ax.set_ylim(-1.85,1.5);ax.set_aspect('equal');ax.axis('off')

def figure(frame,ids,out,step=None):
 fig=plt.figure(figsize=(7.0,2.85),facecolor='white')
 ax=fig.add_axes([0,.20,.245,.68]);view3d(ax,frame,ids)
 fig.text(.12,.07,'Nhìn từ sau' if R[frame]['camera']['position'][2]<0 else 'Nhìn từ trước',ha='center',color=INK,fontsize=9)
 faces(fig,frame,ids,(.25,.02,.58 if step else .75,.96))
 if step:
  ax=fig.add_axes([.84,.22,.16,.68]);dial(ax,step)
 fig.savefig(ROOT/'assets'/out);plt.close(fig)

for i,s in enumerate(M['steps']):figure(i,target_ids(M['stages'][s['stageIndex']]),f'move_{i:03}.pdf',s)
for s in M['stages']:
 for kind,idx in [('before',s['start']),('after',s['endExclusive'])]:figure(idx,target_ids(s),f"stage{s['index']+1:02}_{kind}.pdf")
figure(0,['corner-DFR','center-D'],'start.pdf');figure(41,[],'solved.pdf')
fig=plt.figure(figsize=(5,4.4));view3d(fig.add_axes([0,0,1,1]),0,[]);fig.savefig(ROOT/'assets/cover.pdf');plt.close(fig)

# Instruction pages are deliberately distinct from the 41 state-before-move pages.
intro=r'''\chapter{Đọc Skewb mà chưa cần cầm khối}
\begin{notebox}{Một câu chuyện, không đổi khối giữa chừng}
Ta bắt đầu với tâm trắng ở dưới và chưa có góc trắng nào hướng xuống. Từng mảnh đi qua \textbf{9 chặng, 41 thao tác, 42 trạng thái}. Sau thao tác 40, khối đã giải xong; thao tác 41 chỉ trả cách cầm.
\end{notebox}
\textbf{Đây là mẫu xáo được chuẩn bị để dạy học.} Mẫu không ngẫu nhiên và tài liệu này không phải bộ giải mọi trạng thái Skewb. Đọc mục tiêu, nhận dạng đúng mảnh và hướng màu rồi mới dùng nhóm thao tác. Không chạy nguyên dãy nếu khối của em khác hình.
\section*{Skewb khác khối chia ô vuông}
Skewb có \textbf{8 mảnh góc} (mỗi mảnh mang 3 tam giác màu) và \textbf{6 mảnh tâm} (mỗi mảnh mang 1 hình thoi). Tổng cộng 30 ô màu. Một nước vặn ở đây quay một nửa khối \textbf{120° quanh đường chéo qua đỉnh}, tác động đến 4 góc và 3 tâm. Không có nước U xoay một tầng vuông như 3×3.
\includegraphics[width=\linewidth]{assets/start.pdf}
{\small Trạng thái 0. Số 1 đánh dấu cùng một góc trắng - xanh lá - đỏ trên các mặt thấy được; số 2 là tâm trắng. Các mặt bị khuất trong hình phối cảnh vẫn có trong sáu hình vuông.}
\begin{checkpointbox}{Cách dùng mỗi chặng}
\textbf{Mục tiêu → tìm mảnh → vì sao → từng nước → kiểm → đi tiếp.}
Mỗi hình dưới một thao tác đều là trạng thái \textbf{TRƯỚC} khi xoay. Dòng ``Sau nước này'' cho biết mảnh đang theo dõi sẽ đi đâu; khung tiếp theo là kết quả chính xác đó. Hết chặng có một hình \textbf{SAU} riêng để đối chiếu.
\end{checkpointbox}
\clearpage
\section*{Tên mặt là vị trí, màu là danh tính mảnh}
\begin{tabularx}{\linewidth}{@{}lYlY@{}}\toprule
U & trên & D & dưới\\
F & trước & B & sau\\
R & phải & L & trái\\\bottomrule\end{tabularx}
\textbf{UFR} là đỉnh trên - trước - phải; \textbf{UFL} là trên - trước - trái; \textbf{UBR} là trên - sau - phải. \textbf{DFR} là khe dưới - trước - phải, được dùng như một trạm lắp góc. Khi xoay cả khối, mảnh mang màu cũ có thể chuyển sang tên vị trí mới.

Ở đầu và cuối hành trình: \textbf{trắng D, vàng U, xanh lá F, xanh dương B, đỏ R, cam L}. Trong khi giải, tâm bên có thể sai. Hãy nhận mảnh góc bằng \textbf{đủ ba màu}, không theo màu tâm bên đang lệch.
\begin{notebox}{Cách đọc số trong hình}
Cùng một số nằm trên các ô thuộc \textbf{cùng một mảnh vật lý}. Số được đặt lại theo danh sách ``Tìm đúng mảnh'' ở đầu mỗi chặng; không mang số của chặng trước sang chặng mới. Viền xanh đậm là vùng đang theo dõi, không phải màu mới của khối. Vòng trắng chứa số che một phần nhỏ ô màu chỉ để ghi chú.
\end{notebox}
\textbf{Sáu hình vuông là sáu mặt nhìn thẳng từ ngoài vào.} Chúng không phải một hình khai triển để gấp lại. Ở bốn mặt bên F/B/R/L, phía trên hình là U. Ở mặt U, phía trên hình là B và phía dưới là F. Ở mặt D, phía trên hình là F và phía dưới là B. Phải đọc nhãn mặt trước khi tìm số; hình mặt sau không được lật gương.
\section*{Hai việc khác nhau}
\begin{itemize}
\item \textbf{Đổi góc quan sát:} sách có thể cho nhìn từ phía sau để thấy mảnh. Khối không được xoay; U/D/F/B/R/L vẫn giữ nguyên. Một số hình, như đầu chặng 3 và 6, nhìn từ phía sau. Nhãn dưới phối cảnh ghi rõ hướng quan sát.
\item \textbf{Đổi cách cầm:} thao tác y, y2, z hoặc z' xoay \emph{toàn bộ} khối, làm mảnh chuyển sang vị trí U/D/F/B/R/L khác. Các mảnh vẫn giữ quan hệ với nhau.
\end{itemize}
\begin{cautionbox}{Đừng kết luận giữa nhóm}
Một góc đã làm đúng có thể tạm rời vị trí khi ``mở - lắp - trả''. Câu ``phần phải giữ'' luôn nói về \textbf{cuối cả nhóm}. Chỉ kiểm kết quả của chặng sau khi làm hết nhóm, kể cả lần đổi cách cầm cuối cùng.
\end{cautionbox}
\clearpage
\section*{Ký hiệu cục bộ: đọc trục trước, đọc chiều sau}
\textbf{Ký hiệu này theo mô hình của sách, không phải ánh xạ ký hiệu thi đấu WCA.} Không lấy tên R/L/B của 3×3 hoặc một hướng dẫn Skewb khác để đoán.
\begin{tabularx}{\linewidth}{@{}lYY@{}}\toprule
Ký hiệu & Trục và phần xoay & Chiều nhìn\\\midrule
R, R' & Nửa khối quanh đỉnh UFR & Từ UFR vào lõi\\
L, L' & Nửa khối quanh đỉnh UFL & Từ UFL vào lõi\\
B, B' & Nửa khối quanh đỉnh UBR & Từ UBR vào lõi\\
y, y2 & Cả khối quanh trục trên - dưới & Từ U vào lõi\\
z, z' & Cả khối quanh trục trước - sau & Từ F vào lõi\\\bottomrule\end{tabularx}
Không có dấu phẩy: \textbf{thuận chiều kim đồng hồ} theo hướng nhìn ở bảng. Có dấu phẩy: \textbf{ngược chiều kim đồng hồ}. R/L/B đều quay 120°. y và z quay 90°, y2 quay 180°.
\begin{checkpointbox}{Mũi tên trong mặt đồng hồ}
Mặt đồng hồ bên phải mỗi thao tác cho chiều xoay khi em nhìn \textbf{thẳng từ đỉnh hoặc mặt đã ghi vào lõi}. Nó không nằm trên một mặt của hình phối cảnh. Đọc nhãn ``từ UFR'', ``từ UFL'', ``từ UBR'', ``từ trên U'' hoặc ``từ trước F'' trước khi đọc mũi tên. Mũi tên xanh: vặn nửa khối; mũi tên nâu: xoay cả khối.
\end{checkpointbox}
\section*{Hai nhóm sẽ gặp lại}
\textbf{SK-K} = \alg{R' L R L'}: bốn nước vặn góc. Trong ca cụ thể của chặng 5, nhóm này hoàn tất khung tám góc. Không gọi tên nhóm này là một nước ``K''.

\textbf{SK-G} = \alg{R' L R L' y2 R' L R L' y2}: hai SK-K, xen và kết bằng y2. Sau đủ nhóm, các tâm ở \(U\to F\to B\to U\), còn các góc và tâm ở D/L/R được giữ. Sách vẫn tách rõ cả 10 thao tác.
\begin{cautionbox}{41 không phải số nước thi đấu}
Dãy gồm \textbf{31 lần vặn góc và 10 lần xoay cả khối}. Sách đánh số tất cả để em không bỏ qua đổi cách cầm. Đây không phải số nước theo cách đếm thi đấu.
\end{cautionbox}
'''
(ROOT/'chapters/intro.tex').write_text(static_palette(intro))

def table_targets(frame,ids):
 lines=[r'\begin{tabularx}{\linewidth}{@{}rYlY@{}}\toprule',r'Số & Mảnh & Vị trí & Hướng từng màu\\\midrule']
 for j,pid in enumerate(ids):
  p=piece(frame,pid);lines.append(f'{j+1} & {tex(name(p))} & {p["place"]} & {tex(facings(p))}'+r'\\')
 return '\n'.join(lines+[r'\bottomrule\end{tabularx}'])

out=[r'\chapter{Một đường giải liên tục}']
for s in M['stages']:
 n=s['index']+1;start,end=s['start'],s['endExclusive'];ids=target_ids(s)
 if n>1:out.append(r'\clearpage')
 out += [r'\section{'+str(n)+'. '+tex(s['title'])+'}',r'\label{stage'+str(n)+'}',r'\textbf{Mục tiêu.} '+tex(s['goal']),r'\textbf{Điểm xuất phát.} Trạng thái '+str(start)+r', ngay sau chặng trước.' if start else r'\textbf{Điểm xuất phát.} Trạng thái 0, khối xáo của ví dụ.',r'\includegraphics[width=\linewidth]{assets/stage'+f'{n:02}'+r'_before.pdf}',r'\step{Tìm đúng mảnh trước chặng}',table_targets(start,ids),r'\step{Vì sao dùng nhóm này?}',tex(s['why']),r'\textbf{Phần phải giữ sau cả nhóm.} '+tex(s['preserve']),r'\begin{checkpointbox}{Nhóm thao tác của chặng '+str(n)+'}',r'\alg{'+tex(s['algorithm'])+'}',r'\par Từ trạng thái '+str(start)+' đến '+str(end)+'. Mỗi thao tác được vẽ riêng ở trang sau.',r'\end{checkpointbox}']
 # Two complete, unbreakable move blocks per page.
 for a in range(start,end,2):
  out += [r'\clearpage',r'{\large\bfseries\color{teal}Chặng '+str(n)+r' · Theo từng thao tác}\par\smallskip']
  for i in range(a,min(a+2,end)):
   st=M['steps'][i];an=st['animation'];pid=ids[0];b=piece(i,pid);af=piece(i+1,pid)
   direction='thuận' if an['power']>0 else 'ngược';angle=round(abs(an['angle'])*180/math.pi)
   act=('Xoay CẢ KHỐI' if an['whole'] else 'Vặn nửa khối quanh đỉnh '+an['axisPlace'])
   view={'y':'trên U','z':'trước F'}.get(an['axis'],an['axisPlace'])
   after='Vị trí '+b['place']+r'\(\to\)'+af['place']+'. '+tex(facings(af)[0].upper()+facings(af)[1:])+'.'
   if b['place']==af['place'] and b['stickers']==af['stickers']:after='Mảnh số 1 giữ nguyên vị trí và hướng màu. Các mảnh khác vẫn xoay theo thao tác.'
   follow=('Đến điểm kiểm của chặng ở trang sau.' if i+1==end else 'Hình kế tiếp là trạng thái '+str(i+1)+', trước '+M['steps'][i+1]['token']+'.')
   out += [r'\begin{minipage}{\linewidth}',r'{\bfseries '+str(i+1)+r'. \alg{'+tex(st['token'])+r'} \quad | \quad TRƯỚC: trạng thái '+str(i)+r'}\par',r'{\small '+tex(act)+f'; {angle}° {direction}, nhìn từ '+tex(view)+r' vào lõi.}\par',r'\includegraphics[width=\linewidth]{assets/move_'+f'{i:03}'+r'.pdf}',r'{\small\textbf{Tìm số 1.} '+tex(name(b))+', ở '+b['place']+'. '+tex(facings(b)[0].upper()+facings(b)[1:])+r'.\par',r'\textbf{Sau nước này.} '+after+r'\par',r'\textbf{Đi tiếp.} '+tex(follow)+r'}',r'\end{minipage}',r'\par\vspace{5mm}']
  if end-start==1:
   out += [r'\step{Đối chiếu ngay: SAU thao tác '+str(end)+'}',r'\includegraphics[width=\linewidth]{assets/stage'+f'{n:02}'+r'_after.pdf}',r'{\small '+tex(s['check'].replace('Kéo mô hình để xem cả đáy và sau.','Đối chiếu cả đáy D và phía sau B trong hình.').replace('solved','giải xong'))+r' Bảng kiểm chi tiết ở trang sau.}']
 # Checkpoint page keeps stage highlights, even if the next stage changes its targets or camera.
 ck=s['check'].replace('Kéo mô hình để xem cả đáy và sau.','Đối chiếu cả mặt D và B trong sáu hình vuông.').replace('solved','giải xong')
 afterm=s['afterMetrics'];metrics=f"{len(afterm['solvedCorners'])}/8 góc đúng; {len(afterm['solvedCenters'])}/6 tâm đúng; {len(afterm['uniformFaces'])}/6 mặt đồng màu."
 if n==3:metrics+=' Con số 4/8 gồm 3 góc trắng vừa làm và 1 góc vàng tình cờ đã đúng.'
 out += [r'\clearpage',r'{\LARGE\bfseries\color{ink}Kiểm sau chặng '+str(n)+r'}\par\smallskip',r'\textbf{SAU thao tác '+str(end)+' · Trạng thái '+str(end)+r'.} '+tex(ck),r'\includegraphics[width=\linewidth]{assets/stage'+f'{n:02}'+r'_after.pdf}',r'\step{Các mảnh vừa theo dõi đang ở đâu?}',table_targets(end,ids),r'\begin{checkpointbox}{Đếm bằng toàn bộ khối}',tex(metrics),r'\par ``Đúng'' xét theo khung màu và cách cầm hiện tại; xoay cả khối không làm khối đã giải thành sai.',r'\end{checkpointbox}',r'\step{Đi tiếp}',tex(s['next']).replace('solved','giải xong')]
 if n<9:out += [r'\textbf{Nối mạch.} Chặng '+str(n+1)+' bắt đầu chính từ trạng thái '+str(end)+r' này. Khối không bị xáo lại; số đánh dấu mảnh có thể đổi để theo mục tiêu mới.']
 else:out += [r'\textbf{Đã hoàn tất.} Mỗi mặt có một tâm hình thoi và bốn tam giác góc cùng màu. Không còn thao tác giải nào sau đây.']
(ROOT/'chapters/journey.tex').write_text('\n'.join(out))

end=[r'\chapter{Tự kiểm và dùng lại kiến thức}',r'\section*{Ba câu hỏi trước khi xoay}',r'\begin{enumerate}',r'\item Mảnh nào là mục tiêu? Em đã nhận bằng đủ màu chưa?',r'\item Nó đang ở vị trí nào, và từng màu đang hướng ra mặt nào?',r'\item Sau cả nhóm, điều gì phải đúng trở lại? Nếu khối khác hình, em có dừng nhận dạng lại không?',r'\end{enumerate}',r'\section*{Khi khối khác ví dụ}',r'\begin{description}']
for b in M['branchNotes']:end.append(r'\item['+tex(b['condition'])+'] '+tex(b['action']).replace('solved','giải xong'))
end += [r'\end{description}',r'Các nhánh trên chỉ là cảnh báo nhận dạng. Sách chưa vẽ chuỗi riêng cho chúng, nên không coi chúng là một lời giải đầy đủ cho mọi trạng thái.',r'\clearpage\section*{Tái tạo đúng khối xáo để thực hành}',r'Bắt đầu từ khối đã giải: trắng D, vàng U, xanh lá F, xanh dương B, đỏ R, cam L. Dùng đúng ký hiệu cục bộ đã học. y2\textquotesingle\ là 180° ngược; kết quả vị trí giống y2. Dãy sau tạo chính trạng thái 0, không phải xáo ngẫu nhiên.',r'\begin{checkpointbox}{Dãy chuẩn bị, không phải dãy giải}']
tokens=M['scrambleAlgorithm'].split()
for i in range(0,len(tokens),10):end.append(r'\alg{'+tex(' '.join(tokens[i:i+10]))+r'}\par')
end += [r'\end{checkpointbox}',r'\includegraphics[width=\linewidth]{assets/start.pdf}',r'\textbf{Kiểm trước khi học.} Tâm trắng ở D, không có góc trắng nào hướng xuống. Góc trắng - xanh lá - đỏ ở UFL: trắng nhìn L, xanh lá nhìn U, đỏ nhìn F. Nếu khác, kiểm dãy chuẩn bị trước khi bắt đầu chặng 1.',r'\section*{Bảng nối các điểm kiểm}',r'\begin{tabularx}{\linewidth}{@{}rllY@{}}\toprule',r'Chặng & Từ & Đến & Kết quả chính\\\midrule']
short=['1 góc trắng đúng','2 góc trắng đúng','3 góc trắng đúng','Mặt trắng hoàn chỉnh','8 góc tạo khung đúng','Trắng, vàng và mặt đỏ đúng','Đỏ xuống D; trắng L; vàng R','6 mặt đồng màu, khối đã giải','Trả trắng D và vàng U']
for s,ss in zip(M['stages'],short):end.append(f"{s['index']+1} & {s['start']} & {s['endExclusive']} & {ss}"+r'\\')
end += [r'\bottomrule\end{tabularx}',r'\clearpage\section*{Nguồn và phạm vi đối chiếu}',r'\begin{itemize}']
for src in M['sources']:end.append(r'\item '+tex(src['title'])+r': \url{'+src['url']+'}.')
end += [r'\end{itemize}',r'Các nguồn trên hỗ trợ cấu trúc học cơ bản và đối chiếu ký hiệu. Hành trình cụ thể trong sách dùng ký hiệu cục bộ đã khai báo, không khẳng định ký hiệu của mọi nguồn là tương đương.',r'\begin{notebox}{Cách giữ hình và lời cùng một trạng thái}',r'42 trạng thái, 41 thao tác và 9 điểm kiểm được đọc nguyên từ dữ liệu khóa của hành trình. Các hình in dùng đúng 24 tam giác và 6 hình thoi của mỗi trạng thái; màu không được tô theo suy đoán. Sách chỉ thêm số mảnh, nhãn mặt và mặt đồng hồ chỉ chiều. Sáu mặt nhìn thẳng dùng cùng dữ liệu với hình phối cảnh.',r'\end{notebox}',r'Bộ dữ liệu nguồn đã được kiểm bằng các phép quay và phép ngược, đối chiếu chu trình mảnh độc lập và mô hình tính riêng. Bản in kiểm thêm sự khớp đủ 42 trạng thái, đủ 41 hình trước thao tác, 9 điểm kiểm sau chặng và trạng thái cuối giải đúng. Đây là kiểm mô hình và bản in, không phải chứng nhận kiểm thử tương tác của website.',r'\includegraphics[width=\linewidth]{assets/solved.pdf}',r'\textbf{Đích cuối.} Trên vàng, dưới trắng, trước xanh lá, sau xanh dương, phải đỏ, trái cam. Cả 30 ô đều khớp mặt của mình.']
(ROOT/'chapters/end.tex').write_text(static_palette('\n'.join(end)))
qa={'manifest_sha256':hashlib.sha256((ROOT/'data/manifest.json').read_bytes()).hexdigest(),'render_manifest_sha256':hashlib.sha256((ROOT/'data/render-manifest.json').read_bytes()).hexdigest(),'frames':42,'stages':9,'operations':41,'corner_turns':31,'whole_rotations':10,'exact_state_matches':42,'move_before_after_signature_matches':41,'semantic_checkpoints':9,'solved_frame':40,'original_grip_restored_frame':41,'colored_stickers_each_frame':30,'all_move_figures_before_state':True,'figure_label_pt_min':8.5,'figure_label_pt_min_printed':8.31,'arrow_rule':'angle from animationDescriptor; viewpoint explicitly from axisPlace or U/F into core; no projected false face arrow','source_trajectory_changed':False}
(ROOT/'qa/source_check.json').write_text(json.dumps(qa,indent=2,ensure_ascii=False)+'\n')
print('Built 41 before-move panels,18 checkpoint panels,3 reference panels and chapters.')

# Full-width figures and tables are paragraph blocks, never inline boxes.
for path in (ROOT/'chapters').glob('*.tex'):
    s=path.read_text()
    s=re.sub(r'(\\includegraphics\[[^\]]*\]\{[^}]*\})', lambda m:r'\par\noindent '+m.group(1)+r'\par',s)
    s=s.replace(r'\begin{tabularx}',r'\par\noindent\begin{tabularx}').replace(r'\end{tabularx}',r'\end{tabularx}\par')
    s=s.replace('``Đúng xét','“Đúng” xét')
    path.write_text(s)
