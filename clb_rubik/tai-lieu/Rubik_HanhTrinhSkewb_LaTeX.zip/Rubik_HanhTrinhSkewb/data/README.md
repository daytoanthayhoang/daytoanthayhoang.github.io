# Skewb continuous teaching route

Production deliverable: `site/`. Copy its contents into `clb_rubik/skewb/`. No live site, other worker directory, or GitHub repository was modified. Nothing was published.

## Content and mechanics

- A **single prepared legal state**, 9 stages, 41 operations, 42 exact snapshots. The 41 include whole-puzzle regrips, so they are not a WCA turn count.
- Taught sequence: white corners **0 → 1 → 2 → 3 → 4**, upper-corner case 0, yellow center, regrip, three side centers, return grip. The puzzle is already solved at frame 40; frame 41 only restores the original orientation.
- Initial preparation is openly disclosed. It is not a random scramble and not a general-purpose solver. Missing branches are listed in the route.
- Real Skewb mechanics: **8 corner solids + 6 center solids; 24 triangular stickers + 6 diamond stickers**. Each turn moves four corners and three centers by 120° about a body diagonal. The cut planes pass through the origin. No cubelet surrogate is used.
- Idealized solid partition of the cube [-1,1]^3: each corner is the convex hull of the origin, that corner, and its three incident edge midpoints (volume 1/2). Each center is a diamond pyramid from the origin to its face's four edge midpoints (volume 2/3). Total volume 8, with no overlaps in tested interior samples. Retail hardware internals are not modeled.
- Coordinates: +X right, +Y up, +Z front. Initial color home: D white, U yellow, F green, B blue, R orange, L red.

## Notation safeguard

This follows the book's **local notation**, explicitly not WCA Skewb notation: R through UFR, L through UFL, B through UBR; clockwise viewed from that vertex toward the core. The engine additionally accepts K through UBL for tests, but that axis is not exposed in the teaching route. The book's four-move group is called **SK-K** in the UI to avoid colliding with that internal K token. SK-K expands to R' L R L'. SK-G expands to SK-K y2 SK-K y2. y/y2/z are real whole-puzzle regrips; camera orbit is only observation.

The exact primary sources are in `site/manifest.json`:
- https://sarah.cubing.net/skewb/my-method (beginner-stage structure, explicitly its own notation)
- https://www.gancube.com/pages/gancube-tutorials-skewb
- https://www.worldcubeassociation.org/regulations/#12h (comparison, NOT claimed as local axis mapping)
- https://www.worldcubeassociation.org/regulations/#12a4 (whole-puzzle rotations)

The local source book chapter and its model were independently checked: `rubik_upgrade/source_material/extracted_v2_1/chapters/skewb.tex`, `poly_engine.py`, `draw_skewb.py`.

## Engine API

`Skewb.fromState(state)` / `new Skewb(state)`, `.fromState`, `.clone`, `.move(token)`, `.apply(sequence)`, `.exportState`, `.signature`, `.metrics`, `.piece(id)`, `.pieceHull(id)`, `.renderData`, `.stickerState`, `.animationDescriptor`, `.isSolved`.

State stores 14 exact proper signed-permutation orientation matrices and the whole-puzzle grip matrix. Position and sticker normals are derived, never separately drifted. Center rotation about its own normal is not an observable sticker error. `.validate()` rejects duplicate/invalid sticker slots and improper matrices; it is **not a complete reachability validator for arbitrary externally constructed states**. Every shipped state has an explicit legal move derivation and is independently replayed.

`.renderData()` returns flat sticker records `{id,pieceId,kind,slotId,place,face,color,hex,normal,vertices}` with 3 or 4 vertices. `pieceHull(id)` returns five vertices of the actual solid. `animationDescriptor()` contains `{vector,origin,angle,pieceIds,stickerIds,whole,axisPlace,...}`. `SkewbView` supports `setState`, `setHighlights`, `previewMove`, `commitMove`, `cancelPreview`, `dispose`.

## Production controls

- True pause/resume within a fractional turn; no state commits until the turn finishes.
- Speed 0.5×–2×; one-step and one-group transport both directions.
- Stage selector, range seek, chapter checkpoints and move-rail seek.
- Six camera presets plus stage camera and free orbit; labeled fixed local axes.
- Find/why/check/next linked to exact physical piece identities; six flat face maps.
- WebGL flat-color renderer; automatic SVG fallback plus `?renderer=svg`. SVG hides opaque body hulls. SVG highlight lines are culled by current face normal so hidden faces do not draw across the front.
- Keyboard Space, arrows, Shift+arrows, Home/End; mobile responsive styles and focus states.

## Print/renderer contract

`site/render-manifest.json` has all 42 full states, cameras, raw and inset polygons, and transformed five-vertex hulls with stable piece IDs. Coordinates are puzzle-space. Apply `camera.worldScale=1.25` once, with the given perspective parameters and target. Each frame references:
- `site/print/000.svg` through `041.svg`: projected true Skewb polygons.
- `site/print/000-faces.svg` through `041-faces.svg`: all six current faces in vector form.

These SVGs are vector renderings, not browser screenshots. They are generated from the same exact engine state as the interactive route.

## Regenerate and test

Run from workspace root:

```sh
node rubik_web/skewb_work/build-walkthrough.mjs
cp rubik_web/skewb_work/walkthrough-skewb.json rubik_web/skewb_work/site/manifest.json
cp rubik_web/skewb_work/skewb-engine.js rubik_web/skewb_work/skewb-three.js rubik_web/skewb_work/site/
node rubik_web/skewb_work/export-vectors.mjs
node --test rubik_web/skewb_work/skewb.test.mjs rubik_web/skewb_work/site/site.test.mjs
python rubik_web/skewb_work/verify-python-reference.py
cd rubik_web
./node_modules/.bin/esbuild skewb_work/site/app.js --bundle --minify --format=esm --outfile=skewb_work/site/app.bundle.js --legal-comments=linked
```

## Validation boundaries

18 automated suites passed: solid partition/areas/winding; turns and inverse identities; strict parse/import atomicity; **2,000 mixed moves versus an independent explicit named-cycle oracle**; book rescue cases, K and G semantic effects; all 42 snapshots, highlights, backward paths, checkpoints; animation endpoints and camera fitting; production transport repeated/interrupted flows; SVG color/shape fallback. The original Python floating-point Rodrigues implementation additionally agrees on all 42 snapshots and a 600-move mixed sequence. This is not merely an inverse-cancellation test.

The exact SVGRenderer output was rendered to PNG and visually inspected for initial/solved states. Browser interaction/viewport QA remains for the integrator: the first isolated localhost attempt failed because the browser cannot reach that separate process. The parent owns the managed main preview and will perform CUA on the integrated route. Do not describe those unrun browser checks as passed.

## Palette consistency correction

The route and every SVG use the main site’s exact immutable home-face palette: U yellow `#F4D846`, D white `#F7F7F3`, F green `#38A878`, R orange `#F4A546`, L red `#E65E58`, B blue `#548DC4`. This is a home-color mapping, never recoloring by current position. All Vietnamese descriptions were regenerated. States, moves, piece IDs, permutation matrices, geometry, highlights, cameras, and stage predicates are byte-identical to the mechanical baseline. Run `node rubik_web/skewb_work/verify-palette-fixtures.mjs verify` to check. See `palette-consistency-report.json` for artifact hashes.
