"""Compare integer JS engine with original float Rodrigues implementation.
No production source is modified. Named-cycle JS oracle is self-contained in
skewb.test.mjs; this is a second independent implementation cross-check.
"""
from pathlib import Path
import sys, json, subprocess
import numpy as np
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parents[1]/'rubik_upgrade/source_material/extracted_v2_1'
sys.path.insert(0,str(SOURCE))
from poly_engine import Skewb
script="""
import {readFileSync} from 'node:fs';
import {Skewb,PIECES} from './skewb-engine.js';
const d=JSON.parse(readFileSync('./walkthrough-skewb.json'));
let p=new Skewb(),seed=137381;const moves=['R',\"R'\",'L',\"L'\",'B',\"B'\",'K',\"K'\",'x','y2',\"z'\"];
const sequence=[];for(let i=0;i<600;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const t=moves[(seed>>>16)%moves.length];sequence.push(t);p.move(t);}
console.log(JSON.stringify({fixtures:d.frames.map(f=>({state:new Skewb(f.state).stickerState()})),scramble:d.scrambleAlgorithm,moves:d.moves,random:{sequence,state:p.stickerState()},pieces:PIECES}));
"""
raw=subprocess.check_output(['node','--input-type=module','-e',script],cwd=HERE,text=True)
data=json.loads(raw)
def key(v):return tuple(int(round(x)) for x in v)
def reference(p):return {(key(h),key(hn)):(key(pos),key(n),color) for pos,n,color,h,hn in p.stickers}
homes={s['id']:(tuple(p['anchor']),tuple(s['normal'])) for p in data['pieces'] for s in p['stickers']}
def verify(p,rows):
 ref=reference(p)
 for s in rows: assert ref[homes[s['id']]]==(tuple(s['position']),tuple(s['normal']),s['color']),s['id']
p=Skewb().apply(data['scramble'])
for i,f in enumerate(data['fixtures']):
 verify(p,f['state'])
 if i<len(data['moves']):p.move(data['moves'][i])
assert p.solved()
r=Skewb().apply(' '.join(data['random']['sequence']));verify(r,data['random']['state'])
result={'passed':True,'pythonSource':'poly_engine.py original Rodrigues geometric sticker oracle','continuousSnapshotsCompared':len(data['fixtures']),'stickersPerSnapshot':30,'randomMixedMovesCompared':600,'finalExactStickerSolved':bool(p.solved())}
(HERE/'python-reference-QA.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
