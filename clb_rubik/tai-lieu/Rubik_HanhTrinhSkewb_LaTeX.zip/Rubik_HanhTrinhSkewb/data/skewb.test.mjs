import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {ConvexGeometry} from 'three/addons/geometries/ConvexGeometry.js';
import {Vector3,PerspectiveCamera} from 'three';
import {Skewb,PIECES,PIECE_IDS,STICKER_IDS,NORMALS,AXES,IDENTITY,add,scale,cross,dot,faceName,cornerName,inverse,tokenize,parseMove} from './skewb-engine.js';
import {SkewbView} from './skewb-three.js';
const doc=JSON.parse(readFileSync(new URL('./walkthrough-skewb.json',import.meta.url))),K="R' L R L'",G=`${K} y2 ${K} y2`;
const dist=(a,b)=>Math.hypot(...add(a,scale(b,-1)));
// Independent named-location oracle. These explicit combinatorial cycles use no
// engine matrix, cut plane, piece selection, Rodrigues formula or mesh code.
const rules={
 R:{corners:['UFL','UBR','DFR'],axis:'UFR',centers:['U','R','F'],faces:[['U','R','F'],['D','L','B']]},
 L:{corners:['UFR','DFL','UBL'],axis:'UFL',centers:['U','F','L'],faces:[['U','F','L'],['D','B','R']]},
 B:{corners:['UFR','UBL','DBR'],axis:'UBR',centers:['U','B','R'],faces:[['U','B','R'],['D','F','L']]},
 K:{corners:['UFL','DBL','UBR'],axis:'UBL',centers:['U','L','B'],faces:[['U','L','B'],['D','R','F']]},
 x:{whole:true,faces:[['U','B','D','F']]},y:{whole:true,faces:[['F','L','B','R']]},z:{whole:true,faces:[['U','R','D','L']]}
};
const cy=(v,cycles)=>{for(const c of cycles){const i=c.indexOf(v);if(i>=0)return c[(i+1)%c.length];}return v;};
function named(p){return p.stickerState().map(s=>({id:s.id,color:s.color,kind:s.pieceId.startsWith('corner')?'corner':'center',place:s.pieceId.startsWith('corner')?cornerName(s.position):faceName(s.position),face:faceName(s.normal)}));}
function oracle(state,token){const r=rules[token[0]],period=r.whole?4:3,power=(token.includes('2')?2:1)*(token.endsWith("'")?-1:1),n=(power%period+period)%period;for(let j=0;j<n;j++)state=state.map(s=>{const active=r.whole||(s.kind==='center'?r.centers.includes(s.place):r.corners.includes(s.place)||r.axis===s.place);if(!active)return {...s};const face=cy(s.face,r.faces);let place;if(r.whole){const faces=[...s.place].map(f=>cy(f,r.faces));place=s.kind==='center'?faces[0]:faces.find(f=>'UD'.includes(f))+faces.find(f=>'FB'.includes(f))+faces.find(f=>'RL'.includes(f));}else place=cy(s.place,[s.kind==='center'?r.centers:r.corners]);return {...s,face,place};});return state;}
function oracleApply(state,alg){for(const t of tokenize(alg))state=oracle(state,t);return state;}
function solid(points){const geo=new ConvexGeometry(points.map(v=>new Vector3(...v))),p=geo.getAttribute('position'),planes=[];let volume=0;for(let i=0;i<p.count;i+=3){const a=[p.getX(i),p.getY(i),p.getZ(i)],b=[p.getX(i+1),p.getY(i+1),p.getZ(i+1)],c=[p.getX(i+2),p.getY(i+2),p.getZ(i+2)],n=cross(add(b,scale(a,-1)),add(c,scale(a,-1)));volume+=dot(a,cross(b,c))/6;planes.push([n,dot(n,a)]);}geo.dispose();return {volume:Math.abs(volume),contains:q=>planes.every(([n,d])=>dot(q,n)<=d+1e-9)};}
test('true Skewb geometry: 14 convex pieces, 24 triangles + 6 diamonds, partition volume 8',()=>{
 assert.equal(PIECES.length,14);assert.equal(STICKER_IDS.length,30);const solids=PIECES.map(p=>solid(p.hull));assert.ok(Math.abs(solids.reduce((s,p)=>s+p.volume,0)-8)<1e-8);
 for(const [i,p]of PIECES.entries()){assert.equal(p.hull.length,5);assert.ok(Math.abs(solids[i].volume-(p.kind==='corner'?.5:2/3))<1e-8);assert.equal(p.stickers.length,p.kind==='corner'?3:1);for(const s of p.stickers){assert.equal(s.vertices.length,p.kind==='corner'?3:4);assert.ok(dot(cross(add(s.vertices[1],scale(s.vertices[0],-1)),add(s.vertices[2],scale(s.vertices[0],-1))),s.normal)>0);for(const v of s.vertices)assert.equal(dot(v,s.normal),1);}}
 for(const n of Object.values(NORMALS)){const stickers=PIECES.flatMap(p=>p.stickers).filter(s=>dot(s.normal,n)===1);assert.equal(stickers.length,5);let area=0;for(const s of stickers)for(let i=1;i<s.vertices.length-1;i++)area+=Math.hypot(...cross(add(s.vertices[i],scale(s.vertices[0],-1)),add(s.vertices[i+1],scale(s.vertices[0],-1))))/2;assert.equal(area,4);}
 let seed=129321;for(let i=0;i<1200;i++){const q=[0,1,2].map(()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**31-1;});assert.equal(solids.filter(s=>s.contains(q)).length,1,`cube partition ${q}`);}
 // Each movable solid is entirely in one cut halfspace; rotating about its
 // normal cannot cross into the stationary halfspace, including mid-animation.
 for(const axis of Object.values(AXES))for(const p of PIECES){const sign=Math.sign(dot(p.anchor,axis));assert.ok(p.hull.every(v=>dot(v,axis)*sign>=0));}
});
test('all corner turns and whole rotations agree with independent named oracle',()=>{
 for(const a of ['R','L','B','K','x','y','z'])for(const suffix of ['',"'",'2',"2'"]){const m=a+suffix,p=new Skewb(),d=p.animationDescriptor(m);assert.deepEqual(named(p.clone().move(m)),oracle(named(p),m),m);assert.equal(d.pieceIds.length,d.whole?14:7);assert.equal(d.stickerIds.length,d.whole?30:15);assert.equal(p.clone().apply(`${m} ${inverse(m)}`).signature(),p.signature());assert.equal(p.clone().apply(Array(d.whole?4:3).fill(m)).signature(),p.signature());}
 assert.deepEqual(named(new Skewb().move('R2')),named(new Skewb().move("R'")));
});
test('strict parser and schema import are atomic; malformed cube moves are rejected',()=>{
 for(const x of ['U','F','D','Rw','r','R3','R0',"R''",'(R)2'])assert.throws(()=>parseMove(x));const p=new Skewb(),before=p.signature();assert.throws(()=>p.apply('R L U'));assert.equal(p.signature(),before);const bad=p.exportState();bad.orientations[0]=Array(9).fill(0);assert.throws(()=>p.fromState(bad));assert.equal(p.signature(),before);assert.deepEqual(p.clone().exportState(),p.exportState());
});
test('2,000 mixed moves match independent location/color oracle without numerical drift',()=>{
 const moves=['R',"R'",'L',"L'",'B',"B'",'K',"K'",'x','y','z','y2',"z'"],p=new Skewb();let expected=named(p),seed=583214;for(let i=0;i<2000;i++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;const t=moves[(seed>>>16)%moves.length];p.move(t);expected=oracle(expected,t);assert.deepEqual(named(p),expected,`${i} ${t}`);if(i%50===0){assert.ok(p.validate());assert.equal(p.clone().signature(),p.signature());}}
});
test('book algorithms have semantic effects beyond cancellation: rescue, K and G',()=>{
 const p=new Skewb(),k=p.clone().apply(K);assert.ok(['DFR','DFL','DBR','DBL'].every(x=>k.pieceSolved('corner-'+x)));assert.ok(k.pieceSolved('center-D'));assert.equal(k.metrics().yellowUp.length,0);
 const g=p.clone().apply(G);for(const c of PIECES.filter(p=>p.kind==='corner'))assert.ok(g.pieceSolved(c.id));assert.equal(g.piece('center-U').place,'F');assert.equal(g.piece('center-F').place,'B');assert.equal(g.piece('center-B').place,'U');for(const f of ['D','L','R'])assert.ok(g.pieceSolved('center-'+f));
 const rescue=[["R'",'UFL','L'],['R','UBR','B'],["L R' L'",'UFL','F'],["B' R B",'UBR','R'],["L R L' R'",'DFR','F'],["B' R' B R",'DFR','R'],["R' L R' L'",'UBR','U'],["R B' R B",'UFL','U']];
 for(const [alg,place,whiteFace]of rescue){const a=p.clone().apply(inverse(alg)),target=a.piece('corner-DFR');assert.equal(target.place,place);assert.equal(target.stickers.find(s=>s.color==='D').face,whiteFace);for(const id of ['corner-DFL','corner-DBL','corner-DBR','center-D'])assert.ok(a.pieceSolved(id));assert.deepEqual(named(a),oracleApply(named(p),inverse(alg)));}
});
test('all 42 snapshots replay, preserve physical identities and reverse continuously',()=>{
 let p=new Skewb().apply(doc.scrambleAlgorithm),expected=oracleApply(named(new Skewb()),doc.scrambleAlgorithm);assert.equal(doc.moves.length,41);assert.equal(doc.frames.length,42);assert.equal(doc.stages.length,9);assert.deepEqual(p.exportState(),doc.initialState);assert.equal(p.metrics().whiteCorners.length,0);
 for(let i=0;i<=41;i++){const f=doc.frames[i];assert.deepEqual(p.exportState(),f.state);assert.deepEqual(named(p),expected);assert.equal(p.signature(),f.signature);assert.deepEqual(p.metrics(),f.metrics);assert.ok(p.validate());for(const id of f.highlightPieceIds){assert.ok(PIECE_IDS.includes(id));const piece=p.piece(id);assert.ok(f.find.includes(id));assert.ok(f.find.includes(`ở ${piece.place}`));}if(i<41){assert.deepEqual(p.animationDescriptor(doc.moves[i]),doc.steps[i].animation);assert.equal(p.signature(),doc.steps[i].beforeSignature);p.move(doc.moves[i]);expected=oracle(expected,doc.moves[i]);assert.equal(p.signature(),doc.steps[i].afterSignature);}}
 assert.ok(p.isSolved());assert.deepEqual(p.exportState(),doc.finalState);for(let i=40;i>=0;i--){p.move(inverse(doc.moves[i]));assert.deepEqual(p.exportState(),doc.frames[i].state);}assert.deepEqual(p.exportState(),doc.initialState);
 for(const [i,s]of doc.stages.entries()){assert.equal(s.start,i?doc.stages[i-1].endExclusive:0);assert.deepEqual(s.beforeState,doc.frames[s.start].state);assert.deepEqual(s.afterState,doc.frames[s.endExclusive].state);assert.deepEqual(new Skewb(s.beforeState).apply(s.algorithm).exportState(),s.afterState);}
});
test('stage predicates: 0→1→2→3→4 whites, exact ca0, all corners, opposite faces, final centers',()=>{
 assert.deepEqual(doc.stages.slice(0,4).map(s=>s.afterMetrics.whiteCorners.length),[1,2,3,4]);for(const [i,s]of doc.stages.slice(0,4).entries()){const p=new Skewb(s.afterState);assert.equal(p.piece('center-D').place,'D');for(const id of ['corner-DFR','corner-DBR','corner-DBL','corner-DFL'].slice(0,i+1))assert.ok(p.pieceSolved(id));}
 const ca=new Skewb(doc.stages[4].beforeState);assert.equal(ca.metrics().firstFaceSolved,true);const yellow=Object.fromEntries(PIECES.filter(p=>p.home.startsWith('U')&&p.kind==='corner').map(p=>{const q=ca.piece(p.id);return [q.place,q.stickers.find(s=>s.color==='U').face];}));assert.deepEqual(yellow,{UBL:'B',UFL:'F',UBR:'R',UFR:'R'});
 const corners=new Skewb(doc.stages[4].afterState);assert.equal(corners.metrics().solvedCorners.length,8);assert.equal(corners.piece('center-U').place,'B');const yellowDone=new Skewb(doc.stages[5].afterState);assert.deepEqual(yellowDone.metrics().uniformFaces,['U','D','R']);
 const grip=new Skewb(doc.stages[6].afterState);assert.equal(grip.piece('center-R').place,'D');assert.equal(grip.piece('center-D').place,'L');assert.equal(grip.piece('center-U').place,'R');assert.deepEqual(grip.metrics().uniformFaces,['D','R','L']);assert.ok(new Skewb(doc.stages[7].afterState).isSolved());assert.ok(new Skewb(doc.stages[8].afterState).isSolved());
});
test('Three adapter: real solids, 30 stickers, exact endpoint for every teaching turn, safe cancellation',()=>{
 const view=new SkewbView();for(const step of doc.steps){const p=new Skewb(doc.frames[step.index].state);view.setState(p,{highlightPieceIds:doc.frames[step.index].highlightPieceIds});assert.equal(view.groups.size,14);let body=0,sticker=0;view.root.traverse(x=>{if(x.userData.kind==='body')body++;if(x.userData.kind==='sticker')sticker++;});assert.equal(body,14);assert.equal(sticker,30);const d=view.previewMove(step.token,1),end=p.clone().move(step.token),expected=end.renderData({inset:1,offset:0});for(const s of p.renderData({inset:1,offset:0})){const q=view.groups.get(s.pieceId).quaternion,target=expected.find(x=>x.id===s.id);for(const v of s.vertices){const actual=new Vector3(...v).applyQuaternion(q).toArray();assert.ok(target.vertices.some(t=>dist(actual,t)<1e-8));}}assert.equal([...view.groups.values()].filter(g=>Math.abs(g.quaternion.w-1)>1e-8).length,d.pieceIds.length);assert.equal(view.puzzle.signature(),p.signature());view.cancelPreview();assert.ok([...view.groups.values()].every(g=>g.quaternion.w===1));view.commitMove(step.token);assert.deepEqual(view.puzzle.exportState(),end.exportState());}view.dispose();assert.equal(view.root.children.length,0);
});
test('teaching camera keeps cube and vertex label anchors within square mobile viewport',()=>{for(const s of doc.stages){const c=new PerspectiveCamera(38,1,.1,100);c.position.set(...s.camera);c.lookAt(0,.1,0);c.updateMatrixWorld();for(const x of [-1,1])for(const y of [-1,1])for(const z of [-1,1]){const p=new Vector3(x,y,z).multiplyScalar(1.25*1.21).project(c);assert.ok(Math.abs(p.x)<.95&&Math.abs(p.y)<.95,s.id);}}});
