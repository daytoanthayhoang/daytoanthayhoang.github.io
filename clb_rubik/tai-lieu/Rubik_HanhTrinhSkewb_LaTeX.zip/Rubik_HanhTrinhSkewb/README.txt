HÀNH TRÌNH SKEWB - NGUYỄN VIỆT HOÀNG
Bản in riêng, ngày 14/11/2026

Tệp đọc: Rubik_HanhTrinhSkewb.pdf
Tệp LaTeX chính: main.tex
Các chương: chapters/
Hình vector dùng trực tiếp trong sách: assets/
Dữ liệu nguồn nguyên bản: data/manifest.json, data/render-manifest.json
84 SVG nguồn: data/source-svg/
Kết quả kiểm tra và ảnh từng trang: qa/

NỘI DUNG
Một mẫu xáo hợp lệ được chuẩn bị để dạy học, đi liên tục qua 9 chặng.
41 thao tác gồm 31 lần vặn góc và 10 lần xoay cả khối; 42 trạng thái.
Mỗi thao tác có hình TRƯỚC, sáu mặt nhìn thẳng, mảnh cần theo dõi,
chiều xoay và vị trí SAU. Mỗi chặng có mục tiêu, tìm mảnh, lý do,
phần cần giữ, điểm kiểm SAU và bước tiếp theo. Khối đã giải ở trạng thái
40; thao tác 41 chỉ trả thế cầm. Đây không phải bộ giải mọi trạng thái.

KÝ HIỆU
R qua UFR, L qua UFL, B qua UBR; quay 120 độ nhìn từ đỉnh vào lõi.
Đây là ký hiệu cục bộ của sách, không đồng nhất với ký hiệu WCA.
y/y2/z/z' xoay cả khối. Mặt đồng hồ chỉ chiều nhìn được ghi ngay dưới;
không hiểu nó là mũi tên vẽ trên mặt đang thấy của phối cảnh.
Sáu mặt phẳng là các góc nhìn độc lập, không phải hình khai triển.

BIÊN DỊCH
Dùng XeLaTeX, font Latin Modern và các gói trong rubikbook.sty.
Chạy ./build.sh. Script biên dịch hai lần và tạo Rubik_HanhTrinhSkewb.pdf.
Nếu môi trường TeX chuẩn khác máy dựng, không cần hai biến TEXMF và
TEXFORMATS riêng của máy dựng; build.sh chỉ đặt chúng khi tìm thấy format.
Các hình vector đã được đóng kèm, nên biên dịch TeX không cần Python.

TÁI DỰNG HÌNH VÀ CHƯƠNG
Yêu cầu Python 3, numpy, matplotlib.
MPLCONFIGDIR="$PWD/qa/matplotlib-cache" python3 build_skewb_print.py
./build.sh
Script chỉ đọc các trạng thái khóa, không giải lại hoặc thay dãy thao tác.
Màu/đa giác lấy trực tiếp từ render-manifest.json; lớp ghi chú chỉ thêm
số mảnh, tên mặt và mặt đồng hồ lấy góc xoay từ animationDescriptor.

KIỂM TRA DỮ LIỆU
Yêu cầu Node.js; không cần thư viện ngoài.
node verify_locked.mjs
Kiểm lại dãy chuẩn bị, toàn bộ 42 trạng thái và bộ đa giác, 41 mô tả xoay,
chỉ số mảnh đúng, 9 ranh giới chặng và trạng thái giải xong cuối cùng.
qa/source_check.json và qa/replay_check.json ghi kết quả máy kiểm.
qa/print_QA.json ghi kiểm bản in cuối.

NGUỒN THAM KHẢO
Danh sách nguồn công khai nằm ở cuối PDF và trong manifest.json.
data/README.md, QA.json cùng các tệp chương trình còn lại là bản sao
nguồn gốc để đối chiếu; lệnh dựng website trong README gốc không phải
lệnh dựng tài liệu này. Chưa thực hiện kiểm thử website trong công việc
bản in này. Không thay đổi hoặc xuất bản website nào.
