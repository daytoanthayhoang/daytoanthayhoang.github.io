from pathlib import Path
import json,hashlib,re,subprocess,math,xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent;D=json.loads((ROOT/'data/manifest.json').read_text());R=json.loads((ROOT/'data/render-manifest.json').read_text());F=R['frames'];NS='{http://www.w3.org/2000/svg}'
assert len(F)==len(D['frames'])==len(D['moves'])+1==103
for i,f in enumerate(F):assert f['state']==D['frames'][i]['state'] and len(f['polygons'])==132
assert F[-1]['metrics']['solved']
def esc(x):return str(x).replace('′',"'").replace('\\',r'\textbackslash{}').replace('&',r'\&').replace('%',r'\%').replace('_',r'\_').replace('#',r'\#')
# Derivative print artwork: only background and labels are adapted. All puzzle polygons/arrows stay exact.
import sys
for i in ([] if '--text-only' in sys.argv else range(103)):
 for net in [False,True]:
  stem=f'{i:03}'+('-faces' if net else '');rt=ET.parse(ROOT/'data/svg'/(stem+'.svg')).getroot()
  if not net:
   for child in list(rt):
    if child.tag==NS+'rect' and child.get('width')=='600':child.set('fill','white')
    if child.tag==NS+'text' and child.get('y') in ['42','560','585']:rt.remove(child)
   for el in rt.iter():
    if el.tag==NS+'text' and el.get('font-size')=='13':el.set('font-size','25');el.set('y',str(float(el.get('y'))+3))
    elif el.tag==NS+'rect' and el.get('width')=='32':
     el.set('x',str(float(el.get('x'))-13));el.set('y',str(float(el.get('y'))-6));el.set('width','58');el.set('height','36')
   # Move readable center labels away from turn arrows. Leaders terminate at the original projected centers.
   for g in list(rt):
    if g.tag!=NS+'g':continue
    text=g.find(NS+'text');rect=g.find(NS+'rect')
    if text is None or rect is None:continue
    cx=float(text.get('x'));cy=float(rect.get('y'))+18
    dx,dy=cx-300,cy-300;dist=math.hypot(dx,dy)
    if dist<1:dx,dy,dist=0,1,1
    nx,ny=300+242*dx/dist,300+242*dy/dist
    line=ET.Element(NS+'line',{'x1':str(cx),'y1':str(cy),'x2':str(nx),'y2':str(ny),'stroke':'#405364','stroke-width':'1.3','stroke-dasharray':'3 3'})
    rt.insert(list(rt).index(g),line)
    dot=ET.Element(NS+'circle',{'cx':str(cx),'cy':str(cy),'r':'2.4','fill':'#405364'})
    rt.insert(list(rt).index(g),dot)
    g.set('transform',f'translate({nx-cx},{ny-cy})')
   # Authored target identities get a distinct dark contour, not the same white as inter-sticker gaps.
   hi=set(F[i]['highlightPieceIds'])
   for el in rt.iter():
    if el.tag==NS+'polygon' and el.get('data-piece-id') in hi:
     el.set('stroke','#944a08');el.set('stroke-width','3.2')
   # A white arrow glow remains valid against colored faces; dark core survives paper background.
  fn=ROOT/'assets'/(stem+'.svg');ET.ElementTree(rt).write(fn,encoding='unicode');subprocess.run(['inkscape',str(fn),'--export-type=pdf','--export-filename='+str(fn.with_suffix('.pdf'))],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
# Per-stage blocks, anchored to actual frame indices and fixed center names.
out=[r'\chapter{Một đường giải liên tục qua mười bốn chặng}']
for s in D['stages']:
 n=s['index']+1;start,end=s['start'],s['end'];f=F[start]
 if n>1:out += [r'\clearpage']
 out += [r'\section{'+esc(s['title'])+'}',r'\textbf{Chặng '+str(n)+r'. Mục tiêu.} '+esc(s['goal']),r'\begin{center}\includegraphics[width=.56\linewidth]{assets/'+f'{start:03}'+r'.pdf}\end{center}',r'{\small Trạng thái trước chặng, khung '+str(start)+'. Nhìn các mặt: '+esc(' / '.join(f['visibleFaces']))+'.}',r'\step{Tìm đúng mảnh}',esc(f['teaching']['find']),r'\step{Vì sao và chọn nhánh (tên mặt cục bộ)}',esc(s['why']),esc(s['choose'].replace('Chọn M-C cho đúng ba góc phía sau.', 'Chọn M-C cho ba góc đang ở U-F-L, U-BL-L, U-BR-BL theo tên tâm cố định.').replace("Không xoay cả khối và không bỏ U' cuối nhịp dù đã thấy ô vàng về đúng mặt.","Không xoay cả khối và không bỏ U′ cục bộ ở cuối nhịp (tức DL′ theo tên tâm cố định), dù đã thấy ô vàng về đúng mặt.").replace("Sau nước thứ năm toàn bài,","Sau nước chuyển trạm thứ năm, tức nước 102 của hành trình,"))]
 used=[]
 for tok in s['localAlgorithm'].split():
  face=re.sub(r"[2']",'',tok)
  if face not in used:used.append(face)
 mapping='; '.join(x+' → '+s['frameMap'][x] for x in ['U','D','F','R','L','BR','BL','DB','DBL','DL','DR','DBR'])
 out += [r'\begin{notebox}{Đọc tên mặt trong chặng này}',r'Các chữ trong phần giải thích theo cửa sổ cầm được đổi sang tên tâm cố định như sau: '+esc(mapping)+'. Dòng thao tác bên dưới đã đổi tên xong; chỉ làm dòng đó, không làm thêm một chuỗi thứ hai.',r'\textbf{Chuỗi theo tâm cố định:} \alg{'+esc(s['algorithm'])+'}',r'\end{notebox}',r'\textbf{Giữ gì sau cả cụm?} '+esc(s['preserve'])]
 for a in range(start,end,2):
  out += [r'\par\medskip\noindent\begin{minipage}{\linewidth}']
  for i in range(a,min(a+2,end)):
   t=D['moves'][i];angle=144 if '2' in t else 72;direc='ngược' if "'" in t else 'thuận';faces=' / '.join(F[i]['visibleFaces'])
   out += [r'\begin{minipage}[t]{.49\linewidth}\centering',r'{\bfseries '+str(i+1)+r'. \alg{'+esc(t)+r'}}\par',r'\includegraphics[width=\linewidth]{assets/'+f'{i:03}'+r'.pdf}',r'{\small '+str(angle)+'° '+direc+'. Nhìn: '+esc(faces)+r'.}\end{minipage}\hfill']
  out += [r'\end{minipage}\par']
 out += [r'\par\medskip\begin{minipage}{\linewidth}\begin{checkpointbox}{Kiểm sau chặng '+str(n)+'}',r'\includegraphics[width=\linewidth]{assets/'+f'{end:03}'+r'-faces.pdf}',esc(re.sub(r'Mốc kiểm [^:]+: đạt\.', 'Đã đạt mục tiêu chặng.', s['check'])),r'\par\textbf{Đi tiếp.} '+esc(D['stages'][n]['goal'] if n<len(D['stages']) else 'Đủ 12 mặt đồng màu. Dừng và kiểm toàn bộ các tâm, cạnh, góc.'),r'\end{checkpointbox}\end{minipage}']
out += [r'\clearpage\section{Nếu thế khối khác mẫu}',r'\begin{description}']
for b in D['branchNotes']:out += [r'\item['+esc(b['condition'])+'] '+esc(b['action'])]
out += [r'\end{description}',r'Không chạy tiếp chỉ vì đã thuộc chuỗi. Điều kiện vào và phần phải giữ quyết định có được áp dụng một chặng hay không.']
(ROOT/'chapters/journey.tex').write_text('\n'.join(out))
(ROOT/'qa/source_consistency.json').write_text(json.dumps({'manifest_sha256':hashlib.sha256((ROOT/'data/manifest.json').read_bytes()).hexdigest(),'render_sha256':hashlib.sha256((ROOT/'data/render-manifest.json').read_bytes()).hexdigest(),'frames':103,'moves':102,'stages':14,'state_and_polygon_count_match':True,'final_solved':True},indent=2))
print('Rendered 103 states,102 moves,14 stages.')
