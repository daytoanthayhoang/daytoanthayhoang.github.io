HÀNH TRÌNH MEGAMINX

Một mẫu xáo chuẩn bị, 14 chặng, 102 thao tác mặt và 103 trạng thái liên tục.
Ban đầu 18/30 cạnh và 10/20 góc đã đúng, gồm 4/5 nhánh sao trắng.
Đây không phải bộ giải mọi trạng thái hoặc một scramble ngẫu nhiên.

BIÊN DỊCH
Dùng XeLaTeX và các gói khai báo trong rubikbook.sty; chạy build.sh hai lần
đã được script thực hiện. Các PDF vector trong assets/ đủ dựng sách,
không cần Python hoặc Inkscape cho việc biên dịch TeX.
Trong máy dựng thử, có thể cần đặt:
TEXMF='{/usr/share/texmf,/usr/share/texlive/texmf-dist}'
TEXFORMATS='/workspace/scratch/a84c62516364/output/math8/Bo_TuyenChon40_Web_20261114_cloud/kiemtra:'
Không dùng đường dẫn đặc thù này trên máy có TeX Live/MiKTeX bình thường.

DỮ LIỆU VÀ HÌNH
data/manifest.json và data/render-manifest.json
là bản nguồn khóa của cùng hành trình trên web. SVG nguồn nằm data/svg/.
Mỗi hình dùng 132 sticker của khối 12 mặt ngũ giác thật. Tên tâm cố định
suốt bài; thay camera không đổi tên nước hoặc trạng thái. Bảng mỗi chặng
đổi tên cửa sổ cục bộ sang tên tâm cố định; chỉ làm chuỗi cố định đã in.
Mỗi nấc 72 độ; hai nấc 144 độ, U2 khác U2'.

Lớp in dẫn xuất có nền trắng, nhãn lớn ngoài khối với đường dẫn tới tâm,
viền nâu nhận mảnh mục tiêu. Không đổi polygon, màu, trạng thái hoặc
chiều/cung mũi tên nguồn. Mỗi hình nhỏ là trước nước; checkpoint sau cả cụm.
Mười hai hình mặt là các góc nhìn thẳng độc lập, không phải lưới gấp.

TÁI DỰNG
python3 build_megaminx_print.py (Python 3 và Inkscape) dựng lại hình/chương.
python3 build_megaminx_print.py --text-only chỉ dựng lại chương từ nguồn.
node render_toolkit/verify_locked.mjs không cần thư viện ngoài: kiểm scramble,
103 trạng thái, 13.596 polygon, 102 góc xoay và đích solved.
QA nguồn độc lập Python và QA web được giữ để đối chiếu; không suy từ đó
rằng mỗi trang in đã được kiểm. Kết quả xem bản in riêng nằm qa/.

NGUỒN
Chương Megaminx trong bản Hiểu để nhớ 2.1 người dùng đã cung cấp; danh sách
nguồn/algorithms/điều kiện có trong data/manifest.json. Nguồn tham khảo chính:
https://www.cubeskills.com/tutorials/beginner-megaminx-tutorial
https://www.gancube.com/pages/megaminx-guide-of-gan
Bảng màu chỉ thuộc mô hình chung này; Megaminx thực tế có thể dùng màu khác.
