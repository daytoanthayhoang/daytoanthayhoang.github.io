#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p qa
xelatex -interaction=nonstopmode -halt-on-error Rubik_HanhTrinhMegaminx.tex > qa/build1.txt
xelatex -interaction=nonstopmode -halt-on-error Rubik_HanhTrinhMegaminx.tex > qa/build2.txt
