import fs from 'node:fs'; import assert from 'node:assert/strict';
import {Megaminx,parseMove} from './megaminx-engine.js';
const j=JSON.parse(fs.readFileSync(new URL('../data/manifest.json',import.meta.url)));const r=JSON.parse(fs.readFileSync(new URL('../data/render-manifest.json',import.meta.url)));
const p=new Megaminx().apply(j.scrambleAlgorithm);assert.deepEqual(p.exportState(),j.initialState);
function norm(v){return JSON.parse(JSON.stringify(v));}
for(let i=0;i<j.frames.length;i++){
 assert.deepEqual(p.exportState(),j.frames[i].state);assert.deepEqual(p.exportState(),r.frames[i].state);
 const polys=p.renderData();assert.equal(polys.length,132);
 for(let k=0;k<polys.length;k++)assert.deepEqual(norm(polys[k]),r.frames[i].polygons[k]);
 if(i<j.moves.length){const m=parseMove(j.moves[i]);assert.equal(r.frames[i].arrow.token,j.moves[i]);assert.equal(r.frames[i].arrow.angleDegrees,-m.power*72);p.move(j.moves[i]);}
}
assert.equal(p.metrics().solved,true);
console.log(JSON.stringify({result:'PASS',frames:j.frames.length,sticker_polygons:j.frames.length*132,moves:j.moves.length,stages:j.stages.length,all_states_match:true,all_polygons_match:true,all_turn_angles_match:true,final_solved:true},null,2));
